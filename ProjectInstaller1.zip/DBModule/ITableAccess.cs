﻿using System;
using System.Data;

namespace SubmitPaymentAPI
{
    public interface ITableAccess
    {
        DataTable ReadSingleFromFedTable();

        Tuple<bool, bool> CheckAddressRequirements();

        void IncrementFedSequence();

        void UpdateFedRecord(string pkey, string status, string uetr);

        void AddRelatedReference(string pkey, string status, DateTime timesent);
    }
}