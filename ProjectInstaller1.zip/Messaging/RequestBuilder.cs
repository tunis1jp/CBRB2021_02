﻿using System;
using System.Collections.Generic;

namespace SubmitPaymentAPI
{// Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);

    public class RequestBuilder
    {
        private SubmitPaymentRequest request;
        public RequestBuilder()
        {
            request = new SubmitPaymentRequest();
        }

        public FinancialInstitutionIdWithNameAndAddress BuildFinancialInstitutionIdWithNameAndAddress(string bic, string name = null, PostalAddress addr = null)
        {
            return new FinancialInstitutionIdWithNameAndAddress_bic(bic ?? "", name, addr);
        }

        public FinancialInstitutionIdWithNameAndAddress BuildFinancialInstitutionIdWithNameAndAddress(string memId, string sysCode, string name = null, PostalAddress addr = null)
        {
            return new FinancialInstitutionIdWithNameAndAddress_clear(memId ?? "", sysCode ?? "", name, addr);
        }

        public FinancialInstitutionId BuildFinancialInstitutionId(string bic)
        {
            return new FinancialInstitutionId_bic(bic);
        }

        public FinancialInstitutionId BuildFinancialInstitutionId(string memId, string sysCode)
        {
            return new FinancialInstitutionId_clear(memId, sysCode);
        }

        public PostalAddress BuildPostalAddress(string[] addr)
        {
            return new PostalAddress(addr);
        }

        public PostalAddress BuildPostalAddress(string[] addr, string country)
        {
            return new PostalAddress(addr, country);
        }

        public PostalAddress BuildPostalAddress(string town, string c, string pCode, string d, string sub, string s, string bNum, string bName,
            string f, string pBox, string r, string loc, string dist, string csd)
        {
            return new PostalAddress(town, c, pCode, d, sub, s, bNum, bName, f, pBox, r, loc, dist, csd);
        }

        public Record BuildTaxRecord(string pYear, string pMonth, string type, string addInfo)
        {
            return new Record(Convert.ToInt32(pYear), pMonth, type, addInfo);
        }

        public Creditor BuildCreditor(string name, PostalAddress pa)
        {
            return new Creditor(name, pa);
        }

        public RequestBuilder AddBaseWireData(string amount, string currency, string transId, string eRate = null, string conNum = null)
        {
            double amt = Convert.ToDouble(amount);
            Nullable<double> er = null;
            if (eRate != null)
            {
                er = Convert.ToDouble(eRate);
            }
            request.wireData = new WireData(amt, currency, transId, "FED", er, conNum);
            return this;
        }

        public RequestBuilder AddWireIds(string pkey, string uetr = null, string instId = null)
        {
            request.wireData.wireIds = new WireIds(pkey, instId, uetr);
            return this;
        }

        public RequestBuilder AddOtherTransactionDates(string flag, string time)
        {
            OtherTransactionDates otd;
            if (flag == "C")
            {
                otd = new CreditTransactionDate(time);
            }
            else
            {
                otd = new DebitTransactionDate(time);
            }
            request.wireData.otherTransactionDates = otd;
            return this;
        }

        public RequestBuilder AddClearingAndSettlement(string locInstPro = null)
        {
            request.wireData.clearingAndSettlement = new ClearingAndSettlement(locInstPro);
            return this;
        }

        public RequestBuilder AddCreditTransferTransactionInformation(string amt, string cur)
        { 
            //Assumes we alredy setup clearing and settlement, if null we can make a new empty one
            if(request.wireData.clearingAndSettlement == null)
            {
                this.AddClearingAndSettlement();
            }
            double amount = Convert.ToDouble(amt);
            request.wireData.clearingAndSettlement.creditTransferTransactionInformation = new CreditTransferTransactionInformation(amount, cur);
            return this;
        }

        public RequestBuilder AddChargesInfo(string cb, string amount = null)
        {
            Nullable<double> amt = null;
            if (amount != null)
            {
                amt = Convert.ToDouble(amount);
            }
            request.wireData.clearingAndSettlement.chargesInfo = new ChargesInfo(cb, amt);
            return this;
        }

        public RequestBuilder AddCreditAccount(string acct, string acctType, string office)
        {
            request.wireData.clearingAndSettlement.creditAccount = new CreditAccount(acct, acctType, office);
            return this;
        }

        public RequestBuilder AddInstructingAgent(string bic)
        {
            FinancialInstitutionId finInstId = BuildFinancialInstitutionId(bic);
            request.wireData.clearingAndSettlement.instructingAgent = new InstructAgent(finInstId);
            return this;
        }

        public RequestBuilder AddInstructingAgent(string memId, string sysCode)
        {
            FinancialInstitutionId finInstId = BuildFinancialInstitutionId(memId, sysCode);
            request.wireData.clearingAndSettlement.instructingAgent = new InstructAgent(finInstId);
            return this;
        }

        public RequestBuilder AddInstructedAgent(string bic)
        {
            FinancialInstitutionId finInstId = BuildFinancialInstitutionId(bic);
            request.wireData.clearingAndSettlement.instructedAgent = new InstructAgent(finInstId);
            return this;
        }

        public RequestBuilder AddInstructedAgent(string memId, string sysCode)
        {
            FinancialInstitutionId finInstId = BuildFinancialInstitutionId(memId, sysCode);
            request.wireData.clearingAndSettlement.instructedAgent = new InstructAgent(finInstId);
            return this;
        }

        public RequestBuilder AddIntermediaryAgent1(string bic, string name = null, PostalAddress addr = null)
        {
            FinancialInstitutionIdWithNameAndAddress finInstId = BuildFinancialInstitutionIdWithNameAndAddress(bic, name, addr);
            request.wireData.clearingAndSettlement.intermediaryAgent1 = new IntermediaryAgent(finInstId);
            return this;
        }

        public RequestBuilder AddIntermediaryAgent2(string bic, string name = null, PostalAddress addr = null)
        {
            FinancialInstitutionIdWithNameAndAddress finInstId = BuildFinancialInstitutionIdWithNameAndAddress(bic, name, addr);
            request.wireData.clearingAndSettlement.intermediaryAgent2 = new IntermediaryAgent(finInstId);
            return this;
        }

        public RequestBuilder AddIntermediaryAgent3(string bic, string name = null, PostalAddress addr = null)
        {
            FinancialInstitutionIdWithNameAndAddress finInstId = BuildFinancialInstitutionIdWithNameAndAddress(bic, name, addr);
            request.wireData.clearingAndSettlement.intermediaryAgent3 = new IntermediaryAgent(finInstId);
            return this;
        }

        public RequestBuilder AddIntermediaryAgent1(string memId, string sysCode, string name = null, PostalAddress addr = null)
        {
            FinancialInstitutionIdWithNameAndAddress finInstId = BuildFinancialInstitutionIdWithNameAndAddress(memId, sysCode, name, addr);
            request.wireData.clearingAndSettlement.intermediaryAgent1 = new IntermediaryAgent(finInstId);
            return this;
        }

        public RequestBuilder AddIntermediaryAgent2(string memId, string sysCode, string name = null, PostalAddress addr = null)
        {
            FinancialInstitutionIdWithNameAndAddress finInstId = BuildFinancialInstitutionIdWithNameAndAddress(memId, sysCode, name, addr);
            request.wireData.clearingAndSettlement.intermediaryAgent2 = new IntermediaryAgent(finInstId);
            return this;
        }

        public RequestBuilder AddIntermediaryAgent3(string memId, string sysCode, string name = null, PostalAddress addr = null)
        {
            FinancialInstitutionIdWithNameAndAddress finInstId = BuildFinancialInstitutionIdWithNameAndAddress(memId, sysCode, name, addr);
            request.wireData.clearingAndSettlement.intermediaryAgent3 = new IntermediaryAgent(finInstId);
            return this;
        }

        public RequestBuilder AddInitiation(string initChannel, string initPName = null, string cAcctId = null)
        {
            request.wireData.initiation = new Initiation(initChannel, initPName, cAcctId);
            return this;
        }

        public RequestBuilder AddCreditor(string name, PostalAddress addr)
        {
            Creditor c = BuildCreditor(name, addr);
            request.wireData.initiation.creditor = c;
            return this;
        }

        public RequestBuilder AddIbanCreditorAccount(string iban, string type = null)
        {
            request.wireData.initiation.creditorAccount = new IbanAccount(iban, type);
            return this;
        }

        public RequestBuilder AddOtherCreditorAccount(string id, string type = null)
        {
            request.wireData.initiation.creditorAccount = new CreditorOtherAccount(id, type);
            return this;
        }

        public RequestBuilder AddCreditorAgent(FinancialInstitutionIdWithNameAndAddress id, string branchId = null, string[] inst = null)
        {
            List<string> instructions = (inst==null) ? null : new List<String>(inst);
            CreditorAgent agent = new CreditorAgent(branchId, id, instructions);
            request.wireData.initiation.creditorAgent = agent;
            return this;
        }

        public RequestBuilder AddDebtor(string name, PostalAddress pa = null)
        {
            request.wireData.initiation.debtor = new Debtor(name, pa);
            return this;
        }

        public RequestBuilder AddIbanDebtorAccount(string iban, string type = null)
        {
            request.wireData.initiation.debtorAccount = new IbanAccount(iban, type);
            return this;
        }
        public RequestBuilder AddOtherDebtorAccount(string id, string scheme, string type = null)
        {
            request.wireData.initiation.debtorAccount = new DebtorAccount(id, scheme, type);
            return this;
        }

        public RequestBuilder AddDebtorAgent(FinancialInstitutionIdWithNameAndAddress id)
        {
            request.wireData.initiation.debtorAgent = new DebtorAgent(id);
            return this;
        }
        public RequestBuilder AddRemittanceData(Record r, TaxCreditor c)
        {
            request.wireData.remittanceData = new RemittanceData(r, c);
            return this;
        }

        public RequestBuilder AddRemittanceData(string s)
        {
            request.wireData.remittanceData = new RemittanceData(s);
            return this;
        }

        public SubmitPaymentRequest Build()
        {
            return request;
        }

    }

}