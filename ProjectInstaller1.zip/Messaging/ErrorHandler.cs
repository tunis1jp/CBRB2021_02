﻿namespace SubmitPaymentAPI
{
    using ErrReporter;
    using System.IO;

    public class ErrorHandler : IErrorHandler
    {
        private const string ALERT_TYPE = "FedWire";

        private readonly StreamWriter lf;
        private readonly int maxAlerts;
        private readonly cReporter reporter;

        private int alertsSent = 0;

        public ErrorHandler(int max, StreamWriter logfile)
        {
            maxAlerts = max;
            reporter = new cReporter();
            lf = logfile;
        }

        // returns false if the number of maximum alerts have been reached
        public bool SendAlert(string subtype, string message, int pkey = 0, int transPkey = 0)
        {
            alertsSent += 1;

            lf.WriteLine($"ALERT [{ALERT_TYPE}_{subtype}]: {message}");
            reporter.SendAlert(ALERT_TYPE, message, pkey, transPkey);

            return maxAlerts <= alertsSent;
        }
    }

    public interface IErrorHandler
    {
        bool SendAlert(string subtype, string message, int pkey = 0, int transPkey = 0);
    }
}