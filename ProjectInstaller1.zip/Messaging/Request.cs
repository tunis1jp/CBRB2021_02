﻿using System;
using System.Collections.Generic;

namespace SubmitPaymentAPI
{
    public class ChargesInfo
    {
        public string chargeBearer { get; set; }
        public Nullable<double> amount { get; set; }

        public ChargesInfo(string cb, Nullable<double> amt)
        {
            chargeBearer = cb;
            amount = amt;
        }
    }

    public class ClearingAndSettlement
    {
        public CreditTransferTransactionInformation creditTransferTransactionInformation { get; set; }
        public string localInstrumentProprietary { get; set; }
        public ChargesInfo chargesInfo { get; set; }
        public CreditAccount creditAccount { get; set; }
        public InstructAgent instructingAgent { get; set; }
        public InstructAgent instructedAgent { get; set; }
        public IntermediaryAgent intermediaryAgent1 { get; set; }
        public IntermediaryAgent intermediaryAgent2 { get; set; }
        public IntermediaryAgent intermediaryAgent3 { get; set; }

        public ClearingAndSettlement(string locInstPro = null)
        {
            localInstrumentProprietary = locInstPro;
            chargesInfo = null;
            creditAccount = null;
            instructingAgent = null;
            instructedAgent = null;
            intermediaryAgent1 = null;
            intermediaryAgent2 = null;
            intermediaryAgent3 = null;
        }
    }

    public class CreditAccount
    {
        public string accountString { get; set; }
        public string accountIdType { get; set; }
        public string office { get; set; }

        public CreditAccount(string acct, string type, string o)
        {
            accountString = acct;
            accountIdType = type;
            office = o;
        }
    }

    public class Creditor
    {
        public string name { get; set; }
        public PostalAddress postalAddress { get; set; }

        public Creditor(string n, PostalAddress pa)
        {
            name = n;
            postalAddress = pa;
        }
    }
    public class TaxCreditor
    {
        public string taxId { get; set; }
        public string regulationId { get; set; }

        public TaxCreditor(string tId, string regId)
        {
            taxId = tId;
            regulationId = regId;
        }
    }

    public class Account
    {
        public Id id { get; set; }
        public string typeCode { get; set; }

        public Account(string type)
        {
            typeCode = type;
        }
    }

    public class IbanAccount : Account
    {
        public IbanAccount(string idiban, string type = null) : base(type)
        {
            id = new IbanId(idiban);
        }
    }

    public class OtherAccount : Account
    {
        public OtherAccount(string acctId, string type = null) : base(type)
        {
            id = new Other(acctId);
        }
    }

    public class CreditorOtherAccount : Account
    {
        public CreditorOtherAccount(string acctId, string type = null) : base(type)
        {
            id = new CredOtherId(acctId);
        }
    }
    public class CreditorAgent
    {
        public string branchId { get; set; }
        public FinancialInstitutionIdWithNameAndAddress financialInstitutionIdWithNameAndAddress { get; set; }
        public List<string> instructionForCreditorAgent { get; set; }

        public CreditorAgent(string branch, FinancialInstitutionIdWithNameAndAddress id, List<string> inst)
        {
            branchId = branch;
            financialInstitutionIdWithNameAndAddress = id;
            instructionForCreditorAgent = inst;
        }
    }

    public class CreditTransferTransactionInformation
    {
        public double interBankSettlementAmount { get; set; }
        public string interBankSettlementAmountCurrency { get; set; }

        public CreditTransferTransactionInformation(double amt, string cur)
        {
            interBankSettlementAmount = amt;
            interBankSettlementAmountCurrency = cur;
        }
    }

    public class Debtor
    {
        public string name { get; set; }
        public PostalAddress postalAddress { get; set; }

        public Debtor(string n, PostalAddress pa)
        {
            name = n;
            postalAddress = pa;
        }
    }

    public class DebtorAccount : Account
    {
        public DebtorAccount(string i, string scheme, string type) : base(type)
        {
            id = new DebOtherId(i, scheme);
        }
    }

    public class DebtorAgent
    {
        public FinancialInstitutionIdWithNameAndAddress financialInstitutionId { get; set; }

        public DebtorAgent(FinancialInstitutionIdWithNameAndAddress id)
        {
            financialInstitutionId = id;
        }
    }

    public class FinancialInstitutionId
    {
        public string bicfi { get; set; }
        public ClearingSystemMemberId clearingSystemMemberId { get; set; }

    }

    public class FinancialInstitutionId_bic : FinancialInstitutionId
    {

        public FinancialInstitutionId_bic(string bic)
        {
            bicfi = bic;
            clearingSystemMemberId = null;
        }
    }

    public class FinancialInstitutionId_clear : FinancialInstitutionId
    {
        public FinancialInstitutionId_clear(string memId, string sysCode)
        {
            bicfi = null;
            clearingSystemMemberId = new ClearingSystemMemberId(memId, sysCode);
        }
    }

    public class FinancialInstitutionIdWithNameAndAddress
    {
        public string bicfi { get; set; }
        public ClearingSystemMemberId clearingSystemMemberId { get; set; }

        public string name { get; set; }
        public PostalAddress postalAddress { get; set; }
        public FinancialInstitutionIdWithNameAndAddress(string n, PostalAddress pa)
        {
            name = n;
            postalAddress = pa;
        }
    }


    public class FinancialInstitutionIdWithNameAndAddress_bic : FinancialInstitutionIdWithNameAndAddress
    {
        public FinancialInstitutionIdWithNameAndAddress_bic(string bic, string n, PostalAddress pa) : base(n, pa)
        {
            bicfi = bic;
            clearingSystemMemberId = null;
        }
    }

    public class FinancialInstitutionIdWithNameAndAddress_clear : FinancialInstitutionIdWithNameAndAddress
    {
        public FinancialInstitutionIdWithNameAndAddress_clear(string memId, string sysCode, string n, PostalAddress pa) : base(n, pa)
        {
            bicfi = null;
            clearingSystemMemberId = new ClearingSystemMemberId(memId, sysCode);
        }
    }

    public class ClearingSystemMemberId
    {
        public string memberId { get; set; }
        public string clearingSystemIdCode { get; set; }
        public ClearingSystemMemberId(string m, string c)
        {
            memberId = m;
            clearingSystemIdCode = c;
        }
    }

    public class Id
    {
        public Other other { get; set; }
        public string iban { get; set; }


    }

    public class CredOtherId : Id
    {
        public CredOtherId(string id)
        {
            other = new Other(id);
            iban = null;
        }
    }
    public class DebOtherId : Id
    {

        public DebOtherId(string id, string scheme)
        {
            other = new DebOther(id, scheme);
            iban = null;
        }
    }

    public class IbanId : Id
    {
        public IbanId(string i)
        {
            other = null;
            iban = i;
        }
    }

    public class Initiation
    {
        public Creditor creditor { get; set; }
        public Account creditorAccount { get; set; }
        public string creditorAgentAccountId { get; set; }
        public CreditorAgent creditorAgent { get; set; }
        public Debtor debtor { get; set; }
        public Account debtorAccount { get; set; }
        public DebtorAgent debtorAgent { get; set; }
        public string initiatingChannel { get; set; }
        public string initiatingPartyName { get; set; }

        public Initiation(string initChannel, string initPName, string cAcctId)
        {
            initiatingChannel = initChannel;
            initiatingPartyName = initPName;
            creditorAgentAccountId = cAcctId;
        }
    }

    public class InstructAgent
    {
        public FinancialInstitutionId financialInstitutionId { get; set; }
        public InstructAgent(FinancialInstitutionId finInstId)
        {
            financialInstitutionId = finInstId;
        }
    }

    public class IntermediaryAgent
    {
        public FinancialInstitutionIdWithNameAndAddress financialInstitutionId { get; set; }
        public IntermediaryAgent(FinancialInstitutionIdWithNameAndAddress finInstId)
        {
            financialInstitutionId = finInstId;
        }
    }



    public class DebOther : Other
    {

        public DebOther(string i, string s) : base(i)
        {
            schemeNameCode = s;
        }

    }

    public class Other : Id
    {
        public string id { get; set; }
        public string schemeNameCode { get; set; }

        public Other(string i)
        {
            id = i;
        }
    }

    public class OtherTransactionDates
    {
        public string creditValueDateTime { get; set; }
        public string debitValueDateTime { get; set; }

        public OtherTransactionDates(string cred, string deb)
        {
            creditValueDateTime = cred;
            debitValueDateTime = deb;
        }
    }

    public class DebitTransactionDate : OtherTransactionDates
    {
        public DebitTransactionDate(string d) : base(null, d) { }
    }
    public class CreditTransactionDate : OtherTransactionDates
    {
        public CreditTransactionDate(string d) : base(d, null) { }
    }

    public class Period
    {
        public int year { get; set; }
        public string month { get; set; }

        public Period(int y, string m)
        {
            year = y;
            month = m;
        }
    }

    public class PostalAddress
    {
        public PostalAddressUnstructured unstructured { get; set; }
        public string[] unstructuredAddressLine { get; set; }
        public PostalAddressStrucutred structured { get; set; }

        public PostalAddress(string[] addr)
        {
            unstructuredAddressLine = addr;
            unstructured = null;
            structured = null;
        }

        public PostalAddress(string[] addr, string c)
        {
            unstructuredAddressLine = null;
            unstructured = new PostalAddressUnstructured(addr, c);
            structured = null;
        }

        public PostalAddress(string town, string c, string pCode, string d, string sub, string s, string bNum, string bName,
            string f, string pBox, string r, string loc, string dist, string csd)
        {
            unstructured = null;
            structured = new PostalAddressStrucutred(town, c, pCode, d, sub, s, bNum, bName, f, pBox, r, loc, dist, csd);
        }

    }

    public class PostalAddressUnstructured
    {
        public List<string> addressLine { get; set; }
        public string country { get; set; }

        public PostalAddressUnstructured(string[] addr, string c)
        {
            addressLine = new List<string>(addr);
            country = c;
        }
    }

    public class PostalAddressStrucutred
    {
        public string townName { get; set; }
        public string country { get; set; }
        public string postalCode { get; set; }
        public string department { get; set; }
        public string subDepartment { get; set; }
        public string streetName { get; set; }
        public string buildingNumber { get; set; }
        public string buildingName { get; set; }
        public string floor { get; set; }
        public string postalBox { get; set; }
        public string room { get; set; }
        public string townLocation { get; set; }
        public string districtName { get; set; }
        public string countrySubDivision { get; set; }

        public PostalAddressStrucutred(string town, string c, string pCode, string d, string sub, string s, string bNum, string bName,
            string f, string pBox, string r, string loc, string dist, string csd)
        {
            townName = town;
            country = c;
            postalCode = pCode;
            department = d;
            subDepartment = sub;
            streetName = s;
            buildingNumber = bNum;
            buildingName = bName;
            floor = f;
            postalBox = pBox;
            room = r;
            townLocation = loc;
            districtName = dist;
            countrySubDivision = csd;
        }
    }



    public class Record
    {
        public Period period { get; set; }
        public string type { get; set; }
        public string additionalInformation { get; set; }

        public Record(int year, string month, string t, string addInfo)
        {
            period = new Period(year, month);
            type = t;
            additionalInformation = addInfo;
        }
    }


    public class RemittanceData
    {
        public RemittanceDataTax structured { get; set; }
        public RemittanceDataUnstructured unstructured { get; set; }

        public RemittanceData(string u)
        {
            structured = null;
            unstructured = new RemittanceDataUnstructured(u);
        }

        public RemittanceData(Record r, TaxCreditor c)
        {
            structured = new RemittanceDataTax(r, c);
            unstructured = null;
        }
    }

    public class RemittanceDataTax
    {
        public Tax tax { get; set; }
        public RemittanceDataTax(Record r, TaxCreditor c)
        {
            tax = new Tax(r, c);
        }

    }

    public class RemittanceDataUnstructured
    {
        public string unstrucutred { get; set; }
        public RemittanceDataUnstructured(string u)
        {
            unstrucutred = u;
        }
    }

    public class SubmitPaymentRequest
    {
        public WireData wireData { get; set; }
    }

    public class Tax
    {
        public Record record { get; set; }
        public TaxCreditor creditor { get; set; }
        public Tax(Record r, TaxCreditor c)
        {
            record = r;
            creditor = c;
        }
    }

    public class WireData
    {
        public WireIds wireIds { get; set; }
        public OtherTransactionDates otherTransactionDates { get; set; }
        public double amount { get; set; }
        public string currency { get; set; }
        public string transactionIdentification { get; set; }
        public string transactionType { get; set; }
        public Nullable<double> exchangeRate { get; set; }
        public string fxContractNumber { get; set; }
        public ClearingAndSettlement clearingAndSettlement { get; set; }
        public Initiation initiation { get; set; }
        public RemittanceData remittanceData { get; set; }

        public WireData(double amt, string cur, string transId, string type, Nullable<double> eRate = null, string conNumber = null)
        {
            amount = amt;
            currency = cur;
            transactionIdentification = transId;
            transactionType = type;
            //not used currently
            exchangeRate = eRate;
            fxContractNumber = conNumber;
        }
    }

    public class WireIds
    {
        public string senderReferenceNumber { get; set; }
        public string endToEndId { get; set; }
        public string instructionId { get; set; }
        public string uniqueEndToEndTransactionReference { get; set; }

        public WireIds(string pkey, string instId = null, string uter = null)
        {
            senderReferenceNumber = pkey;
            endToEndId = pkey;
            instructionId = instId;
            uniqueEndToEndTransactionReference = uter;
        }
    }

}