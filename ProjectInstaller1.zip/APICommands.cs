﻿namespace SubmitPaymentAPI
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Net.Http;

    public class APICommands
    {
        private readonly HttpClient client;
        private readonly WiresConfig wires;
        private readonly ITableAccess ta;
        private readonly IErrorHandler errorHandler;
        private readonly StreamWriter logfile;
        public TokenWrapper tWrapper;


        //HttpClient is used for testing
        public APICommands(WiresConfig wiresConfig, ITableAccess fedTableAccess, IErrorHandler eh, StreamWriter lf, HttpClient hc)
        {
            client = hc ?? new HttpClient();
            wires = wiresConfig;
            ta = fedTableAccess;
            logfile = lf;
            errorHandler = eh;
        }

        public async void AuthorizeClient()
        {
            var formData = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials"),
                new KeyValuePair<string, string>("scope", "wires.pwsp.w")
            };

            try
            {
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(wires.PingFedURL),
                    Headers = {
                        //TODO: Revisit
                        { "Authorization", "Basic " + wires.GetPingFedPassword()}
                    },
                    Content = new FormUrlEncodedContent(formData)
                };

                logfile.WriteLine("Sending Authorization Request");

                DateTime issueDate = System.DateTime.Now;
                var resp = client.SendAsync(request).Result;
                //await turns the async back to sync
                string msg = await resp.Content.ReadAsStringAsync();
                ProcessAuth(resp.StatusCode, msg, issueDate);
            }
            catch(AggregateException e)
            {
                ProcessException(e, true);
            }
        }

        public async void SendPaymentRequest(SubmitPaymentRequest req)
        {
            bool tryAgain = true;
            int tries = 0;
            try
            {
                string messageGuid = System.Guid.NewGuid().ToString();
                logfile.WriteLine("Sending payment request. Reference Number: [" + req.wireData.wireIds.senderReferenceNumber + "]");

                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(wires.SubmitPaymentURL),
                    Headers = {
                        { "Authorization", tWrapper.Token.Token_type + " " + tWrapper.Token.Access_token},
                        { "x-correlation-id", messageGuid}, 
                        { "x-consumer-id", wires.ApplicationCode }
                    },
                    Content = new StringContent(JsonConvert.SerializeObject(req))
                };

                logfile.WriteLine($"Sending payment Request message with content: {request.Content}");

                //Try to send a message up to 10 times if it responds with a 500 status
                while (tryAgain) {
                    DateTime issueDate = DateTime.Now;
                    var resp = client.SendAsync(request).Result;
                    //await turns the async back to sync
                    string msg = await resp.Content.ReadAsStringAsync();
                    tryAgain = ProcessResponse(resp.StatusCode, msg, req, tries += 1, issueDate);
                }
            }
            catch (AggregateException e)
            {
                ProcessException(e, false);
            }
        }

        private void ProcessAuth(HttpStatusCode status, string content, DateTime issueDate)
        { 
            if (status == HttpStatusCode.OK)
            {
                AccessToken tkn = JsonConvert.DeserializeObject<AccessToken>(content);
                tWrapper = new TokenWrapper(tkn, issueDate);
                logfile.WriteLine("Successfully autheticated API Service");
            }
            else
            {
                string message = $"An error response was returned from the Authetication Endpoint: {content}";
                errorHandler.SendAlert("OAuth", message);
                tWrapper = null;
            }
        }

        private bool ProcessResponse(HttpStatusCode status, string content, SubmitPaymentRequest req, int tries, DateTime issueDate)
        {

            // 202 Response = Accepted 
            // OK status omitted from design, might need to ignore

            if (status == HttpStatusCode.Accepted || status == HttpStatusCode.OK)
            {
                Response_Success resp = JsonConvert.DeserializeObject<Response_Success>(content);

                logfile.WriteLine("Request [" + req.wireData.wireIds.senderReferenceNumber + "] has been sent successfully.");

                // Update MTStatus to 1 and UETR to response value
                try
                {
                    ta.UpdateFedRecord(resp.senderReferenceNumber, "1", resp.uniqueEndToEndTransactionReference);
                    ta.AddRelatedReference(resp.senderReferenceNumber, status.ToString(), issueDate);
                } catch (TableAccessException e)
                {
                    logfile.WriteLine(e.Message);
                }
                return false;
            }
            else if((int)status >= 500 && tries <= 10)
            {
                // Try again, if 10 tries then go to else block
                return true;
            }
            else
            {
                Response_Error resp = JsonConvert.DeserializeObject<Response_Error>(content);

                string message = "";
                message += $"An error response was recieved from the request for message[{req.wireData.wireIds.senderReferenceNumber}]\r\n";
                foreach(AdditionalStatus addstat in resp.status.additionalStatus)
                {
                    message += $"-- StatusCode: {addstat.statusCode}, Severity: {addstat.severity}, StatusDesc: {addstat.statusDesc}";
                }
                errorHandler.SendAlert("SubmitPayment", message, int.Parse(req.wireData.wireIds.senderReferenceNumber));

                // 9 is an error status, no UETR to add
                try { 
                    ta.UpdateFedRecord(req.wireData.wireIds.senderReferenceNumber, "9", "");
                    ta.AddRelatedReference(req.wireData.wireIds.senderReferenceNumber, status.ToString(), issueDate);
                } catch (TableAccessException e)
                {
                    logfile.WriteLine(e.Message);
                }
                return false;
            }
        }

        private void ProcessException(AggregateException e, bool isOauth)
        {
            if (isOauth)
            {
                string alertMessage = "";

                foreach (Exception x in e.InnerExceptions)
                {
                    if (x is ArgumentNullException)
                    {
                        string readableMsg = "The request was null.";
                        alertMessage += $"An error occurred in Authorization: {readableMsg}\r\n";
                    }
                    else if (x is InvalidOperationException)
                    {
                        string readableMsg = "The request message was already sent by the System.Net.Http.HttpClient instance.";
                        alertMessage += $"An error occurred in Authorization: {readableMsg}\r\n";
                    }
                    else if (x is HttpRequestException)
                    {
                        string readableMsg = "The request failed due to an underlying issue such as network connectivity, DNS";
                        readableMsg += "failure, server certificate validation or timeout.";
                        alertMessage += $"An error occurred in Authorization: {readableMsg}\r\n";
                    }
                    else //Should not be hit - not a valid exception from SendAsync
                    {
                        alertMessage = $"An unexpected error occurred in the network call: {x.Message}\r\n";
                    }
                }
                errorHandler.SendAlert("OAuth", alertMessage);
            }
            else
            {
                string alertMessage = "";

                foreach (Exception x in e.InnerExceptions)
                {
                    if (x is ArgumentNullException)
                    {
                        string readableMsg = "The request was null.";
                        alertMessage += $"An error occurred in Authorization: {readableMsg}\r\n";
                    }
                    else if (x is InvalidOperationException)
                    {
                        string readableMsg = "The request message was already sent by the System.Net.Http.HttpClient instance.";
                        alertMessage += $"An error occurred in Authorization: {readableMsg}\r\n";
                    }
                    else if (x is HttpRequestException)
                    {
                        string readableMsg = "The request failed due to an underlying issue such as network connectivity, DNS";
                        readableMsg += "failure, server certificate validation or timeout.";
                        alertMessage += $"An error occurred in Authorization: {readableMsg}\r\n";
                    }
                    else //Should not be hit - not a valid exception from SendAsync
                    {
                        alertMessage += "An unexpected error occurred in the network call: {x.Message}\r\n";
                    }
                }
                errorHandler.SendAlert("SendPayment", alertMessage);
            }
        }
    }
    public class AccessToken
    {
        public string Access_token { get; set; }
        public string Token_type { get; set; }
        public int Expires_in { get; set; }
    }

    public class TokenWrapper
    {
        public AccessToken Token { get; set; }
        public DateTime IssueDate { get; set; }
        public TokenWrapper(AccessToken t, DateTime issueDt)
        {
            Token = t;
            IssueDate = issueDt;
        }

        public bool IsExpired()
        {
            //If compare response is greater than zero, the token is expired
            return System.DateTime.Now.CompareTo(IssueDate.AddSeconds(Token.Expires_in)) >= 0;
        }
    }
}