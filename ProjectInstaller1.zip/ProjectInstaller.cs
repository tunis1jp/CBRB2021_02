﻿using System;
using System.ComponentModel;
using System.ServiceProcess;
using System.Xml;

namespace SubmitPaymentAPI
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();

            Installers.Clear();
            Installers.Add(GetServiceInstaller());
            Installers.Add(GetServiceProcessInstaller());
        }

        private ServiceInstaller GetServiceInstaller()
        {
            string name = GetConfigValue("GTSServicename") ?? "GTS_SubmitPayment";
            return new ServiceInstaller()
            {
                ServiceName = name,
                Description = "Cibar " + name
            };
        }

        private string GetConfigValue(string node)
        {
            try
            {
                string path = System.Reflection.Assembly.GetExecutingAssembly().Location
                    + "\\" + "wires.config";

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load("wires.config");

               return xmlDoc.GetElementsByTagName(node)[0].InnerText;
            } catch (Exception ex)
            {
                Console.WriteLine("Config file error: " + ex.Message);
            }
            //Return null to trigger default
            return null;
        }

        private ServiceProcessInstaller GetServiceProcessInstaller()
        {
            return new ServiceProcessInstaller
            {
                Account = ServiceAccount.LocalSystem
            };
        }
    }
}
