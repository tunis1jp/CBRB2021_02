﻿using System;
using System.IO;
using System.ServiceProcess;

namespace SubmitPaymentAPI
{
    public partial class SubmitPaymentAPIService : ServiceBase
    {
        public SubmitPaymentAPIService()
        { 
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            System.Threading.Thread.Sleep(30000);
            Program.Main();
        }

        protected override void OnStop()
        {
            //Stopping service
        }
    }
}
