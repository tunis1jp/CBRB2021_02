function SetFocusDelay() {
    setTimeout("SetFocusFunction()", 1000);
}

//*****************************************************************************
// This module contains functions which are shared between the
// user and bank side
//*****************************************************************************

function ParseForBadChars(str) {
    var pos;

    // start at first character and go for the length of the string
    for (pos = 0; pos < str.length; pos++) {
        switch (str.charAt(pos)) {
            case " ": // space
                str =
                    str.substr(0, pos) + "%20" + str.substr(pos + 1, str.length - pos);
                break;

            case "#": // pound sign
                str =
                    str.substr(0, pos) + "%23" + str.substr(pos + 1, str.length - pos);
                break;

            case "$": // dollar sign
                str =
                    str.substr(0, pos) + "%24" + str.substr(pos + 1, str.length - pos);
                break;

            case "%": // percent
                str =
                    str.substr(0, pos) + "%25" + str.substr(pos + 1, str.length - pos);
                break;

            case "&": // ampersand
                str =
                    str.substr(0, pos) + "%26" + str.substr(pos + 1, str.length - pos);
                break;

            case ".": // period
                str =
                    str.substr(0, pos) + "%2E" + str.substr(pos + 1, str.length - pos);
                break;

            case "/": // forward slash
                str =
                    str.substr(0, pos) + "%2F" + str.substr(pos + 1, str.length - pos);
                break;

            case ":": // colon
                str =
                    str.substr(0, pos) + "%3A" + str.substr(pos + 1, str.length - pos);
                break;

            case "<": // less than
                str =
                    str.substr(0, pos) + "%3C" + str.substr(pos + 1, str.length - pos);
                break;

            case ">": // greater than
                str =
                    str.substr(0, pos) + "%3E" + str.substr(pos + 1, str.length - pos);
                break;

            case "?": // question mark
                str =
                    str.substr(0, pos) + "%3F" + str.substr(pos + 1, str.length - pos);
                break;

            case "@": // at sign
                str =
                    str.substr(0, pos) + "%40" + str.substr(pos + 1, str.length - pos);
                break;

            case "[": // left square bracket
                str =
                    str.substr(0, pos) + "%5B" + str.substr(pos + 1, str.length - pos);
                break;

            case "\\": // backslash
                str =
                    str.substr(0, pos) + "%5C" + str.substr(pos + 1, str.length - pos);
                break;

            case "]": // right square bracket
                str =
                    str.substr(0, pos) + "%5D" + str.substr(pos + 1, str.length - pos);
                break;

            case "^": // caret
                str =
                    str.substr(0, pos) + "%5E" + str.substr(pos + 1, str.length - pos);
                break;

            case "{": // left brace
                str =
                    str.substr(0, pos) + "%7B" + str.substr(pos + 1, str.length - pos);
                break;

            case "|": // pipe
                str =
                    str.substr(0, pos) + "%7C" + str.substr(pos + 1, str.length - pos);
                break;

            case "}": // right brace
                str =
                    str.substr(0, pos) + "%7D" + str.substr(pos + 1, str.length - pos);
                break;

            case "~": // tilde
                str =
                    str.substr(0, pos) + "%7E" + str.substr(pos + 1, str.length - pos);
                break;
        }
    }
    return str;
}

//***********************************************************
// We have a 'family' of functions to check for valid input
// with a varying degree of restrictions.
//***********************************************************

//* Added this function to check for a larger range of allowed characters
function chkAlmostAnythingGoes(field, sDescription) {
    var sValidChars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-?:().,'+{} [];&!@#$^&*_=`~| ";
    var sMsg = "";

    sMsg = FindInvalidChars(field, sValidChars);
    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }
}
//* Added this function to check for invalid characters in the saving of report names.
function chkReportValChars(field, sDescription) {
    var sValidChars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_?:. &";
    var sMsg = "";

    sMsg = FindInvalidChars(field, sValidChars);
    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }
}

function chkValidReference(field, sDescription) {
    var sValidChars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-?().'+{} ";
    var sMsg = "";

    sMsg = FindInvalidChars(field, sValidChars);
    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }
}

function chkValidUrl(field, sDescription) {
    var sValidChars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-:().,+ ";
    var sMsg = "";

    sMsg = FindInvalidChars(field, sValidChars);
    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }
}

function chkAlphaNumericFullPunct(field, sDescription) {
    var sValidChars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-?:().,'+{} [];&";
    var sMsg = "";

    sMsg = FindInvalidChars(field, sValidChars);
    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }
}
// This isn't really a Swift 2018 check. It is being created as a part of those changes
// but it could be used for most (if not all) other checks. It takes the valid characters
// as an input parameter.
function checkSwiftModular(field, sDescription, ValidCharsIn) {
    var sMsg = "";

    if (ValidCharsIn !== undefined) {
        sMsg = FindInvalidChars(field, ValidCharsIn);
        if (sMsg !== "") {
            sMsg =
                "The " +
                sDescription +
                " data includes the following disallowed character(s):\n" +
                sMsg +
                "\n Please replace these before continuing.";
            alert(sMsg);
            field.focus();
            return false;
        } else {
            return true;
        }
    } else {
        sMsg = "The valid characters parameter is missing.";
        return false;
    }
}
function chkTextArea2018(field, sDescription, InValidCharsIn) {
    var sResult = "";
    var iIndex = 0;
    var iLen = 0;
    var sMsg = "";
    var sOneChar = "";

    sResult = field.value;

    iLen = InValidCharsIn.length;
    for (iIndex = 0; iIndex < iLen; iIndex++) {
        sOneChar = InValidCharsIn.charAt(iIndex);
        if (sResult.indexOf(sOneChar) > -1) {
            sMsg = sMsg + DisplayInvalidChar(sOneChar);
        }
    }

    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }

    // if ever we want to replace illegal chars...
    //sResult = sResult.replace(/\</g,"*less than*");
}
// chk Swift allows 2 more chars than chkAlphaNumericPunct
//		- the opening and closing braces
function chkSwift(field, sDescription) {
    var sValidChars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-?:().,'+ \n\r";
    var sMsg = "";

    sMsg = FindInvalidChars(field, sValidChars);
    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following swift disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }
}

function chkAlphaNumericPunct(field, sDescription) {
    var sValidChars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-?:().,'+ ";
    var sMsg = "";

    sMsg = FindInvalidChars(field, sValidChars);
    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }
}

function chkAlphaNumeric(field, sDescription) {
    var sValidChars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
    var sMsg = "";

    sMsg = FindInvalidChars(field, sValidChars);
    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }
}

function DisplayInvalidChar(sThisChar) {
    var sResult = "";

    switch (sThisChar) {
        case "\t":
            sResult = "\t'(tab)" + "'\n";
            break;
        case '"':
            sResult = "\t'(quote)" + "'\n";
            break;
        default:
            sResult = "\t'" + sThisChar + "'\n";
            break;
    }

    return sResult;
}

//*****************************************************************************
// This function is used to validate the data in single-line text fields.
// It uses the 'positive' approach, that is, it checks every character in the
// text data against a list of valid characters. Since this is only used for
// single-line text fields, the performance penalty shouldn't be too high.
//*****************************************************************************
function FindInvalidChars(field, sValidChars) {
    var sString = field.value;
    var iLen = 0;
    var iIndex = 0;
    var sOneChar = "";
    var sResult = "";

    iLen = sString.length;
    for (iIndex = 0; iIndex < iLen; iIndex++) {
        sOneChar = sString.charAt(iIndex);
        if (sValidChars.indexOf(sOneChar) === -1) {
            sResult = sResult + DisplayInvalidChar(sOneChar);
        }
    }

    return sResult;
}

//*****************************************************************************
// This function is used to validate the data in multi-line text fields.
// It uses the 'negative' approach, that is, it checks against a list of
// invalid characters.  It checks only for the existence of one of each of the
// invalid characters, so this should hopefully be faster than the 'positive'
// routines which have to check every character in the data for the existence
// of characters that are not in the valid set.
//*****************************************************************************
function chkTextArea(field, sDescription) {
    var sResult = "";
    var iIndex = 0;
    var iLen = 0;
    var sInvalidChars = '<>%"';
    var sMsg = "";
    var sOneChar = "";

    sResult = field.value;

    iLen = sInvalidChars.length;
    for (iIndex = 0; iIndex < iLen; iIndex++) {
        sOneChar = sInvalidChars.charAt(iIndex);
        if (sResult.indexOf(sOneChar) > -1) {
            sMsg = sMsg + DisplayInvalidChar(sOneChar);
        }
    }

    if (sMsg !== "") {
        sMsg =
            "The " +
            sDescription +
            " data includes the following disallowed character(s):\n" +
            sMsg +
            "\n Please replace these before continuing.";
        alert(sMsg);
        field.focus();
        return false;
    } else {
        return true;
    }

    // if ever we want to replace illegal chars...
    //sResult = sResult.replace(/\</g,"*less than*");
}

//***********************************************************
//***********************************************************
function chkDigitsOnly(field, iDigitsAllowed, Description) {
    var sResult = "";
    var iLen = 0;
    var iPos = 0;
    var sTemp = "";
    var sOneChar = "";

    //-----------------------------------------------------------------------
    //-----------------------------------------------------------------------
    sTemp = field.value;

    //--------------------------------------------------------------------------
    // If we have some data, validate it
    //--------------------------------------------------------------------------
    iLen = sTemp.length;
    if (iLen > 0) {
        //-----------------------------------------------------------------------
        // Parse the numeric string and make sure we have all valid characters.
        //-----------------------------------------------------------------------
        for (iPos = 0; iPos < iLen; iPos++) {
            sOneChar = sTemp.charAt(iPos);
            switch (sOneChar) {
                default:
                    if (sOneChar < "0" || sOneChar > "9") {
                        alert("'" + sOneChar + "' is an invalid numeric character.");
                        field.focus();
                        return false;
                    }
                    break;
            }
        }

        //-----------------------------------------------------------------------
        // Validate the number of significant digits and the number of decimal
        // places.
        //-----------------------------------------------------------------------
        if (iLen > iDigitsAllowed) {
            alert(
                Description +
                " is limited to " +
                iDigitsAllowed +
                " digits, you have entered " +
                iLen +
                "."
            );
            field.focus();
            return false;
        }
    }
    sResult = sTemp;
    field.value = sResult;
    return true;
}

function chkNumber(field, iSigDigitsAllowed, iDecimalsAllowed, sFormat) {
    var sResult = "";
    var iLen = 0;
    var iPos = 0;
    var sTemp = "";
    var sOneChar = "";
    var iDecimalCount = 0;
    var sDecChar = "";
    var sSigChar = "";
    var iDecimalPlaces = 0;
    var iSigDigits = 0;
    var sDollars = "";
    var sCents = "";

    //-----------------------------------------------------------------------
    // Set up some formatting information
    //-----------------------------------------------------------------------
    if (sFormat === "CD") {
        sDecChar = ".";
        sSigChar = ",";
    } else {
        sDecChar = ",";
        sSigChar = ".";
    }

    //-----------------------------------------------------------------------
    // Remove the commas for 'CD', or the decimal points (for 'DC').  This
    // just makes things easier.  We'll put 'em back later.
    //-----------------------------------------------------------------------
    sTemp = field.value;
    sTemp = ReplaceChar(sTemp, sSigChar, "");

    //--------------------------------------------------------------------------
    // If we have some data, validate it
    //--------------------------------------------------------------------------
    iLen = sTemp.length;
    if (iLen > 0) {
        //-----------------------------------------------------------------------
        // Parse the numeric string and make sure we have all valid characters.
        //-----------------------------------------------------------------------
        for (iPos = 0; iPos < iLen; iPos++) {
            sOneChar = sTemp.charAt(iPos);
            switch (sOneChar) {
                case ".":
                    if (sFormat === "CD") {
                        iDecimalCount++;
                    }
                    break;

                case ",":
                    if (sFormat === "DC") {
                        iDecimalCount++;
                    }
                    break;

                default:
                    if (sOneChar < "0" || sOneChar > "9") {
                        alert("'" + sOneChar + "' is an invalid numeric character.");
                        field.focus();
                        return false;
                    }
                    break;
            }
        }

        //-----------------------------------------------------------------------
        // Prevent too many decimal points error
        //-----------------------------------------------------------------------
        if (iDecimalCount > 1) {
            alert(
                "Invalid amount, this numeric value is limited to 1 decimal point, you have entered " +
                iDecimalCount +
                "."
            );
            field.focus();
            return false;
        }

        //-----------------------------------------------------------------------
        // At this point our result should be all digits and maybe a single
        // decimal point.  Break the number into 2 pieces and determine the
        // length of each.
        //-----------------------------------------------------------------------
        iPos = sTemp.indexOf(sDecChar, 0);
        if (iPos > -1) {
            sDollars = sTemp.substring(0, iPos);
            sCents = sTemp.substring(iPos + 1, sTemp.length);
        } else {
            sDollars = sTemp;
            sCents = "";
        }

        iDecimalPlaces = sCents.length;
        iSigDigits = sDollars.length;

        //-----------------------------------------------------------------------
        // Validate the number of significant digits and the number of decimal
        // places.
        //-----------------------------------------------------------------------
        if (iDecimalPlaces > iDecimalsAllowed) {
            alert(
                "Invalid amount, this numeric value is limited to " +
                iDecimalsAllowed +
                " decimal places, you have entered " +
                iDecimalPlaces +
                "."
            );
            field.focus();
            return false;
        }

        if (iSigDigits > iSigDigitsAllowed) {
            alert(
                "Invalid amount, this numeric value is limited to " +
                iSigDigitsAllowed +
                " significant digits, you have entered " +
                iSigDigits +
                "."
            );
            field.focus();
            return false;
        }

        //-----------------------------------------------------------------------
        // Re-format the result
        // add any zeroes needed to fill out the decimal places
        //-----------------------------------------------------------------------
        if (iDecimalsAllowed > 0)
            sResult = CommaPlacer(sDollars, sSigChar) + sDecChar + sCents;
        else sResult = CommaPlacer(sDollars, sSigChar);

        for (iPos = iDecimalPlaces; iPos < iDecimalsAllowed; iPos++) {
            sResult = sResult + "0";
        }
    }

    field.value = sResult;
    return true;
}

//Replaces one char with another
function ReplaceChar(sValue, sChar, sWithChar) {
    var i = 0;
    var sNewValue = "";

    for (i = 0; i < sValue.length; i++) {
        if (sValue.charAt(i) === sChar) {
            sNewValue = sNewValue + sWithChar;
        } else {
            sNewValue = sNewValue + sValue.charAt(i);
        }
    }

    return sNewValue;
}

function CommaPlacer(sDollars, cPlaceHolder) {
    var i = 0;
    var strValue = "";
    var iCount = 0;

    //places the comma
    for (i = sDollars.length; i > -1; i--) {
        iCount++;
        if (iCount > 3) {
            strValue = cPlaceHolder + sDollars.charAt(i) + strValue;
            iCount = 1;
        } else {
            strValue = sDollars.charAt(i) + strValue;
        }
    }

    if (strValue.charAt(0) === cPlaceHolder) {
        strValue = strValue.substring(1);
    }

    return strValue;
}
//this function works to prevent further user input once the upper limits have been reached
function CheckCharacters(textBx, columns, rows) {
    var currentCharCount;
    var maxCharCount;
    var button = event.KeyCode || event.Key || event.which;
    var linesUsed = 0;
    var linesLeft;

    maxCharCount = columns * rows;
    currentCharCount = textBx.value.length;
    if (currentCharCount >= maxCharCount) {
        event.preventDefault();
    }
    lineHeight = parseInt(getComputedStyle(textBx).lineHeight, 10);
    linesUsed = parseInt(textBx.scrollHeight / lineHeight);
    linesLeft = rows - linesUsed

    if (button == 13 && linesUsed == rows) {
        event.preventDefault();
    }
    if (linesLeft < 0) {
        event.preventDefault();
    }
}
function CalculateTextAreaRows(textArea, labelOut, columns, rows) {
    var textAreaRows;
    var textAreaCols;
    var maxCharacters;
    var charsLeft;
    var lineHeight;

    textAreaCols = columns;
    textAreaRows = rows;
    maxCharacters = textAreaRows * textAreaCols;
    lineHeight = parseInt(getComputedStyle(textArea).lineHeight, 10);

    charsLeft = CountCharacters();
    linesLeft = CountRows(textArea);

    textOut = "Text area " + textAreaRows + "x" + textAreaCols + " (" + maxCharacters + " characters). " + linesLeft + " row(s) left, " + charsLeft + " characters available.";
    labelOut.innerText = textOut;
    textOut = "";
    //this function seeks to updated the label with the current rows and characters
    function CountCharacters() {
        var currCharacters;

        currCharacters = textArea.value.length;

        if (currCharacters > maxCharacters) {
            return 0;
        } else {
            return maxCharacters - currCharacters;
        }
    }

    function CountRows(textArea) {
        var characters;
        var cols;
        var rows;
        var currentRows;
        var remainingRows;

        ResizeRows(textArea);

        characters = textArea.value.length;
        currentRows = textAreaRowsUsed(lineHeight)

        if (characters == 0) {
            currentRows = 0;
        }
        remainingRows = textAreaRows - currentRows;

        return remainingRows;
    }

    function ResizeRows(textArea) {
        var rows = textArea.rows;

        // Size the Text Area for rows
        var elem = textArea;
        if (elem.offsetHeight != 0) {
            while (rows > 1 && elem.scrollHeight < elem.offsetHeight) {
                rows--;
                textArea.rows = rows;
            }
            while (elem.scrollHeight > elem.offsetHeight) {
                rows++;
                textArea.rows = rows;
            }
        }
    }
    function textAreaRowsUsed(lineHeight) {
        return parseInt(textArea.scrollHeight / lineHeight);
    }
}
function isNumberKey(pressedKey) {
    var charCode = (pressedKey.which) ? pressedKey.which : pressedKey.keyCode;
    if (charCode != 46 && charCode != 36 && charCode > 31 &&  (charCode < 48 || charCode > 57)) {
        return event.preventDefault();
    }
    else {
        return true;
    }
}
function ToggleControlUsability(definingControl, targetControl, valueToCheck) {
    var controlValue = definingControl.value
    if (controlValue == valueToCheck) {
        targetControl.disabled = false;
    } else {
        targetControl.disabled = true;
        targetControl.value = '';
    }
}