﻿using System;
using Dbio;
using ADO2NET;
using System.Data;
using System.IO;

namespace SubmitPaymentAPI
{
    public class TableAccess : ITableAccess
    {
		private StreamWriter logfile;
		private readonly cDbioRd reader;
		private readonly cDbioWr writer;
		
		public TableAccess(StreamWriter lf)
        {
			logfile = lf;
			reader = new cDbioRd();
			writer = new cDbioWr();
		}

        public DataTable ReadSingleFromFedTable()
        {
			//UETR will be empty on the record initially, use the UETR from the response to populate
            string sqlCommand = @"
                Select TOP 1
					--WireIds
					F.Pkey as senderReferenceNumber,
					F.UETR,
					--base WireData
					F.Amount as Amount,
					'USD' as Currency,
					(Select FedBatchSequencer from ParmsGTS) as transactionIdentification,
					'FED' as transactionType,
					--OtherTransactionDates
					F.DebitCreditFlag, 
					F.ValueDate,
					--CreditTransferTransactionInformation
					F.Amount as InstructedAmount,
					'USD' as InstructedCurrCode,
					--RemittanceData
					CONCAT(Details1, ' ', Details2, ' ',Details3, ' ',Details4) as RemittanceData,
					--Initiation
					--Debtor
					9870336010 as DebtorAcctId,
					004 as DebtorAcctScheme,
					'GLA' as DebtorAcctTypeCode,
					--Creditor Account
					F.BeneBankAcctNum as CredAcctOtherId,
					--Creditor Party Lookup
					F.BeneficiaryBankName as CredName,
						--PostalAddr
						--Unstructured
						Creditor.Address1 as creditorAddress1, 
						Creditor.Address2 as creditorAddress2,  
						Creditor.Address3 as creditorAddress3, 
						Creditor.CountryDomicile as creditorCountryDom, 
						--Structured
						Creditor.ISO_townName as creditorTownName, 
						Creditor.ISO_country as creditorCountry,
						Creditor.ISO_postalCode as creditorPostalCode, 
						Creditor.ISO_department as creditorDepartment, 
						Creditor.ISO_subDepartment as creditorSubDepartment, 
						Creditor.ISO_streetName as creditorStreetName, 
						Creditor.ISO_buildingNumber as creditorBuildingNumber, 
						Creditor.ISO_buildingName as creditorBuildingName, 
						Creditor.ISO_floor as creditorFloor, 
						Creditor.ISO_postalBox as creditorPostalBox,
						Creditor.ISO_room as creditorRoom, 
						Creditor.ISO_townLocation as creditorTownLocation, 
						Creditor.ISO_districtName as creditorDistrictName, 
						Creditor.ISO_countrySubDivision as creditorCountrySubDivision,
					--CreditorAgent Lookup
					F.RecvBankABA as creditorAgtMemberId,
					'USABA' as creditorAgtClearingSystemIdCode,
					F.ReceivingBankName as creditorAgtName,
						--PostalAddr
						--Unstructured
						CreditorAgent.Address1 as creditorAgtAddress1, 
						CreditorAgent.Address2 as creditorAgtAddress2,  
						CreditorAgent.Address3 as creditorAgtAddress3, 
						CreditorAgent.CountryDomicile as creditorAgtCountryDom, 
						--Structured
						CreditorAgent.ISO_townName as creditorAgtTownName, 
						CreditorAgent.ISO_country as creditorAgtCountry,
						CreditorAgent.ISO_postalCode as creditorAgtPostalCode, 
						CreditorAgent.ISO_department as creditorAgtDepartment, 
						CreditorAgent.ISO_subDepartment as creditorAgtSubDepartment, 
						CreditorAgent.ISO_streetName as creditorAgtStreetName, 
						CreditorAgent.ISO_buildingNumber as creditorAgtBuildingNumber, 
						CreditorAgent.ISO_buildingName as creditorAgtBuildingName, 
						CreditorAgent.ISO_floor as creditorAgtFloor, 
						CreditorAgent.ISO_postalBox as creditorAgtPostalBox,
						CreditorAgent.ISO_room as creditorAgtRoom, 
						CreditorAgent.ISO_townLocation as creditorAgtTownLocation, 
						CreditorAgent.ISO_districtName as creditorAgtDistrictName, 
						CreditorAgent.ISO_countrySubDivision as creditorAgtCountrySubDivision
				FROM FED F
					LEFT JOIN Party Creditor
						ON Creditor.Pkey = F.PartyPkey
					LEFT JOIN Party CreditorAgent
						ON CreditorAgent.Pkey = F.RecBank
				WHERE 
					F.Mtstatus = 0
					AND F.DatePassed = '01/01/1900'
					AND F.ApprovalDate <> '01/01/1900'
					AND F.TransPkey NOT IN (SELECT Pkey FROM WipItems WHERE WipStatus IN ('RCAL', 'NPRC'))
				ORDER BY Valuedate
            ";

			Recordset rs = new ADO2NET.Recordset();
			reader.ExecuteReadSql(sqlCommand, ref rs);
			return rs.DataTable;
        }

		public Tuple<bool, bool> CheckAddressRequirements()
        { 
			//Assuming only one record in DB instance, but using TOP 1 just in case
			string sqlCommand = "SELECT TOP 1 RequireStructuredAddress, SendUnstructuredAddress FROM ParmsLE";
			Recordset rs = new ADO2NET.Recordset();
			reader.ExecuteReadSql(sqlCommand, ref rs);
			DataTable table = rs.DataTable;
			bool requireStructBit = table.Rows[0]["RequireStructuredAddress"].ToString() == "True";
			bool sendUnstructuredBit = table.Rows[0]["SendUnstructuredAddress"].ToString() == "True";

			return new Tuple<bool, bool>(requireStructBit, sendUnstructuredBit);
		}

		public void IncrementFedSequence()
        {
			string sqlCommand = "UPDATE ParmsGTS SET FedBatchSequencer = (SELECT FedBatchSequencer+1 FROM ParmsGTS)";
			ErrReporter.cReporter.ErrorReturned err = writer.ExecuteWriteSql(sqlCommand);
			if (err != 0)
			{
				logfile.WriteLine($"A [{err}] error occured when incrementing the FedBatchSequencer");
			}
		}

		public void UpdateFedRecord(string pkey, string status, string uetr)
        {
			string sqlCommand = $"UPDATE FED SET Mtstatus = {status}, UETR = '{uetr}' WHERE Pkey = {pkey}";
			ErrReporter.cReporter.ErrorReturned err = writer.ExecuteWriteSql(sqlCommand);
			if (err != 0)
			{
				throw new TableAccessException($"A [{err}] error occured when updating FED record [UETR: {uetr}]");
			}
		}

		public void AddRelatedReference(string pkey, string status, DateTime timeSent)
        {
			string sqlCommand = $@"
				INSERT INTO RelatedReferences
					SELECT 
						TransPkey, PrimaryPkey, WhichSystem, UETR as RelatedReference, 
						'FED' as Receiver, 'FED' as MsgVia, Amount, Mtstatus, Pkey as OutboundPkey, 
						'{timeSent}' as TransmissionDateTime, '{status}' as ResponseText 
					FROM FED WHERE Pkey = {pkey}
			";
			ErrReporter.cReporter.ErrorReturned err = writer.ExecuteWriteSql(sqlCommand);
			if (err != 0)
			{
				throw new TableAccessException($"A [{err}] error occured when adding a RelatedReferences record for [pkey: {pkey}]");
			}
		}

		[Obsolete("ReadAllFromFedTable is preferred for automatic fedSequence - needs an update")]
		public DataTable ReadAllFromFedTable()
		{
			//UETR will be empty on the record initially, use the UETR from the response to populate
			string sqlCommand = @"
                Select
					--WireIds
					F.Pkey as senderReferenceNumber,
					F.UETR,
					--base WireData
					F.Amount as Amount,
					'USD' as Currency,
					(Select FedBatchSequencer from ParmsGTS) + ROW_NUMBER() OVER(ORDER BY F.ValueDate) as transactionIdentification,
					'FED' as transactionType,
					--OtherTransactionDates
					F.DebitCreditFlag, 
					F.ValueDate,
					--CreditTransferTransactionInformation
					F.Amount as InstructedAmount,
					'USD' as InstructedCurrCode,
					--RemittanceData
					CONCAT(Details1, ' ', Details2, ' ',Details3, ' ',Details4) as RemittanceData,
					--Initiation
					--Debtor
					9870336010 as DebtorAcctId,
					004 as DebtorAcctScheme,
					'GLA' as DebtorAcctTypeCode,
					--Creditor Account
					F.BeneBankAcctNum as CredAcctOtherId,
					--Creditor Party Lookup
					F.BeneficiaryBankName as CredName,
						--PostalAddr
						--Unstructured
						Creditor.Address1 as creditorAddress1, 
						Creditor.Address2 as creditorAddress2,  
						Creditor.Address3 as creditorAddress3, 
						Creditor.CountryDomicile as creditorCountryDom, 
						--Structured
						Creditor.ISO_townName as creditorTownName, 
						Creditor.ISO_country as creditorCountry,
						Creditor.ISO_postalCode as creditorPostalCode, 
						Creditor.ISO_department as creditorDepartment, 
						Creditor.ISO_subDepartment as creditorSubDepartment, 
						Creditor.ISO_streetName as creditorStreetName, 
						Creditor.ISO_buildingNumber as creditorBuildingNumber, 
						Creditor.ISO_buildingName as creditorBuildingName, 
						Creditor.ISO_floor as creditorFloor, 
						Creditor.ISO_postalBox as creditorPostalBox,
						Creditor.ISO_room as creditorRoom, 
						Creditor.ISO_townLocation as creditorTownLocation, 
						Creditor.ISO_districtName as creditorDistrictName, 
						Creditor.ISO_countrySubDivision as creditorCountrySubDivision,
					--CreditorAgent Lookup
					F.RecvBankABA as creditorAgtMemberId,
					'USABA' as creditorAgtClearingSystemIdCode,
					F.ReceivingBankName as creditorAgtName,
						--PostalAddr
						--Unstructured
						CreditorAgent.Address1 as creditorAgtAddress1, 
						CreditorAgent.Address2 as creditorAgtAddress2,  
						CreditorAgent.Address3 as creditorAgtAddress3, 
						CreditorAgent.CountryDomicile as creditorAgtCountryDom, 
						--Structured
						CreditorAgent.ISO_townName as creditorAgtTownName, 
						CreditorAgent.ISO_country as creditorAgtCountry,
						CreditorAgent.ISO_postalCode as creditorAgtPostalCode, 
						CreditorAgent.ISO_department as creditorAgtDepartment, 
						CreditorAgent.ISO_subDepartment as creditorAgtSubDepartment, 
						CreditorAgent.ISO_streetName as creditorAgtStreetName, 
						CreditorAgent.ISO_buildingNumber as creditorAgtBuildingNumber, 
						CreditorAgent.ISO_buildingName as creditorAgtBuildingName, 
						CreditorAgent.ISO_floor as creditorAgtFloor, 
						CreditorAgent.ISO_postalBox as creditorAgtPostalBox,
						CreditorAgent.ISO_room as creditorAgtRoom, 
						CreditorAgent.ISO_townLocation as creditorAgtTownLocation, 
						CreditorAgent.ISO_districtName as creditorAgtDistrictName, 
						CreditorAgent.ISO_countrySubDivision as creditorAgtCountrySubDivision
				FROM FED F
					LEFT JOIN Party Creditor
						ON Creditor.Pkey = F.PartyPkey
					LEFT JOIN Party CreditorAgent
						ON CreditorAgent.Pkey = F.RecBank
				WHERE 
					F.Mtstatus = 0
				ORDER BY Valuedate
            ";

			Recordset rs = new ADO2NET.Recordset();
			reader.ExecuteReadSql(sqlCommand, ref rs);
			return rs.DataTable;
		}

	}

	public class TableAccessException : Exception
	{
		public TableAccessException(string msg) : base(msg) { }
	}
}