﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace SubmitPaymentAPI
{
    //Class that we'll use to decrypt the stored password
    public class PWDecrypt
    {
        //this is the phrase that we use to generate the key that we'll use to encrypt and decrypt the password.
        private readonly static string keyBase = "UZsgsKgs9HA0kDk2nis77N";//"V7nfCSsOcuPdCHEsHdlOPr";
        private const int keySize = 256;
        private const int blockSize = 128;

        public static string DecryptPassword(string cipherText)
        {
            //return our encrypted password back to bytes
            byte[] encryptedTextBytes = Convert.FromBase64String(cipherText);

            //generate our key again
            PasswordDeriveBytes passKey = new PasswordDeriveBytes(keyBase, null);
            RijndaelManaged aesDecrypt = new RijndaelManaged
            {

                //create our key and Initialization Vector (IV) that we used when we encrypted the password
                Key = passKey.GetBytes(keySize / 8),
                IV = passKey.GetBytes(blockSize / 8),
                Mode = CipherMode.CBC,
                Padding = PaddingMode.PKCS7
            };

            //create the encryptor, memorystream, and crypotstream
            ICryptoTransform decryptor = aesDecrypt.CreateDecryptor(aesDecrypt.Key, aesDecrypt.IV);
            MemoryStream msDecrypt = new MemoryStream(encryptedTextBytes);
            CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read);

            //Decrypt the bytes
            byte[] plainTextBytes = new byte[encryptedTextBytes.Length];
            _ = csDecrypt.Read(plainTextBytes, 0, plainTextBytes.Length);

            // close all of our current open objects
            msDecrypt.Close();
            csDecrypt.Close();

            //return our newly decrypted password in plain text
            return Encoding.UTF8.GetString(plainTextBytes, 0, 9);
        }
    }
}