﻿using System;
using System.Configuration;
using System.Data;
using System.Xml;

namespace SubmitPaymentAPI
{
    public class WiresConfig
    {
        // Name of service
        public string GTSServicename { get; set; }

        // Enable Logging
        public string Logging { get; set; }

        // Time to wait between requests
        public string  TimerInterval { get; set; }

        // MalCode used by the API
        public string ApplicationCode { get; set; }

        // Url for calling the PingFed API
        public string PingFedURL { get; set; }

        // Password for calling the PingFed API
        public string PingFedPassword { get; set; }

        // Url for calling SubmitPayment
        public string SubmitPaymentURL { get; set; }

        // Maximum number of alerts to send before quitting the service
        public string MaximumAlerts { get; set; }

        // All items must be string in order to set up the logger
        // Using these gets to convert values in program
        public int GetMaximumAlerts()
        {
            return int.Parse(MaximumAlerts);
        }

        public int GetTimerInterval()
        {
            return int.Parse(TimerInterval);
        }

        public string GetPingFedPassword()
        {
            return PWDecrypt.DecryptPassword(PingFedPassword);
        }

        public bool GetLogging()
        {
            return Logging == "Y";
        }
    }
} 