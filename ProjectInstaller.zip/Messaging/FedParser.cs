﻿using System;
using System.Data;

namespace SubmitPaymentAPI
{
    public class FedParser
    {
        private DataTable record;
        bool RequreStrucutredAddress;
        
        //Setting it here, I don't see why this is needed
        bool SendUnstructuredAddress;

        public FedParser(Tuple<bool, bool> settings)
        {
            RequreStrucutredAddress = settings.Item1;
            SendUnstructuredAddress = settings.Item2;
        }

        private string Read(string col)
        {
            string val = record.Rows[0][col].ToString();
            if (val == "" || val == null) return null;
            return val;
        }

        private string PrependZeros(string value, int size)
        {
            int paddingSize = size - value.Length;
            string padding = new string('0', paddingSize);
            return padding + value;
        }

        public SubmitPaymentRequest Parse(DataTable dt)
        {
            this.record = dt;

            RequestBuilder builder = new RequestBuilder();
            //BaseWireData needs to be first! Otherwise you get a Null Reference
            builder.AddBaseWireData(Read("Amount"), Read("Currency"), Read("transactionIdentification"))
                .AddWireIds(Read("senderReferenceNumber"), Read("uetr"))
                .AddOtherTransactionDates(Read("DebitCreditFlag"), Read("ValueDate"))
                .AddCreditTransferTransactionInformation(Read("InstructedAmount"), Read("InstructedCurrCode"))
                .AddInitiation("FED")
                .AddOtherDebtorAccount(Read("DebtorAcctId"), PrependZeros(Read("DebtorAcctScheme"), 3), Read("DebtorAcctTypeCode"))
                .AddOtherCreditorAccount(Read("CredAcctOtherId") ?? " ")
                .AddCreditor(Read("CredName"), ReadPostalAddress("creditor"))
                .AddCreditorAgent(ReadFinancialInstitutionIdWithNameAndAddress("creditorAgt"));
            
            string remittance = Read("RemittanceData");
            if (remittance != null || !"".Equals(remittance)) {
                builder.AddRemittanceData(Read("RemittanceData"));
            }

            return builder.Build();
        }


        private FinancialInstitutionIdWithNameAndAddress ReadFinancialInstitutionIdWithNameAndAddress(string prefix)
        {
            PostalAddress pa = ReadPostalAddress(prefix);

            if (Read(prefix + "MemberId") != null)
            {
                return new FinancialInstitutionIdWithNameAndAddress_clear(Read(prefix + "MemberId"), Read(prefix + "ClearingSystemIdCode"), Read(prefix + "Name"), pa);
            }
            else if (Read(prefix + "Bic") != null)
            {
                return new FinancialInstitutionIdWithNameAndAddress_bic(Read(prefix + "Bic"), Read(prefix + "Name"), pa);
            }
            else
            {
                return null;
            }
        }

        private PostalAddress ReadPostalAddress(string prefix) 
        {
            PostalAddress pa = null;
            if (Read(prefix + "TownName") != null)
            {
                pa = new PostalAddress(
                    Read(prefix + "TownName") ?? " ",
                    Read(prefix + "Country") ?? " ",
                    Read(prefix + "PostalCode") ?? " ",
                    Read(prefix + "Department") ?? " ",
                    Read(prefix + "SubDepartment") ?? " ",
                    Read(prefix + "StreetName") ?? " ",
                    Read(prefix + "BuildingNumber") ?? " ",
                    Read(prefix + "BuildingName") ?? " ",
                    Read(prefix + "Floor") ?? " ",
                    Read(prefix + "PostalBox") ?? " ",
                    Read(prefix + "Room") ?? " ",
                    Read(prefix + "TownLocation") ?? " ",
                    Read(prefix + "DistrictName") ?? " ",
                    Read(prefix + "CountrySubDivision") ?? " "
                    );
            }
            else if (Read(prefix + "Address1") != null)
            {
                string[] addrLine = {
                        Read(prefix + "Address1") ?? " ",
                        Read(prefix + "Address2") ?? " ",
                        Read(prefix + "Address3") ?? " "
                    };
                //Default to US?
                if (Read(prefix + "CountryDom") != null)
                {
                    pa = new PostalAddress(addrLine, Read(prefix + "CountryDom"));
                }
                else
                {
                    pa = new PostalAddress(addrLine, " ");
                }
                if (RequreStrucutredAddress)
                {
                    throw new FedParserException($"The address for record [{Read("senderReferenceNumber")}] requires a strucure, but it has none");
                }
            }
            return pa;
        }

        [Obsolete("Using the smaller version of the parser based on the design, keeping in case the design expands")]
        public SubmitPaymentRequest ParseFullRecord(DataTable dt)
        {
            this.record = dt;

            RequestBuilder builder = new RequestBuilder();
            builder.AddBaseWireData(Read("Amount"), Read("Currency"), Read("transactionIdentification"), Read("exchangeRate"), Read("fxContractNumber"));
            builder.AddWireIds(Read("senderReferenceNumber"), Read("UETR"));
            builder.AddOtherTransactionDates(Read("DebitCreditFlag"), Read("ValueDate"));
            builder.AddClearingAndSettlement(Read("localInstrumentProprietary"))
                .AddCreditTransferTransactionInformation(Read("interBankSettlementAmount"), Read("interBankSettlementCurrency"));

            if (Read("chargeBearer") != null && Read("chargeInfoAmount") != null)
            {
                builder.AddChargesInfo(Read("chargeBearer"), Read("chargeInfoAmount"));

            }
            if (Read("creditAcctStr") != null && Read("creditAcctType") != null && Read("creditOffice") != null)
            {
                builder.AddCreditAccount(Read("creditAcctStr"), Read("creditAcctType"), Read("creditOffice"));
            }
            if (Read("instructingAgtBic") != null || (Read("instructingAgtMemberId") != null && Read("instructingAgtSysCode") != null))
            {
                if (Read("instructingAgtBic") != null)
                {
                    builder.AddInstructingAgent(Read("instructingAgtBic"));
                }
                else
                {
                    builder.AddInstructingAgent(Read("instructingAgtMemberId")/*RecvBankABA*/, Read("instructingAgtSysCode"));
                }

            }
            if (Read("instructedAgtBic") != null || (Read("instructedAgtMemberId") != null && Read("instructedAgtSysCode") != null)) // if InstructedAgent Exists
            {

                if (Read("instructedAgtBic") != null)
                {
                    builder.AddInstructedAgent(Read("instructedAgtBic"));
                }
                else
                {

                    builder.AddInstructedAgent(Read("instructedAgtMemberId")/*RecvBankABA*/, Read("instructedAgtSysCode"));
                }
            }
            if (Read("interAgt1Bic") != null || (Read("interAgt1MemberId") != null && Read("interAgt1SysCode") != null))
            {
                PostalAddress pa = ReadPostalAddress("interAgt1");

                if (Read("interAgt1Bic") != null)
                {
                    builder.AddIntermediaryAgent1(Read("interAgt1Bic"), Read("interAgt1Name"), pa);
                }
                else
                {
                    builder.AddIntermediaryAgent1(Read("interAgt1MemId")/*RecvBankABA*/, Read("interAgt1Name"), pa);
                }
            }
            if (Read("interAgt2Bic") != null || (Read("interAgt2MemberId") != null && Read("interAgt2SysCode") != null))
            {
                PostalAddress pa = ReadPostalAddress("interAgt2");

                if (Read("interAgt2Bic") != null)
                {
                    builder.AddIntermediaryAgent1(Read("interAgt2Bic"), Read("interAgt2Name"), pa);
                }
                else
                {
                    builder.AddIntermediaryAgent1(Read("interAgt2MemId")/*RecvBankABA*/, Read("interAgt2Name"), pa);
                }
            }
            if (Read("interAgt3Bic") != null || (Read("interAgt3MemberId") != null && Read("interAgt3SysCode") != null))
            {
                PostalAddress pa = ReadPostalAddress("interAgt3");

                if (Read("interAgt3Bic") != null)
                {
                    builder.AddIntermediaryAgent1(Read("interAgt3Bic"), Read("interAgt3Name"), pa);
                }
                else
                {
                    builder.AddIntermediaryAgent1(Read("interAgt3MemId")/*RecvBankABA*/, Read("interAgt3Name"), pa);
                }
            }

            builder.AddInitiation(Read("initiatingChannel"), Read("initiatingPartyName"), Read("creditorAgentAccountId"))
                .AddCreditor(Read("BeneName"), ReadPostalAddress("creditor"))
                .AddCreditorAgent(ReadFinancialInstitutionIdWithNameAndAddress("cAgt"), Read("cAgtBranchId"), Read("cAgtInstruction").Split(';')); // may need to revisit

            //Required
            if (Read("debtorIban") != null)
            {
                builder.AddIbanDebtorAccount(Read("debtorIban"), Read("debtorType"));
            }
            else
            {
                builder.AddOtherDebtorAccount(Read("debtorId"), Read("debtorScheme"), Read("debtorType"));
            }

            if (Read("creditorIban") != null || Read("creditorId") != null)
            {
                if (Read("creditorIban") != null)
                {
                    builder.AddIbanCreditorAccount(Read("creditorIban"), Read("creditorType"));
                }
                else
                {
                    builder.AddIbanCreditorAccount(Read("creditorId"), Read("creditorType"));
                }
            }
            if (Read("debtorName") != null)
            {
                PostalAddress pa = ReadPostalAddress("debtor");
                builder.AddDebtor(Read("debtorName"), pa);
            }
            FinancialInstitutionIdWithNameAndAddress debtorFID = ReadFinancialInstitutionIdWithNameAndAddress("debtorAgt");
            if (debtorFID != null) // if DebtorAgent Exists
            {
                builder.AddDebtorAgent(debtorFID);
            }

            if (Read("remittanceUnstructured") != null || Read("remittanceTaxId") != null)
            {
                if (Read("remittanceUnstructured") != null)
                {
                    builder.AddRemittanceData(Read("remittanceUnstructured"));
                }
                else
                {
                    Record r = builder.BuildTaxRecord(Read("remittanceRecordYear"), Read("remittanceRecordMonth"), Read("remittanceRecordType"), Read("remittanceAddInfo"));
                    TaxCreditor c = new TaxCreditor(Read("remittanceTaxId"), Read("remittanceRegId"));
                    builder.AddRemittanceData(r, c);
                }
            }
            return builder.Build();
        }
    }

    public class FedParserException : Exception
    {
        public FedParserException(string message) : base(message) { }
    }

}
