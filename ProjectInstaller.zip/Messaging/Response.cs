﻿using System.Collections.Generic;

namespace SubmitPaymentAPI
{
    public class Response
    {

    }
    public class Response_Success : Response
    {
        public string senderReferenceNumber { get; set; }
        public string uniqueEndToEndTransactionReference { get; set; }
    }

    public class AdditionalStatus
    {
        public int statusCode { get; set; }
        public string serverStatusCode { get; set; }
        public string severity { get; set; }
        public string statusDesc { get; set; }
    }

    public class Response_Error : Response
    {
        public Status status { get; set; }
    }

    public class Status
    {
        public int serverStatusCode { get; set; }
        public string severity { get; set; }
        public List<AdditionalStatus> additionalStatus { get; set; }
    }
}