﻿using Newtonsoft.Json;

namespace SubmitPaymentAPI
{
    public class MessageGenerator
    {

        JsonSerializer serializer;

        public MessageGenerator()
        {
            serializer = new JsonSerializer();
        }

        public string Generatate(SubmitPaymentRequest request)
        {
            var settings = new JsonSerializerSettings();
            settings.NullValueHandling = NullValueHandling.Ignore;
            string json = JsonConvert.SerializeObject(request, settings);
            return json;
        }
    }
}