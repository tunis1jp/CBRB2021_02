﻿using System;
using System.Data;
using System.IO;
using System.Net.Http;
using System.Threading;

namespace SubmitPaymentAPI
{
    public class Program
    {
        public static StreamWriter logfile;
        public static string Logpath = "";
        public static CibarLogger.cibar_config cf;

        public static void Main()
        {
            try
            {
                //Setting up the logger
                WiresConfig config = new WiresConfig();
                string execname = System.Reflection.Assembly.GetEntryAssembly().GetName().Name;
                cf = new CibarLogger.cibar_config("wires.config", "SubmitPaymentAPI", execname, ref logfile, config);
                logfile.AutoFlush = true;
                cf.daychanged(ref logfile);

                SubmitPayment api = new SubmitPayment(logfile);
                api.Setup(config);
                api.Run(config.GetTimerInterval());
            }
            catch (Exception e)
            {
                logfile.WriteLine($"Unexpected error occurred in the program: {e.Message}");
            }
            logfile.Close();
        }
    }

    public class SubmitPayment
    {
        public static StreamWriter logfile;

        public IErrorHandler eh;
        public ITableAccess ta;
        public APICommands api;

        public SubmitPayment(StreamWriter lf)
        {
            logfile = lf;
        }

        //ITableAccess, IErrorHandler, and HTTPClient are for testing
        public void Setup(WiresConfig wires, ITableAccess tbl = null, IErrorHandler err = null, HttpClient hc = null)
        {
            eh = err ?? new ErrorHandler(wires.GetMaximumAlerts(), logfile);
            ta = tbl ?? new TableAccess(logfile);
            api = new APICommands(wires, ta, eh, logfile, hc);
        }

        public void Run(int sleepTimeInterval)
        {
            //Check for new FED Data
            DataTable record = ta.ReadSingleFromFedTable();
            if (record.Rows.Count == 0) {
                logfile.WriteLine("No pending records found to process.");
                logfile.WriteLine("Exiting service...");
                return;
            }
            //Get the Token for the API
            api.AuthorizeClient();

            //setup the parser with the address settings from ParmsLE
            FedParser dbParser = new FedParser(ta.CheckAddressRequirements());

            while (record.Rows.Count > 0)
            {
                if(api.tWrapper != null && api.tWrapper.IsExpired())
                {
                    logfile.WriteLine("Token has expired. Re-authenticating service.");
                    api.AuthorizeClient();
                }

                if (api.tWrapper == null)
                {
                    //The Authorization failed, quit program
                    return;
                }

                try
                {
                    SubmitPaymentRequest req = dbParser.Parse(record);
                    api.SendPaymentRequest(req);
                } catch(FedParserException e)
                {
                    eh.SendAlert("ParseRecord", e.Message);
                }

                // Sleep for the defined miliseconds between requests
                Thread.Sleep(sleepTimeInterval);

                // Increment the sequence and read the next record
                ta.IncrementFedSequence();
                record = ta.ReadSingleFromFedTable();
            }
            logfile.WriteLine("There are no more pending records available to submit");
            logfile.WriteLine("Exiting service...");
        }
    }
}
