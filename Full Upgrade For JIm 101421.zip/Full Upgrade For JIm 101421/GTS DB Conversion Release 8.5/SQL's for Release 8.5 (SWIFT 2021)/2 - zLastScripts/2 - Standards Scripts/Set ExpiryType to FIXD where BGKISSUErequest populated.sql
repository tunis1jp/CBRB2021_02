update ballocprimary
set ExpiryType = 'FIXD'
where TypeIESRG = 's' and BGIssueRequest <> '' and LiabilityAmountBase > 0
