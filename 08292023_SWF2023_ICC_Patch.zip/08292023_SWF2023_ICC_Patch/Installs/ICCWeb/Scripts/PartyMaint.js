﻿// ***************************************
// Script to manage Party Maintnenace
// ***************************************
function PosCursor(here) {
    here.focus();
}

function CheckDisabled(chk) {
    chk.checked = true
}

function CheckAll(master) {
    var iCnt;
    var checked = master.checked;
    
    chkPartyType = document.getElementsByName("chkPartyType");
	iCnt = chkPartyType.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
        chkPartyType[iIdx].checked = checked;
    }
}

