Update SWFFldRules
set MTTokenDescription = 'Delivery To/Collect By'
where MTTokenID like ':24G%'