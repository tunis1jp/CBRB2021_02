Update CustomScreen
set Length = '70'
where tag = '23x'