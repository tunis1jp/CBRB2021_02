update CustomScreen
set tag = '59' , caption = ':59:Beneficiary:4*35x' 
where tag = '59D' and product = 'MT785freefrm'

update CustomScreen
set BlankTag = '59' 
where blanktag = '59D' and product = 'MT785freefrm'

