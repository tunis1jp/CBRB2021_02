update MemLetterForm
set active = '0' where code like ('%760%')

update MemLetterForm
set active = '0' where code like ('%767%')
