update ParmsGTS set RequireIccSdbTypeImp = 0, RequireIccSdbTypeStb = 1

Update ParmsGTS
set SWIFT2020 = 'Y'
