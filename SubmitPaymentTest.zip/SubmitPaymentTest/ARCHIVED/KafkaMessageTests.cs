﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using Newtonsoft.Json;
using System;

namespace kafka
{

    [TestClass]
    public class KafkaMessageTests
    {
        [TestMethod]
        public void TestDeserJsonMsg()
        {
            string message = File.ReadAllText("..\\..\\resources\\FTRREP_V1.2.1.json");
            KafkaMessage_FTRREP msg = JsonConvert.DeserializeObject<KafkaMessage_FTRREP>(message);
           
        }
    }
}