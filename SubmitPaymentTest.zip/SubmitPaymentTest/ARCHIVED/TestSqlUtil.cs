﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace TDB_SubmitPaymentAPI
{
    public class TestSQLUtil : ISQLUtil
    {
        private List<DataTable> responses = new List<DataTable>();

        public void AddResponse(DataTable table)
        {
            responses.Add(table);
        }

        public int CreateExceptionEntry(Exception exception, string moduleName, string functionName)
        {
            throw new NotImplementedException();
        }

        public DataTable ReturnDatatable(string datatableSQL)
        {
            DataTable response = responses[0];
            responses.Remove(response);
            return response;
        }

        public DataTable ReturnDatatable(string advDatatableSQL, string param)
        {
            DataTable response = responses[0];
            responses.Remove(response);
            return response;
        }

        public int RunAdvancedSqlCommand(string advancedSQL, string[] paramArr)
        {
            throw new NotImplementedException();
        }

        public int RunGenericSqlCommand(string genSQL)
        {
            throw new NotImplementedException();
        }

        public int RunGenericSqlCommand(SqlCommand genSQLCMD)
        {
            throw new NotImplementedException();
        }
    }
}

namespace kafka
{
    public class TestSQLUtil : ISQLUtil
    {
        private List<DataTable> responses = new List<DataTable>();

        public void AddResponse(DataTable table)
        {
            responses.Add(table);
        }

        public int CreateExceptionEntry(Exception exception, string moduleName, string functionName)
        {
            throw new NotImplementedException();
        }

        public DataTable ReturnDatatable(string datatableSQL)
        {
            DataTable response = responses[0];
            responses.Remove(response);
            return response;
        }

        public DataTable ReturnDatatable(string advDatatableSQL, string param)
        {
            DataTable response = responses[0];
            responses.Remove(response);
            return response;
        }

        public int RunAdvancedSqlCommand(string advancedSQL, string[] paramArr)
        {
            throw new NotImplementedException();
        }

        public int RunGenericSqlCommand(string genSQL)
        {
            throw new NotImplementedException();
        }

        public int RunGenericSqlCommand(SqlCommand genSQLCMD)
        {
            throw new NotImplementedException();
        }
    }
}