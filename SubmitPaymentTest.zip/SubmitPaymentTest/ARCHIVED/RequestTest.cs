﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using System;
using System.Collections.Generic;
using System.IO;

namespace TDB_SubmitPaymentAPI.UnitTests
{
    [TestClass]
    public class RequestTest
    {
        private SubmitPaymentRequest SetupRequest()
        {

            RequestBuilder builder = new RequestBuilder();

            //Build
            string[] address = { "79, Wellington Street" };
            string[] inst = { "BY67TU908781" };
            PostalAddress initCredPA = builder.BuildPostalAddress(address);
            PostalAddress debtorPA = builder.BuildPostalAddress(address, "CA");
            FinancialInstitutionIdWithNameAndAddress initCredAgent =
                builder.BuildFinancialInstitutionIdWithNameAndAddress("0000AA00", "Tod James", initCredPA);
            PostalAddress structPA =
                builder.BuildPostalAddress("Toronto", "CA", "L6X2Y9", "Wires", "Wires-SubDepartment", "123, Fake Street",
                "123", "BuildingName", "12", "L6X2Y9", "12", "Toronto", "Distillery", "Ontario");

            // Assemble Base
            builder.AddBaseWireData("100000.99", "USD", "123456789", "1.2333539999", "123456789");
            builder.AddWireIds("ba1cf2244-960", "400fa879-5a4a-4c81-ae48-09ad12d01afa", "066532289");

            //Assemble Clearing And Settlement
            builder.AddOtherTransactionDates("D", "2033-11-05T13:15:30.123456789Z");
            builder.AddClearingAndSettlement("CTRC")
                .AddCreditTransferTransactionInformation("100000.99", "USD");

            //Optional - Clearing And Settlement
            builder.AddChargesInfo("DEBT", "100000.99");
            builder.AddCreditAccount("ACCTSTR", "DDA", "999");
            builder.AddInstructingAgent("0000AA00");
            builder.AddInstructedAgent("0000AA00");
            builder.AddIntermediaryAgent1("0000AA00", "Tod James", initCredPA);
            builder.AddIntermediaryAgent2("0000AA00", "Tod James", structPA);
            builder.AddIntermediaryAgent3("0000AA00", "Tod James", structPA);

            //Assemble - Initiation
            builder.AddInitiation("SFT", "Tod James", "ABCD123")
                .AddCreditor("Tod James", debtorPA)
                .AddCreditorAgent(initCredAgent, "ABCD123", inst)
                .AddOtherDebtorAccount("ABCD123", "999", "DDA");

            //Optional - Initiation
            builder.AddIbanCreditorAccount("FR7630006000011234567890189", "DDA");
            builder.AddDebtor("Tod James", debtorPA);
            builder.AddDebtorAgent(initCredAgent);

            //Optional RemittanceData
            Record record = builder.BuildTaxRecord("2005", "MM01", "RTGS", "INFO");
            TaxCreditor tCred = new TaxCreditor("20000001", "0002");
            builder.AddRemittanceData(record, tCred);

            return builder.Build();
        }

        [TestMethod]
        public void Test_RequestBuilder_Build()
        {
            TDB_SubmitPaymentAPI.SubmitPaymentRequest req = SetupRequest();

            Assert.AreEqual("ba1cf2244-960", req.wireData.wireIds.senderReferenceNumber);
            Assert.AreEqual("ba1cf2244-960", req.wireData.wireIds.endToEndId);
            Assert.AreEqual("400fa879-5a4a-4c81-ae48-09ad12d01afa", req.wireData.wireIds.uniqueEndToEndTransactionReference);
            Assert.AreEqual("066532289", req.wireData.wireIds.instructionId);
            Assert.AreEqual("2033-11-05T13:15:30.123456789Z", req.wireData.otherTransactionDates.debitValueDateTime);
            Assert.AreEqual(100000.99, req.wireData.amount);
            Assert.AreEqual("USD", req.wireData.currency);
            Assert.AreEqual("123456789", req.wireData.transactionIdentification);
            Assert.AreEqual("FED", req.wireData.transactionType);
            Assert.AreEqual(1.2333539999, req.wireData.exchangeRate);
            Assert.AreEqual("123456789", req.wireData.fxContractNumber);
            Assert.AreEqual(100000.99, req.wireData.clearingAndSettlement.creditTransferTransactionInformation.interBankSettlementAmount);
            Assert.AreEqual("USD", req.wireData.clearingAndSettlement.creditTransferTransactionInformation.interBankSettlementAmountCurrency);
            Assert.AreEqual("CTRC", req.wireData.clearingAndSettlement.localInstrumentProprietary);
            Assert.AreEqual("DEBT", req.wireData.clearingAndSettlement.chargesInfo.chargeBearer);
            Assert.AreEqual(100000.99, req.wireData.clearingAndSettlement.chargesInfo.amount);
            Assert.AreEqual("ACCTSTR", req.wireData.clearingAndSettlement.creditAccount.accountString);
            Assert.AreEqual("DDA", req.wireData.clearingAndSettlement.creditAccount.accountIdType);
            Assert.AreEqual("999", req.wireData.clearingAndSettlement.creditAccount.office);
            Assert.AreEqual("0000AA00", req.wireData.clearingAndSettlement.instructingAgent.financialInstitutionId.bicfi);
            Assert.AreEqual("0000AA00", req.wireData.clearingAndSettlement.instructedAgent.financialInstitutionId.bicfi);
            Assert.AreEqual("0000AA00", req.wireData.clearingAndSettlement.intermediaryAgent1.financialInstitutionId.bicfi);
            Assert.AreEqual("Tod James", req.wireData.clearingAndSettlement.intermediaryAgent1.financialInstitutionId.name);
            Assert.AreEqual("79, Wellington Street", req.wireData.clearingAndSettlement.intermediaryAgent1.financialInstitutionId.postalAddress.unstructuredAddressLine[0]);
            Assert.AreEqual("0000AA00", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.bicfi);
            Assert.AreEqual("Tod James", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.name);
            Assert.AreEqual("Toronto", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.townName);
            Assert.AreEqual("CA", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.country);
            Assert.AreEqual("L6X2Y9", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.postalCode);
            Assert.AreEqual("Wires", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.department);
            Assert.AreEqual("Wires-SubDepartment", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.subDepartment);
            Assert.AreEqual("123, Fake Street", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.streetName);
            Assert.AreEqual("123", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.buildingNumber);
            Assert.AreEqual("BuildingName", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.buildingName);
            Assert.AreEqual("12", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.floor);
            Assert.AreEqual("L6X2Y9", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.postalBox);
            Assert.AreEqual("12", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.room);
            Assert.AreEqual("Toronto", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.townLocation);
            Assert.AreEqual("Distillery", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.districtName);
            Assert.AreEqual("Ontario", req.wireData.clearingAndSettlement.intermediaryAgent2.financialInstitutionId.postalAddress.structured.countrySubDivision);
            Assert.AreEqual("0000AA00", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.bicfi);
            Assert.AreEqual("Tod James", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.name);
            Assert.AreEqual("Toronto", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.townName);
            Assert.AreEqual("CA", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.country);
            Assert.AreEqual("L6X2Y9", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.postalCode);
            Assert.AreEqual("Wires", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.department);
            Assert.AreEqual("Wires-SubDepartment", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.subDepartment);
            Assert.AreEqual("123, Fake Street", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.streetName);
            Assert.AreEqual("123", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.buildingNumber);
            Assert.AreEqual("BuildingName", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.buildingName);
            Assert.AreEqual("12", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.floor);
            Assert.AreEqual("L6X2Y9", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.postalBox);
            Assert.AreEqual("12", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.room);
            Assert.AreEqual("Toronto", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.townLocation);
            Assert.AreEqual("Distillery", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.districtName);
            Assert.AreEqual("Ontario", req.wireData.clearingAndSettlement.intermediaryAgent3.financialInstitutionId.postalAddress.structured.countrySubDivision);
            Assert.AreEqual("Tod James", req.wireData.initiation.creditor.name);
            Assert.AreEqual("79, Wellington Street", req.wireData.initiation.creditor.postalAddress.unstructured.addressLine[0]);
            Assert.AreEqual("CA", req.wireData.initiation.creditor.postalAddress.unstructured.country);
            Assert.AreEqual("FR7630006000011234567890189", req.wireData.initiation.creditorAccount.id.iban);
            Assert.AreEqual("DDA", req.wireData.initiation.creditorAccount.typeCode);
            Assert.AreEqual("ABCD123", req.wireData.initiation.creditorAgentAccountId);
            Assert.AreEqual("ABCD123", req.wireData.initiation.creditorAgent.branchId);
            Assert.AreEqual("0000AA00", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.bicfi);
            Assert.AreEqual("Tod James", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.name);
            Assert.AreEqual("79, Wellington Street", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.postalAddress.unstructuredAddressLine[0]);
            Assert.AreEqual("BY67TU908781", req.wireData.initiation.creditorAgent.instructionForCreditorAgent[0]);
            Assert.AreEqual("Tod James", req.wireData.initiation.debtor.name);
            Assert.AreEqual("79, Wellington Street", req.wireData.initiation.debtor.postalAddress.unstructured.addressLine[0]);
            Assert.AreEqual("CA", req.wireData.initiation.debtor.postalAddress.unstructured.country);
            Assert.AreEqual("ABCD123", req.wireData.initiation.debtorAccount.id.other.id);
            Assert.AreEqual("999", req.wireData.initiation.debtorAccount.id.other.schemeNameCode);
            Assert.AreEqual("DDA", req.wireData.initiation.debtorAccount.typeCode);
            Assert.AreEqual("0000AA00", req.wireData.initiation.debtorAgent.financialInstitutionId.bicfi);
            Assert.AreEqual("Tod James", req.wireData.initiation.debtorAgent.financialInstitutionId.name);
            Assert.AreEqual("79, Wellington Street", req.wireData.initiation.debtorAgent.financialInstitutionId.postalAddress.unstructuredAddressLine[0]);
            Assert.AreEqual("SFT", req.wireData.initiation.initiatingChannel);
            Assert.AreEqual("Tod James", req.wireData.initiation.initiatingPartyName);
            Assert.AreEqual(2005, req.wireData.remittanceData.structured.tax.record.period.year);
            Assert.AreEqual("MM01", req.wireData.remittanceData.structured.tax.record.period.month);
            Assert.AreEqual("RTGS", req.wireData.remittanceData.structured.tax.record.type);
            Assert.AreEqual("INFO", req.wireData.remittanceData.structured.tax.record.additionalInformation);
            Assert.AreEqual("20000001", req.wireData.remittanceData.structured.tax.creditor.taxId);
            Assert.AreEqual("0002", req.wireData.remittanceData.structured.tax.creditor.regulationId);
        }

        [TestMethod]
        public void Test_Message_Example()
        {
            string json = File.ReadAllText("..\\..\\resources\\exampleRequest.json");
            JObject j = JObject.Parse(json);

            JSchema schema = JSchema.Parse(File.ReadAllText("..\\..\\resources\\apiSchema.json"));
            bool result = j.IsValid(schema, out IList<ValidationError> _);
            Assert.AreEqual(true, result);
        }

        [TestMethod]
        public void Test_Message_Generator()
        {
            SubmitPaymentRequest req = SetupRequest();

            MessageGenerator generator = new MessageGenerator();
            string json = generator.Generatate(req);

            JObject j = JObject.Parse(json);

            JSchema schema = JSchema.Parse(File.ReadAllText("..\\..\\resources\\apiSchema.json"));
            bool result = j.IsValid(schema, out IList<ValidationError> errors);
            // Used to debug schema issues
            foreach(ValidationError err in errors)
            {
                Console.Write(err.Message);
            }
            Assert.AreEqual(true, result);
        }

        [Ignore]
        [TestMethod] // was used to generate a test message from DB data
        public void generateTestMsgForTDB()
        {
            RequestBuilder builder = new RequestBuilder();
            builder.AddBaseWireData("1350000.00", "USD", "651953");
            builder.AddWireIds("3602");
            builder.AddOtherTransactionDates("C", "2022-08-08 00:00:00.000");
            builder.AddClearingAndSettlement();
            builder.AddCreditTransferTransactionInformation("1350000.00", "USD");
            builder.AddInitiation("FED");
            string[] addr1 = new string[] { "111 N Main", "", "" };
            PostalAddress creditorParty = new PostalAddress(addr1); //pkey = 7
            builder.AddCreditor("PNC for EU", creditorParty);
            builder.AddOtherCreditorAccount("");

            string[] addr2 = new string[] { "333 Tower Plaza", "", "Paris France" };
            PostalAddress creditorAgentParty = new PostalAddress(addr2); // pkey = 3
            FinancialInstitutionIdWithNameAndAddress fina = new FinancialInstitutionIdWithNameAndAddress_clear("026005322", "USABA", "BOA for EU", creditorAgentParty);
            
            //builder.AddCreditorAgent(fina);
            builder.AddOtherDebtorAccount("9870336010", "004", "GLA");
            builder.AddRemittanceData("");

            SubmitPaymentRequest req = builder.Build();

            string json = new MessageGenerator().Generatate(req);
            Console.WriteLine(json);
        }

    }
}
