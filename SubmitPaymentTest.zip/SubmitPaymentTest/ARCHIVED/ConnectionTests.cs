﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using RichardSzalay.MockHttp;
using System.Threading;

namespace kafka.UnitTests
{
    [TestClass]
    public class ConnectionTest
    {
        [TestMethod]
        public void Test_KafkaWiresConfig()
        {
            KafkaConfig config = new KafkaConfig();

            Assert.AreEqual("GTS_PayPlusInbound", config.GTSServiceName);
            Assert.AreEqual(false, config.Logging); // Y/N converted to boolean
            Assert.AreEqual(15001, config.TimerInterval);
            Assert.AreEqual("http://testEndpoint.com", config.KafkaEndpoint);
            Assert.AreEqual("testApi", config.KafkaApiKey);
            Assert.AreEqual("testSecret", config.KafkaSecret);
            Assert.AreEqual("testTopic", config.KafkaTopic); 
            Assert.AreEqual("testChannel", config.KafkaChannelId);
            Assert.AreEqual(51, config.MaximumAlerts);
        }
    }
}

namespace TDB_SubmitPaymentAPI.UnitTests
{
    [TestClass]
    public class ConnectionTest
    {
        [TestMethod]
        public void Test_APIWiresConfig()
        {
            WiresConfig config = new WiresConfig();

            Assert.AreEqual("GTS_SubmitPayment", config.GTSServiceName);
            Assert.AreEqual(true, config.Logging); // Y/N converted to boolean
            Assert.AreEqual(15000, config.TimerInterval);
            Assert.AreEqual("CBRC", config.ApplicationCode);
            Assert.AreEqual(50, config.MaximumAlerts);
            Assert.AreEqual("http://www.testPing.com", config.PingFedUrl);
            Assert.AreEqual("testPassw", config.PingFedPassword); //maximum size of decripted value is 9
            Assert.AreEqual("http://www.testUrl.com", config.SubmitPaymentUrl);
        }

        [TestMethod]
        public void TestAuthorizeClient()
        {
            var mockHttp = new MockHttpMessageHandler();

            string token = "{'access_token' : '12345ABCDE', 'token_type' : 'Bearer', 'expires_in' : 12345}";

            mockHttp.When("http://www.testPing.com")
                    .Respond("application/json", token); 

            var client = new HttpClient(mockHttp);
            
            APICommands api = new APICommands(client, new WiresConfig(), new TableAccess(), new ErrorHandler(1));
            
            api.AuthorizeClient();
            

            AccessToken val = api.tWrapper.Token;

            Assert.AreEqual(val.Access_token, "12345ABCDE");
            Assert.AreEqual(val.Token_type, "Bearer");
            Assert.AreEqual(val.Expires_in, 12345);
        }

        [TestMethod]
        public void TestAuthorizeClient_ErrorResp()
        {
            GtsUtil.Logger.openLogFile("testLogFile.log", true);
            var mockHandler = new MockHttpMessageHandler();

            string response = "I am an error message";

            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.BadRequest,
                Content = new StringContent(response)
            };

            _ = mockHandler.When(HttpMethod.Post, "http://www.testPing.com")
                .Respond(mockResponse.StatusCode, mockResponse.Content);

            var httpClient = mockHandler.ToHttpClient();

            APICommands api = new APICommands(httpClient, new WiresConfig(), new TableAccess(), new ErrorHandler(1));

            api.AuthorizeClient();

            GtsUtil.Logger.closeLogFile();

            Assert.IsNull(api.tWrapper);

            List<string> lines = File.ReadLines("testLogFile.log").ToList();
            Assert.AreEqual(4, lines.Count);
            Assert.IsTrue(lines[0].Contains("Log File Opened"));
            Assert.IsTrue(lines[1].Contains("An error response was returned from the Authetication Endpoint."));
            Assert.IsTrue(lines[2].Contains("I am an error message"));
            Assert.IsTrue(lines[3].Contains("Log File Closed"));

            File.Delete("testLogFile.log");
        }

        [TestMethod]
        public void TestAuthorizeClient_nullRequest()
        {
            GtsUtil.Logger.openLogFile("testLogFile.log", true);

            var mockHttp = new MockHttpMessageHandler();

            // Setup a respond for the user api (including a wildcard in the URL)
            mockHttp.When("http://www.testPing.com")
                    .Throw(new ArgumentNullException("test", "test exception")); 

            // Inject the handler to the test api instance
            var client = new HttpClient(mockHttp);
            APICommands api = new APICommands(client, new WiresConfig(), new TableAccess(), new ErrorHandler(1));
            api.AuthorizeClient();

            GtsUtil.Logger.closeLogFile();

            Assert.IsNull(api.tWrapper);
            List<string> lines = File.ReadLines("testLogFile.log").ToList();
            Assert.AreEqual(5, lines.Count);
            Assert.IsTrue(lines[0].Contains("Log File Opened"));
            Assert.IsTrue(lines[1].Contains("An error occurred in Authorization: The request was null."));
            Assert.IsTrue(lines[2].Contains("test exception"));
            Assert.IsTrue(lines[3].Contains("Parameter name: test"));
            Assert.IsTrue(lines[4].Contains("Log File Closed"));

            File.Delete("testLogFile.log");
        }

        [TestMethod]
        public void TestAuthorizeClient_invalidOperation()
        {
            GtsUtil.Logger.openLogFile("testLogFile.log", true);
            var mockHttp = new MockHttpMessageHandler();

            mockHttp.When("http://www.testPing.com")
                    .Throw(new InvalidOperationException("test exception"));

            var client = new HttpClient(mockHttp);
            APICommands api = new APICommands(client, new WiresConfig(), new TableAccess(), new ErrorHandler(1));

            api.AuthorizeClient();

            GtsUtil.Logger.closeLogFile();

            Assert.IsNull(api.tWrapper);
            List<string> lines = File.ReadLines("testLogFile.log").ToList();
            Assert.AreEqual(4, lines.Count);
            Assert.IsTrue(lines[0].Contains("Log File Opened"));
            Assert.IsTrue(lines[1].Contains("An error occurred in Authorization: The request message was already sent by the System.Net.Http.HttpClient instance."));
            Assert.IsTrue(lines[2].Contains("test exception"));
            Assert.IsTrue(lines[3].Contains("Log File Closed"));

            File.Delete("testLogFile.log");
        }

        [TestMethod]
        public void TestAuthorizeClient_httpException()
        {
            GtsUtil.Logger.openLogFile("testLogFile.log", true);
            var mockHttp = new MockHttpMessageHandler();

            mockHttp.When("http://www.testPing.com")
                    .Throw(new HttpRequestException("test exception"));

            var client = new HttpClient(mockHttp);
            APICommands api = new APICommands(client, new WiresConfig(), new TableAccess(), new ErrorHandler(1));

            api.AuthorizeClient();

            GtsUtil.Logger.closeLogFile();

            string exceptionMsg = "The request failed due to an underlying issue such as network connectivity, DNS"
                + "failure, server certificate validation or timeout.";

            Assert.IsNull(api.tWrapper);
            List<string> lines = File.ReadLines("testLogFile.log").ToList();
            Assert.AreEqual(4, lines.Count);
            Assert.IsTrue(lines[0].Contains("Log File Opened"));
            Assert.IsTrue(lines[1].Contains("An error occurred in Authorization: " + exceptionMsg));
            Assert.IsTrue(lines[2].Contains("test exception"));
            Assert.IsTrue(lines[3].Contains("Log File Closed"));

            File.Delete("testLogFile.log");
        }

        private SubmitPaymentRequest SetupRequest()
        {
            RequestBuilder builder = new RequestBuilder();

            //Build
            string[] address = { "79, Wellington Street" };
            string[] inst = { "BY67TU908781" };
            PostalAddress initCredPA = builder.BuildPostalAddress(address);
            PostalAddress debtorPA = builder.BuildPostalAddress(address, "CA");
            FinancialInstitutionIdWithNameAndAddress initCredAgent =
                builder.BuildFinancialInstitutionIdWithNameAndAddress("0000AA00", "Tod James", initCredPA);
            PostalAddress structPA =
                builder.BuildPostalAddress("Toronto", "CA", "L6X2Y9", "Wires", "Wires-SubDepartment", "123, Fake Street",
                "123", "BuildingName", "12", "L6X2Y9", "12", "Toronto", "Distillery", "Ontario");

            // Assemble Base
            builder.AddBaseWireData("100000.99", "USD", "123456789", "1.2333539999", "123456789");
            builder.AddWireIds("ba1cf2244-960", "400fa879-5a4a-4c81-ae48-09ad12d01afa", "066532289");

            //Assemble Clearing And Settlement
            builder.AddOtherTransactionDates("D", "2033-11-05T13:15:30.123456789Z");
            builder.AddClearingAndSettlement("CTRC")
                .AddCreditTransferTransactionInformation("100000.99", "USD");

            //Optional - Clearing And Settlement
            builder.AddChargesInfo("DEBT", "100000.99");
            builder.AddCreditAccount("ACCTSTR", "DDA", "999");
            builder.AddInstructingAgent("0000AA00");
            builder.AddInstructedAgent("0000AA00");
            builder.AddIntermediaryAgent1("0000AA00", "Tod James", initCredPA);
            builder.AddIntermediaryAgent2("0000AA00", "Tod James", structPA);
            builder.AddIntermediaryAgent3("0000AA00", "Tod James", structPA);

            //Assemble - Initiation
            builder.AddInitiation("SFT", "Tod James", "ABCD123")
                .AddCreditor("Tod James", debtorPA)
                .AddCreditorAgent(initCredAgent, "ABCD123", inst)
                .AddOtherDebtorAccount("ABCD123", "999", "DDA");

            //Optional - Initiation
            builder.AddIbanCreditorAccount("FR7630006000011234567890189", "DDA");
            builder.AddDebtor("Tod James", debtorPA);
            builder.AddDebtorAgent(initCredAgent);

            //Optional RemittanceData
            Record record = builder.BuildTaxRecord("2005", "MM01", "RTGS", "INFO");
            TaxCreditor tCred = new TaxCreditor("20000001", "0002");
            builder.AddRemittanceData(record, tCred);

            return builder.Build();
        }

        [TestMethod]
        public void TestSendPaymentRequest()
        {
            GtsUtil.Logger.openLogFile("testLogFile.log", true);
            var mockHttp = new MockHttpMessageHandler();

            string response = "{'senderReferenceNumber' : 'ref', 'uniqueEndToEndTransactionReference' : 'uter'}";

            mockHttp.When("http://www.testUrl.com")
                .Respond("application/json", response);

            var client = new HttpClient(mockHttp);
            APICommands api = new APICommands(client, new WiresConfig(), new TableAccess(), new ErrorHandler(1));

            SubmitPaymentRequest req = SetupRequest();

            AccessToken token = new AccessToken
            {
                Access_token = "12345ABCDE",
                Token_type = "Bearer",
                Expires_in = 12345
            };

            api.tWrapper = new TokenWrapper(token, DateTime.Now);

            api.SendPaymentRequest(req);
           
            GtsUtil.Logger.closeLogFile();

            List<string> lines = File.ReadLines("testLogFile.log").ToList();
            Assert.AreEqual(5, lines.Count);
            Assert.IsTrue(lines[0].Contains("Log File Opened"));
            Assert.IsTrue(lines[1].Contains("Success"));
            Assert.IsTrue(lines[2].Contains("ref"));
            Assert.IsTrue(lines[3].Contains("uter"));
            Assert.IsTrue(lines[4].Contains("Log File Closed"));

            File.Delete("testLogFile.log");
        }

        [TestMethod]
        public void TestSendPayment_ErrorResp()
        {
            GtsUtil.Logger.openLogFile("testLogFile.log", true);
            var mockHandler = new MockHttpMessageHandler();

            string response = "{'senderReferenceNumber' : 'ref', 'uniqueEndToEndTransactionReference' : 'uter'}";

            var mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.BadRequest,
                Content = new StringContent(response)
            };
            _ = mockHandler.When(HttpMethod.Post, "http://www.testUrl.com")
                .Respond(mockResponse.StatusCode, mockResponse.Content);

            var httpClient = mockHandler.ToHttpClient();
            var api = new APICommands(httpClient, new WiresConfig(), new TableAccess(), new ErrorHandler(1));

            AccessToken token = new AccessToken
            {
                Access_token = "12345ABCDE",
                Token_type = "Bearer",
                Expires_in = 12345
            };

            api.tWrapper = new TokenWrapper(token, DateTime.Now);

            SubmitPaymentRequest req = SetupRequest();
            api.SendPaymentRequest(req);

            GtsUtil.Logger.closeLogFile();

            List<string> lines = File.ReadLines("testLogFile.log").ToList();
            Assert.AreEqual(3, lines.Count);
            Assert.IsTrue(lines[0].Contains("Log File Opened"));
            Assert.IsTrue(lines[1].Contains("Fail"));
            Assert.IsTrue(lines[2].Contains("Log File Closed"));

            File.Delete("testLogFile.log");
        }

        [TestMethod]
        public void TestTokenWrapper_IsExpired()
        {
            AccessToken token = new AccessToken
            {
                Access_token = "12345ABCDE",
                Token_type = "Bearer",
                Expires_in = 3
            };
            TokenWrapper wrapper = new TokenWrapper(token, DateTime.Now);
            Assert.IsFalse(wrapper.IsExpired());

            //Expiring token
            Thread.Sleep(3000);
            Assert.IsTrue(wrapper.IsExpired());
        }

        [Ignore]
        [TestMethod]
        public void TestGUID()
        {
            string guid = System.Guid.NewGuid().ToString();
            Console.WriteLine(guid);
        }
    }
}