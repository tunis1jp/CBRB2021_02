﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace TDB_SubmitPaymentAPI
{
    class Column
    {
        public string Name { get; set; }

        //TypeCode {int = 1, string = 2, datetime = 3}
        public int TypeCode { get; set; }

        public Column(string n, int i)
        {
            Name = n;
            TypeCode = i;
        }
    }

    [TestClass]
    public class TableAccessTest
    {
        private DataTable setupRecord(DateTime time)
        {
            DataTable table = new DataTable();

            List<Column> list = new List<Column>()
            {
                //Base Data
                new Column("senderReferenceNumber", 1),
                new Column("UETR", 2),
                new Column("Amount", 1),
                new Column("Currency", 2),
                new Column("transactionIdentification", 1),
                new Column("transactionType", 2),
                new Column("DebitCreditFlag", 2),
                new Column("ValueDate", 3),
                new Column("InstructedAmount", 1),
                new Column("InstructedCurrCode", 2),
                new Column("RemittanceData", 2),
                new Column("DebtorAcctId", 1),
                new Column("DebtorAcctScheme", 1),
                new Column("DebtorAcctTypeCode", 2),
                new Column("CredAcctOtherId", 2),
                //Creditor
                new Column("CredName", 2),
                new Column("CredOtherId", 2),
                new Column("CreditorAgentParty", 1),
                new Column("creditorAddress1", 2),
                new Column("creditorAddress2", 2),
                new Column("creditorAddress3", 2),
                new Column("creditorCountryDom", 2),
                new Column("creditorTownName", 2),
                new Column("creditorCountry", 2),
                new Column("creditorPostalCode", 2),
                new Column("creditorDepartment", 2),
                new Column("creditorSubDepartment", 2),
                new Column("creditorStreetName", 2),
                new Column("creditorBuildingNumber", 2),
                new Column("creditorBuildingName", 2),
                new Column("creditorFloor", 2),
                new Column("creditorPostalBox", 2),
                new Column("creditorRoom", 2),
                new Column("creditorTownLocation", 2),
                new Column("creditorDistrictName", 2),
                new Column("creditorCountrySubDivision", 2),
                //CreditorAgent
                new Column("creditorAgtMemberId", 1),
                new Column("creditorAgtClearingSystemIdCode", 2),
                new Column("creditorAgtName", 2),
                new Column("creditorAgtAddress1", 2),
                new Column("creditorAgtAddress2", 2),
                new Column("creditorAgtAddress3", 2),
                new Column("creditorAgtCountryDom", 2),
                new Column("creditorAgtTownName", 2),
                new Column("creditorAgtCountry", 2),
                new Column("creditorAgtPostalCode", 2),
                new Column("creditorAgtDepartment", 2),
                new Column("creditorAgtSubDepartment", 2),
                new Column("creditorAgtStreetName", 2),
                new Column("creditorAgtBuildingNumber", 2),
                new Column("creditorAgtBuildingName", 2),
                new Column("creditorAgtFloor", 2),
                new Column("creditorAgtPostalBox", 2),
                new Column("creditorAgtRoom", 2),
                new Column("creditorAgtTownLocation", 2),
                new Column("creditorAgtDistrictName", 2),
                new Column("creditorAgtCountrySubDivision", 2)
            };

            foreach (Column c in list)
            {
                table.Columns.Add(new DataColumn
                {
                    DataType = (c.TypeCode == 1) ? typeof(Int64) : (c.TypeCode == 2) ? typeof(string) : typeof(DateTime),
                    ColumnName = c.Name
                });
            }

            DataRow row = table.NewRow();
            //Base Data
            row["senderReferenceNumber"] = 3602;
            row["UETR"] = "";
            row["Amount"] = 1350000.00;
            row["Currency"] = "USD";
            row["transactionIdentification"] = 0;
            row["transactionType"] = "FED";
            row["DebitCreditFlag"] = "C";
            row["ValueDate"] = time;
            row["InstructedAmount"] = 1350000.00;
            row["InstructedCurrCode"] = "USD";
            row["RemittanceData"] = "";
            row["DebtorAcctId"] = 9870336010;
            row["DebtorAcctScheme"] = 4;
            row["DebtorAcctTypeCode"] = "GLA";
            row["CredAcctOtherId"] = "";
            //Creditor
            row["CredName"] = "PNC for EU";
            row["CredOtherId"] = "";
            row["creditorAddress1"] = "";
            row["creditorAddress2"] = "";
            row["creditorAddress3"] = "";
            row["creditorCountryDom"] = "";
            row["creditorTownName"] = "Colorado Springs";
            row["creditorCountry"] = "USA";
            row["creditorPostalCode"] = "80904";
            row["creditorDepartment"] = "Dep";
            row["creditorSubDepartment"] = "Sub";
            row["creditorStreetName"] = "Garden Of the Gods";
            row["creditorBuildingNumber"] = "123";
            row["creditorBuildingName"] = "Bank";
            row["creditorFloor"] = "2";
            row["creditorPostalBox"] = "PO";
            row["creditorRoom"] = "1A";
            row["creditorTownLocation"] = "Colorado";
            row["creditorDistrictName"] = "dist";
            row["creditorCountrySubDivision"] = "US_Central";
            //Creditor Agent
            row["creditorAgtMemberId"] = 026005322;
            row["creditorAgtClearingSystemIdCode"] = "USABA";
            row["creditorAgtName"] = "BOA for EU";
            row["creditorAgtAddress1"] = "333 Tower Plaza";
            row["creditorAgtAddress2"] = "";
            row["creditorAgtAddress3"] = "Paris France";
            row["creditorAgtCountryDom"] = "FR";
            row["creditorAgtTownName"] = "";
            row["creditorAgtCountry"] = "";
            row["creditorAgtPostalCode"] = "";
            row["creditorAgtDepartment"] = "";
            row["creditorAgtSubDepartment"] = "";
            row["creditorAgtStreetName"] = "";
            row["creditorAgtBuildingNumber"] = "";
            row["creditorAgtBuildingName"] = "";
            row["creditorAgtFloor"] = "";
            row["creditorAgtPostalBox"] = "";
            row["creditorAgtRoom"] = "";
            row["creditorAgtTownLocation"] = "";
            row["creditorAgtDistrictName"] = "";
            row["creditorAgtCountrySubDivision"] = "";

            table.Rows.Add(row);

            return table;
        }

        [TestMethod]
        public void TestFedParser()
        {
            DateTime time = DateTime.Now;
            
            //turn off required strucutre
            FedParser parser = new FedParser(new Tuple<bool, bool>(false,false));
            SubmitPaymentRequest req = parser.Parse(setupRecord(time));

            Assert.AreEqual("3602", req.wireData.wireIds.senderReferenceNumber);
            Assert.AreEqual("3602", req.wireData.wireIds.endToEndId);
            //Assert.AreEqual("", req.wireData.wireIds.uniqueEndToEndTransactionReference);
            Assert.AreEqual(time.ToString(), req.wireData.otherTransactionDates.creditValueDateTime);
            Assert.AreEqual(1350000.00, req.wireData.amount);
            Assert.AreEqual("USD", req.wireData.currency);
            Assert.AreEqual("0", req.wireData.transactionIdentification);
            Assert.AreEqual("FED", req.wireData.transactionType);
            Assert.AreEqual(1350000.00, req.wireData.clearingAndSettlement.creditTransferTransactionInformation.interBankSettlementAmount);
            Assert.AreEqual("USD", req.wireData.clearingAndSettlement.creditTransferTransactionInformation.interBankSettlementAmountCurrency);
            //Assert.AreEqual(null, req.wireData.remittanceData.unstructured.unstrucutred);
            Assert.AreEqual("9870336010", req.wireData.initiation.debtorAccount.id.other.id);

            Assert.AreEqual("004", req.wireData.initiation.debtorAccount.id.other.schemeNameCode);
            Assert.AreEqual("GLA", req.wireData.initiation.debtorAccount.typeCode);
            Assert.AreEqual(" ", req.wireData.initiation.creditorAccount.id.other.id);
            Assert.AreEqual("PNC for EU", req.wireData.initiation.creditor.name);

            Assert.AreEqual("Colorado Springs", req.wireData.initiation.creditor.postalAddress.structured.townName);
            Assert.AreEqual("USA", req.wireData.initiation.creditor.postalAddress.structured.country);
            Assert.AreEqual("80904", req.wireData.initiation.creditor.postalAddress.structured.postalCode);
            Assert.AreEqual("Dep", req.wireData.initiation.creditor.postalAddress.structured.department);
            Assert.AreEqual("Sub", req.wireData.initiation.creditor.postalAddress.structured.subDepartment);
            Assert.AreEqual("Garden Of the Gods", req.wireData.initiation.creditor.postalAddress.structured.streetName);
            Assert.AreEqual("123", req.wireData.initiation.creditor.postalAddress.structured.buildingNumber);
            Assert.AreEqual("Bank", req.wireData.initiation.creditor.postalAddress.structured.buildingName);
            Assert.AreEqual("2", req.wireData.initiation.creditor.postalAddress.structured.floor);
            Assert.AreEqual("PO", req.wireData.initiation.creditor.postalAddress.structured.postalBox);
            Assert.AreEqual("1A", req.wireData.initiation.creditor.postalAddress.structured.room);
            Assert.AreEqual("Colorado", req.wireData.initiation.creditor.postalAddress.structured.townLocation);
            Assert.AreEqual("dist", req.wireData.initiation.creditor.postalAddress.structured.districtName);
            Assert.AreEqual("US_Central", req.wireData.initiation.creditor.postalAddress.structured.countrySubDivision);

            //We might have a problem when we drop the leading 0
            Assert.AreEqual("26005322", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.clearingSystemMemberId.memberId);
            Assert.AreEqual("USABA", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.clearingSystemMemberId.clearingSystemIdCode);
            Assert.AreEqual("BOA for EU", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.name);
            Assert.AreEqual("333 Tower Plaza", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.postalAddress.unstructured.addressLine[0]);
            Assert.AreEqual(" ", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.postalAddress.unstructured.addressLine[1]);
            Assert.AreEqual("Paris France", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.postalAddress.unstructured.addressLine[2]);
            Assert.AreEqual("FR", req.wireData.initiation.creditorAgent.financialInstitutionIdWithNameAndAddress.postalAddress.unstructured.country);

            MessageGenerator generator = new MessageGenerator();
            string json = generator.Generatate(req);

            JObject j = JObject.Parse(json);

            JSchema schema = JSchema.Parse(File.ReadAllText("..\\..\\resources\\apiSchema.json"));
            bool result = j.IsValid(schema, out IList<ValidationError> errors);
            // Used to debug schema issues
            foreach (ValidationError err in errors)
            {
                Console.Write(err.Message);
            }
            Assert.AreEqual(true, result);

        }
    }
}