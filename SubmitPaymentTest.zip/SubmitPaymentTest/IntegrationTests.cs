﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RichardSzalay.MockHttp;
using SubmitPaymentAPI;
using System;
using System.Net.Http;

namespace SubmitPaymentTest
{
    [TestClass]
    public class IntegrationTests
    {
        [TestMethod]
        public void SubmitPaymentAPI_HappyPath()
        {
            var mockHttp = new MockHttpMessageHandler();

            string token = "{'access_token' : '12345ABCDE', 'token_type' : 'Bearer', 'expires_in' : 12345}";

            mockHttp.When("http://www.testPing.com")
                    .Respond("application/json", token);

            string response = "{'senderReferenceNumber' : '3602', 'uniqueEndToEndTransactionReference' : 'IAMA-UETR-Test'}";

            mockHttp.When("http://www.testUrl.com")
                .Respond("application/json", response);

            var client = new HttpClient(mockHttp);

            APICommands api = new APICommands(client, new WiresConfig(), fta, eh);

            api.AuthorizeClient();
        }
    }
}
