﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace SubmitPaymentKafka
{
    public partial class SubmitPaymentKafkaService : ServiceBase
    {
        public SubmitPaymentKafkaService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            System.Threading.Thread.Sleep(10000);
            Program.Main();
        }

        protected override void OnStop()
        {
            //Stopping service
        }
    }
}
