﻿using System;
using System.Collections.Generic;

namespace SubmitPaymentKafka
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE1006:Naming Styles", Justification = "<Pending>")]
    public class KafkaMessage_FTRREP
    {
        public PODScls PODS { get; set; }

        public class LifeCycleInfo
        {
            public string eventSubType { get; set; }
            public string messageType { get; set; }
            public string messageSubtype { get; set; }
            public string eventType { get; set; }
            public string eventId { get; set; }
            public DateTime timestamp { get; set; }
        }

        public class OtherIds
        {
            public string uniquePaymentIdentifier { get; set; }
            public string senderReferenceNumber { get; set; }
        }

        public class PODScls
        {
            public OtherIds otherIds { get; set; }
            public string transactionIdentification { get; set; }
            public LifeCycleInfo lifeCycleInfo { get; set; }
        }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE1006:Naming Styles", Justification = "<Pending>")]
    public class KafkaMessage_FTRCAN
    {
        public class Cdtr
        {
            public string taxId { get; set; }
            public string regnId { get; set; }
            public PstlAdr pstlAdr { get; set; }
            public string nm { get; set; }
        }

        public class CdtrAcct
        {
            public Id id { get; set; }
        }

        public class CdtrAgt
        {
            public List<InstrForCdtrAgt> instrForCdtrAgt { get; set; }
            public FinInstnId finInstnId { get; set; }
        }

        public class CdtTrfTxInf
        {
            public int intrBkSttlmAmt { get; set; }
            public string intrBkSttlmAmtCcy { get; set; }
        }

        public class ChrgsInf
        {
            public string chrgBr { get; set; }
        }

        public class ClearingAndSettlement
        {
            public PrvsInstgAgt1 prvsInstgAgt1 { get; set; }
            public List<ChrgsInf> chrgsInf { get; set; }
            public CdtTrfTxInf cdtTrfTxInf { get; set; }
            public InstgAgt instgAgt { get; set; }
            public PmtTpInf pmtTpInf { get; set; }
            public InstdAgt instdAgt { get; set; }
            public IntrmyAgt1 intrmyAgt1 { get; set; }
        }

        public class ClrSysId
        {
            public string cd { get; set; }
        }

        public class ClrSysMmbId
        {
            public string mmbId { get; set; }
            public ClrSysId clrSysId { get; set; }
        }

        public class Dbtr
        {
            public PstlAdr pstlAdr { get; set; }
            public Id id { get; set; }
        }

        public class DbtrAcct
        {
            public Id id { get; set; }
            public Tp tp { get; set; }
        }

        public class DbtrAgt
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class FinInstnId
        {
            public Othr othr { get; set; }
            public PstlAdr pstlAdr { get; set; }
            public string nm { get; set; }
            public ClrSysMmbId clrSysMmbId { get; set; }
        }

        public class Id
        {
            public Othr othr { get; set; }
        }

        public class InitgPty
        {
            public string nm { get; set; }
        }

        public class Initiation
        {
            public string initiatingChannel { get; set; }
            public DbtrAcct dbtrAcct { get; set; }
            public CdtrAgt cdtrAgt { get; set; }
            public CdtrAcct cdtrAcct { get; set; }
            public DbtrAgt dbtrAgt { get; set; }
            public Dbtr dbtr { get; set; }
            public InitgPty initgPty { get; set; }
            public Cdtr cdtr { get; set; }
        }

        public class InstdAgt
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class InstgAgt
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class InstrForCdtrAgt
        {
            public string instrInf { get; set; }
        }

        public class IntrmyAgt1
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class LclInstrm
        {
            public string prtry { get; set; }
        }

        public class LifeCycleInfo
        {
            public string messageType { get; set; }
            public string messageSubtype { get; set; }
            public string eventType { get; set; }
            public string eventId { get; set; }
            public DateTime timestamp { get; set; }
        }

        public class OtherIds
        {
            public string IMAD { get; set; }
            public string UETR { get; set; }
            public string uniquePaymentIdentifier { get; set; }
            public string senderReferenceNumber { get; set; }
        }

        public class OtherTransactionDates
        {
            public DateTime debitValueDateTime { get; set; }
        }

        public class Othr
        {
            public string id { get; set; }
            public SchmeNm schmeNm { get; set; }
        }

        public class PmtTpInf
        {
            public LclInstrm lclInstrm { get; set; }
        }

        public class PODS
        {
            public ClearingAndSettlement clearingAndSettlement { get; set; }
            public OtherTransactionDates otherTransactionDates { get; set; }
            public RemittanceData remittanceData { get; set; }
            public string direction { get; set; }
            public string productType { get; set; }
            public DateTime creDtTm { get; set; }
            public string retrieveIndicator { get; set; }
            public OtherIds otherIds { get; set; }
            public string productSubtype { get; set; }
            public Initiation initiation { get; set; }
            public LifeCycleInfo lifeCycleInfo { get; set; }
            public string transactionType { get; set; }
            public string transactionIdentification { get; set; }
        }

        public class Prd
        {
            public string mnth { get; set; }
            public string yr { get; set; }
        }

        public class PrvsInstgAgt1
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class PstlAdr
        {
            public List<string> adrLine { get; set; }
            public string ctry { get; set; }
        }

        public class Rcrd
        {
            public Prd prd { get; set; }
            public string addtlInf { get; set; }
            public string tp { get; set; }
        }

        public class RemittanceAdvice
        {
            public RemittanceInformation remittanceInformation { get; set; }
        }

        public class RemittanceData
        {
            public RemittanceAdvice remittanceAdvice { get; set; }
        }

        public class RemittanceInformation
        {
            public List<string> unstructured { get; set; }
            public Structured structured { get; set; }
        }

        public class Root
        {
            public PODS PODS { get; set; }
        }

        public class SchmeNm
        {
            public string cd { get; set; }
        }

        public class Structured
        {
            public Tax tax { get; set; }
        }

        public class Tax
        {
            public Rcrd rcrd { get; set; }
            public Cdtr cdtr { get; set; }
        }

        public class Tp
        {
            public string cd { get; set; }
        }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE1006:Naming Styles", Justification = "<Pending>")]
    public class KafkaMessage_FTRINF
    {
        public class Cdtr
        {
            public string taxId { get; set; }
            public string regnId { get; set; }
            public PstlAdr pstlAdr { get; set; }
            public string nm { get; set; }
        }

        public class CdtrAcct
        {
            public Id id { get; set; }
        }

        public class CdtrAgt
        {
            public List<InstrForCdtrAgt> instrForCdtrAgt { get; set; }
            public FinInstnId finInstnId { get; set; }
        }

        public class CdtTrfTxInf
        {
            public int intrBkSttlmAmt { get; set; }
            public string intrBkSttlmAmtCcy { get; set; }
        }

        public class ChrgsInf
        {
            public string chrgBr { get; set; }
        }

        public class ClearingAndSettlement
        {
            public PrvsInstgAgt1 prvsInstgAgt1 { get; set; }
            public List<ChrgsInf> chrgsInf { get; set; }
            public CdtTrfTxInf cdtTrfTxInf { get; set; }
            public InstgAgt instgAgt { get; set; }
            public PmtTpInf pmtTpInf { get; set; }
            public InstdAgt instdAgt { get; set; }
            public IntrmyAgt1 intrmyAgt1 { get; set; }
        }

        public class ClrSysId
        {
            public string cd { get; set; }
        }

        public class ClrSysMmbId
        {
            public string mmbId { get; set; }
            public ClrSysId clrSysId { get; set; }
        }

        public class Dbtr
        {
            public PstlAdr pstlAdr { get; set; }
            public Id id { get; set; }
        }

        public class DbtrAcct
        {
            public Id id { get; set; }
            public Tp tp { get; set; }
        }

        public class DbtrAgt
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class FinInstnId
        {
            public Othr othr { get; set; }
            public PstlAdr pstlAdr { get; set; }
            public string nm { get; set; }
            public ClrSysMmbId clrSysMmbId { get; set; }
        }

        public class Id
        {
            public Othr othr { get; set; }
        }

        public class InitgPty
        {
            public string nm { get; set; }
        }

        public class Initiation
        {
            public string initiatingChannel { get; set; }
            public DbtrAcct dbtrAcct { get; set; }
            public CdtrAgt cdtrAgt { get; set; }
            public CdtrAcct cdtrAcct { get; set; }
            public DbtrAgt dbtrAgt { get; set; }
            public Dbtr dbtr { get; set; }
            public InitgPty initgPty { get; set; }
            public Cdtr cdtr { get; set; }
        }

        public class InstdAgt
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class InstgAgt
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class InstrForCdtrAgt
        {
            public string instrInf { get; set; }
        }

        public class IntrmyAgt1
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class LclInstrm
        {
            public string prtry { get; set; }
        }

        public class LifeCycleInfo
        {
            public string messageType { get; set; }
            public string eventType { get; set; }
            public string eventId { get; set; }
            public DateTime timestamp { get; set; }
        }

        public class OtherIds
        {
            public string OMAD { get; set; }
            public string IMAD { get; set; }
            public string UETR { get; set; }
            public string uniquePaymentIdentifier { get; set; }
            public string senderReferenceNumber { get; set; }
        }

        public class OtherTransactionDates
        {
            public DateTime debitValueDateTime { get; set; }
        }

        public class Othr
        {
            public string id { get; set; }
            public SchmeNm schmeNm { get; set; }
        }

        public class PmtTpInf
        {
            public LclInstrm lclInstrm { get; set; }
        }

        public class PODS
        {
            public ClearingAndSettlement clearingAndSettlement { get; set; }
            public OtherTransactionDates otherTransactionDates { get; set; }
            public RemittanceData remittanceData { get; set; }
            public string direction { get; set; }
            public string productType { get; set; }
            public DateTime creDtTm { get; set; }
            public string retrieveIndicator { get; set; }
            public OtherIds otherIds { get; set; }
            public string productSubtype { get; set; }
            public Initiation initiation { get; set; }
            public LifeCycleInfo lifeCycleInfo { get; set; }
            public string transactionType { get; set; }
            public string transactionIdentification { get; set; }
        }

        public class Prd
        {
            public string mnth { get; set; }
            public string yr { get; set; }
        }

        public class PrvsInstgAgt1
        {
            public FinInstnId finInstnId { get; set; }
        }

        public class PstlAdr
        {
            public List<string> adrLine { get; set; }
            public string ctry { get; set; }
        }

        public class Rcrd
        {
            public Prd prd { get; set; }
            public string addtlInf { get; set; }
            public string tp { get; set; }
        }

        public class RemittanceAdvice
        {
            public RemittanceInformation remittanceInformation { get; set; }
        }

        public class RemittanceData
        {
            public RemittanceAdvice remittanceAdvice { get; set; }
        }

        public class RemittanceInformation
        {
            public List<string> unstructured { get; set; }
            public Structured structured { get; set; }
        }

        public class Root
        {
            public PODS PODS { get; set; }
        }

        public class SchmeNm
        {
            public string cd { get; set; }
        }

        public class Structured
        {
            public Tax tax { get; set; }
        }

        public class Tax
        {
            public Rcrd rcrd { get; set; }
            public Cdtr cdtr { get; set; }
        }

        public class Tp
        {
            public string cd { get; set; }
        }


    }
}