﻿using Dbio;
using System;

namespace SubmitPaymentKafka
{
	public class TableAccess
	{
		private readonly cDbioWr writer = new cDbioWr();

		public void UpdateFedRecord(string uetr, int status)
		{
			string sqlCommand = $"UPDATE FED SET Mtstatus = {status} WHERE UETR = '{uetr}'";
			ErrReporter.cReporter.ErrorReturned err = writer.ExecuteWriteSql(sqlCommand);
			if(err != 0)
            {
				throw new TableAccessException($"A [{err}] error occured when updating FED record [UETR: {uetr}]");
            }
		}

		public void UpdateRelatedReference(string uetr, int status, string response)
        {
			string sqlCommand = $"UPDATE RelatedReferences SET Mtstatus = '{status}', ResponseText = '{response}' WHERE RelatedReference = '{uetr}'";
			ErrReporter.cReporter.ErrorReturned err = writer.ExecuteWriteSql(sqlCommand);
			if (err != 0)
			{
				throw new TableAccessException($"A [{err}] error occured when updating RelatedReferences record [UETR: {uetr}]");
			}
		}
	}

	public class TableAccessException : Exception
    {
		public TableAccessException(string msg) : base(msg) { }
    }
}