﻿using Confluent.Kafka;
using System;
using System.Xml;

namespace SubmitPaymentKafka
{
    public class KafkaConfig : ConsumerConfig
    {
        public string GTSServicename { get; }

        public bool Logging { get; }
        public int TimerInterval { get; }

        public string KafkaEndpoint { get; }

        public string KafkaApiKey { get; }

        public string KafkaSecret { get; }

        public string KafkaTopic { get; }

        public string KafkaChannelId { get; }

        public int MaximumAlerts { get; }

        public ConsumerConfig Consumer { get; set; }

        public KafkaConfig()
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("wires.config");
            GTSServicename = xmlDoc.GetElementsByTagName("GTSServicename")[1].InnerText;
            Logging = (xmlDoc.GetElementsByTagName("Logging")[1].InnerText == "Y");
            KafkaEndpoint = xmlDoc.GetElementsByTagName("KafkaEndpoint")[0].InnerText;
            KafkaApiKey = xmlDoc.GetElementsByTagName("KafkaApiKey")[0].InnerText;
            KafkaSecret = xmlDoc.GetElementsByTagName("KafkaSecret")[0].InnerText;
            KafkaTopic = xmlDoc.GetElementsByTagName("KafkaTopic")[0].InnerText;
            KafkaChannelId = xmlDoc.GetElementsByTagName("KafkaChannelId")[0].InnerText;

            // Defaulting MaxAlerts to 1
            MaximumAlerts = ParseIntWithDefault(xmlDoc.GetElementsByTagName("MaximumAlerts")[0].InnerText, 1);

            //Defaulting timerinterval to 1 second
            TimerInterval = ParseIntWithDefault(xmlDoc.GetElementsByTagName("TimerInterval")[0].InnerText, 1000);
        }

        private int ParseIntWithDefault(string num, int def)
        {
            try
            {
                return int.Parse(num);
            }
            catch (Exception)
            {
                return def;
            }
        }

        public void SetConsumerConfig(ConsumerConfig c)
        {
            Consumer = c;
        }
    }
}