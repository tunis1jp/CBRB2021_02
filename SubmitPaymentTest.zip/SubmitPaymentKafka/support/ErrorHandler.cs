﻿namespace SubmitPaymentKafka
{
    using ErrReporter;
    using System.IO;

    public class ErrorHandler
    {
        private const string ALERT_TYPE = "FedWire";
        private readonly StreamWriter logfile;
        private readonly int maxAlerts;
        private int alertsSent = 0;
        private readonly cReporter reporter;

        public ErrorHandler(int max, StreamWriter lf)
        {
            maxAlerts = max;
            reporter = new cReporter();
            logfile = lf;
        }

        // returns false if the number of maximum alerts have been reached
        public bool SendAlert(string message, int pkey = 0, int transPkey = 0)            
        {
            alertsSent += 1;

            logfile.WriteLine($"ALERT [{ALERT_TYPE}]: {message}");
            reporter.SendAlert(ALERT_TYPE, message, pkey, transPkey);

            return maxAlerts <= alertsSent;
        }
    }
}