﻿using Confluent.Kafka;
using System;
using System.Text;
using Newtonsoft.Json;
using System.IO;

namespace SubmitPaymentKafka
{
    public class KafkaConsumer
    {
        public StreamWriter logfile;
        public string Logpath = "";
        public CibarLogger.cibar_config cf;

        // Minutes to wait for messages before logging that none have come in
        const int LOG_NOMSG_MINUTES = 10;

        private readonly KafkaConfig config;
        bool shouldContinue = true;
        private readonly TableAccess ta;
        private readonly ErrorHandler Alert;

        public KafkaConsumer()
        {
            config = GetConfig();
            string execname = System.Reflection.Assembly.GetEntryAssembly().GetName().Name;
            cf = new CibarLogger.cibar_config("wires.config", "SubmitPaymentAPI", execname, ref logfile, config);
            logfile.AutoFlush = true;
            cf.daychanged(ref logfile);

            //make a new sqlUtil if none exists
            ta = new TableAccess();
            Alert = new ErrorHandler(config.MaximumAlerts, logfile);
        }

        private KafkaConfig GetConfig()
        {
            logfile.WriteLine("Reading configuration from wires.config");

            KafkaConfig kafkaConfig = new KafkaConfig();

            var config = new ConsumerConfig
            {
                BootstrapServers = kafkaConfig.KafkaEndpoint,
                
                GroupId = kafkaConfig.KafkaChannelId,
                
                AutoOffsetReset = AutoOffsetReset.Earliest,
                
                //Turning off the offset store to ensure every message is processed at least once
                EnableAutoOffsetStore = false //ensure storeOffeset is called to save the store

            };

            kafkaConfig.SetConsumerConfig(config);

            logfile.WriteLine("Successfully read the wires.config file");
            return kafkaConfig;
        }

        public void Run()
        {
            logfile.WriteLine("Initializing the consumer...");
            using (var consumer = new ConsumerBuilder<Ignore, string>(config)
               .SetErrorHandler((_, e) => logfile.WriteLine($"Error: {e.Reason}"))
               .Build())
            {
                consumer.Subscribe(config.KafkaTopic);
                logfile.WriteLine($"Subscribed to topic: {config.KafkaTopic}");

                int tryAgain = 0;
                int timeoutMilliseconds = config.TimerInterval;
                int logNoMessage = (60 / (timeoutMilliseconds/1000)) * LOG_NOMSG_MINUTES;

                Console.CancelKeyPress += new ConsoleCancelEventHandler(MyHandler);
                try
                {
                    while (shouldContinue)
                    {
                        // Waiting for the next message for the defined timeInterval
                        var consumeResult = consumer.Consume(TimeSpan.FromMilliseconds(timeoutMilliseconds));

                        if (consumeResult == null)
                        {
                            if (tryAgain >= logNoMessage)
                            {
                                logfile.WriteLine(
                                    $"No Messages Received on {consumeResult.Topic} in {LOG_NOMSG_MINUTES} minutes");
                                tryAgain = 0;
                            }
                            tryAgain += 1;
                            continue;
                        }

                        logfile.WriteLine($"Received message at {consumeResult.Topic}: {consumeResult.Message.Value}");

                        ProcessMessage(consumeResult);

                        //store the message so it doesn't reprocess it
                        consumer.StoreOffset(consumeResult);
                        tryAgain = 0;
                    }
                }
                catch (ConsumeException e)
                {
                    logfile.WriteLine($"Consume error: {e.Error.Reason}");
                }
                catch (KafkaException e)
                {
                    logfile.WriteLine($"Store Offset error: {e.Error.Reason}");
                }
                catch (Exception e)
                {
                    logfile.WriteLine(e.Message);
                }
                finally
                {
                    consumer.Close();
                    logfile.WriteLine("Successfully Terminated Consumer.");
                }
            }
        }

        /*
         * Only Process messages with this header value - "CHANNEL_CODE": ["CBRB"]
         * Can filter this out using streams, but its a bit easier on this end... (probably slower too) 
         */
        void ProcessMessage(ConsumeResult<Ignore, string> consumeResult)
        {
            //Note: Make the consumeResult object the same as in the using block above     
            if (consumeResult.Message.Headers != null && consumeResult.Message.Headers.Count > 0)
            {
                var headers = consumeResult.Message.Headers;

                //TODO: read the content?
                var content = consumeResult.Message.Value;

                if (headers.TryGetLastBytes("CHANNEL_CODE", out byte[] channelCode))
                {
                    if (!"CBRB".Equals(Encoding.ASCII.GetString(channelCode)))
                    {
                        //Do not process message without the header-> CHANNEL_CODE = CBRB
                        logfile.WriteLine("Not processing message, 'CHANNEL_CODE' header is not 'CBRB'");
                        return;
                    }

                    //TODO: are these headers correct?
                    var status = Encoding.ASCII.GetString(headers.GetLastBytes("STATUS"));
                    var refNum = Encoding.ASCII.GetString(headers.GetLastBytes("REF_NUMBER"));
                    var incRefNum = Encoding.ASCII.GetString(headers.GetLastBytes("INCOMING_REF_NUMBER"));
                    var uetr = Encoding.ASCII.GetString(headers.GetLastBytes("UETR"));
                    var mid = Encoding.ASCII.GetString(headers.GetLastBytes("MID"));
                    var correlation_id = Encoding.ASCII.GetString(headers.GetLastBytes("CORRELATION_ID"));
                    
                    switch (status)
                    {
                        //TODO: Should we Deserialize the messages?
                        //TODO: What is MTStatus of 'failed' messages
                        case "ACCEPTED":
                            //message = FTRREP  AND( / ResponseSegment / ResponseCode = '1' OR ' ')
                            //KafkaMessage_FTRREP msg = JsonConvert.DeserializeObject<KafkaMessage_FTRREP>(content);

                            try { 
                                ta.UpdateFedRecord(uetr, 2);
                                ta.UpdateRelatedReference(uetr, 2, "ACCEPTED");
                            }
                            catch(Exception e)
                            {
                                logfile.WriteLine(e.Message);
                            }
                            break;
                        case "PROCESSING":
                            //message = FTRREP  AND( / ResponseSegment / ResponseCode != '1' OR ' ')
                            //KafkaMessage_FTRREP msg = JsonConvert.DeserializeObject<KafkaMessage_FTRREP>(content);
                            shouldContinue = Alert.SendAlert("Kafka message returned with a status of PROCESSING", int.Parse(refNum)); //needs the Pkeys
                            try { 
                                ta.UpdateFedRecord(uetr, 3);
                                ta.UpdateRelatedReference(uetr, 3, "PROCESSING");
                            }
                            catch (Exception e)
                            {
                                logfile.WriteLine(e.Message);
                            }
                            break;
                        case "COMPLETE":
                            //message = FTRINF
                            //KafkaMessage_FTRINF message = JsonConvert.DeserializeObject<KafkaMessage_FTRINF>(content);
                            shouldContinue = Alert.SendAlert("Kafka message returned with a status of COMPLETE", int.Parse(refNum)); //needs the Pkeys
                            try { 
                                ta.UpdateFedRecord(uetr, 4);
                                ta.UpdateRelatedReference(uetr, 4, "COMPLETE");
                            } catch (Exception e)
                            {
                                logfile.WriteLine(e.Message);
                            }
                            break;
                        case "CANCELLED":
                            //message = FTRCAN
                            //KafkaMessage_FTRCAN message = JsonConvert.DeserializeObject<KafkaMessage_FTRCAN>(content);
                            shouldContinue = Alert.SendAlert("Kafka message returned with a status of CANCELLED", int.Parse(refNum)); //needs the Pkeys

                            try
                            {
                                    ta.UpdateFedRecord(uetr, 5); 
                                        ta.UpdateRelatedReference(uetr, 5, "CANCELLED");
                            }
                            catch (Exception e)
                            {
                                logfile.WriteLine(e.Message);
                            }
                            break;
                    }
                }
            }
        }

        protected void MyHandler(object sender, ConsoleCancelEventArgs args)
        {
            logfile.WriteLine("User Terminating Run...");
            args.Cancel = true;
            shouldContinue = false;
            return;
        }
    }
}
