﻿namespace SubmitPaymentKafka
{
    class Program
    {
        public static void Main()
        {
            //Testing only
            /*
                string topic = "quickstart-events";
                Producer producer = new Producer();
                //[STATUS, CHANNEL_CODE, REF_NUMBER, INCOMING_REF_NUMBER]
                var m1 = producer.createMessage("Message One", new string[] { "ACCEPTED", "CBRB", "TEST_REFNUM", "TEST_INCREFNUM" });
                var m2 = producer.createMessage("Message Two", new string[] { "ACCEPTED", "CBRB", "TEST_REFNUM", "TEST_INCREFNUM" });
                producer.AddMessage(topic, m1);
                producer.AddMessage(topic, m2);
            */
            KafkaConsumer consumer = new KafkaConsumer();
            consumer.Run();
        }
    }
}