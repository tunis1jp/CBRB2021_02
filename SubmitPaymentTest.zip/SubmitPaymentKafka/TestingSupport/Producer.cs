﻿using Confluent.Kafka;
using System;
using System.Text;

namespace SubmitPaymentKafka
{
    //IGNORE THIS!
    //TODO: Work on schema integration - seems like TDB has some support already built

    class Producer
    {
        public Message<Null, string> createMessage(string val, string[] headers)
        {
            var hdrs = new Headers();
            hdrs.Add("STATUS", Encoding.ASCII.GetBytes(headers[0]));
            hdrs.Add("CHANNEL_CODE", Encoding.ASCII.GetBytes(headers[1]));
            hdrs.Add("REF_NUMBER", Encoding.ASCII.GetBytes(headers[2]));
            hdrs.Add("INCOMING_REF_NUMBER", Encoding.ASCII.GetBytes(headers[3]));

            return new Message<Null, string> { Value = val, Headers = hdrs };
        }

        public void AddMessage(string topic, Message<Null, string> message)
        {
            //new Message<Null, string> { Value = "hello world", Headers = hdrs }

            //setup should be pulled in from the wires.config file...
            var config = new ProducerConfig
            {
                BootstrapServers = "localhost:9092",
            };

            //Consumer should have a <Key, Object> format - unsure what the schema is
            using (var producer = new ProducerBuilder<Null, String>(config).Build())
            {
                //subscribe to the topic

                var hdrs = new Headers();

                producer.ProduceAsync(topic, message);

            }
        }
    }
}
