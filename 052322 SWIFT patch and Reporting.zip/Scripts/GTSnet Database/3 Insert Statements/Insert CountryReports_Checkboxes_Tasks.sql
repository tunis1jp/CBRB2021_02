insert into TaskStatus
values ('RPT_MIS_COUNTERPARTY', '', '', '1900-01-01 00:00:00.000', '3', '0', '', '', '', '1', '0', '1', '', '', '', '', 'N', 'RPT_MIS_COUNTERPARTY.EXE', 'N', '', '', '0', '2022-05-05 12:00:00.000', '0', '0', '1', '1', '0', '0', '0', '0')

insert into TaskStatus
values ('RPT_MIS_COUNTRYEXPOSURE', '', '', '1900-01-01 00:00:00.000', '3', '0', '', '', '', '1', '0', '1', '', '', '', '', 'N', 'RPT_MIS_COUNTRYEXPOSURE.EXE', 'N', '', '', '0', '2022-05-05 12:00:00.000', '0', '0', '1', '1', '0', '0', '0', '0')

insert into reports
values ('Counterparty Exposure', 'Counterparty Exposure Report', 'O', '1', '', '', 'MIS', 'RPT_MIS_COUNTERPARTY', '', '1', '', 'MISC', '1', '7', 'PDF', 'L', '0', '0')

insert into reports
values ('Country Exposure Report', 'Country Exposure Report', 'O', '1', '', '', 'MIS', 'RPT_MIS_COUNTRYEXPOSURE', '', '1', '', 'MISC', '1', '7', 'PDF', 'L', '0', '0')

insert into CheckBoxes
values ('1', 'USA on Country Report', '', 'PAR', 'TD', 'Y', '')