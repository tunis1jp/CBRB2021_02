/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateUpdate]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStateUpdate]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStatePrintByCountry]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStatePrintByCountry]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStatePrintByCode]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStatePrintByCode]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateGetTrace]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStateGetTrace]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateGetListNamesByLe]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStateGetListNamesByLe]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateGetCodeData]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStateGetCodeData]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateGetAllToPrintByLE]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStateGetAllToPrintByLE]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateDelete]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStateDelete]
GO

/****** Object:  StoredProcedure [dbo].[memGEOCountryStateCopy]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[memGEOCountryStateCopy]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateAddNew]    Script Date: 5/4/2022 7:40:04 AM ******/
DROP PROCEDURE IF EXISTS [dbo].[MemGEOCountryStateAddNew]
GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateAddNew]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [dbo].[MemGEOCountryStateAddNew] 

	@LegalEntity VARCHAR(2),
	@GEOCode VARCHAR(5),
	@Country VARCHAR(2),
	@StateCode VARCHAR(2),
	@ListName VARCHAR(24),
	@LimitAmount MONEY,
	@Description VARCHAR(50),
	@Trace INTEGER,
	@B1Code FLOAT,
	@ReportsMonthly BIT,
	@ReportsSemimonthly BIT,
	@B1Quarterly BIT,
	@B2Quarterly BIT,
	@Active BIT,
	@CountryFlag BIT,
	@HighRisk BIT,
	@CRR VARCHAR(7)
	
AS

	INSERT INTO MemGEOCountryState(
		
	LegalEntity,
	GEOCode,
	Country,
	StateCode,
	ListName,
	LimitAmount,
	Description,
	Trace,
	B1Code,
	ReportsMonthly,
	ReportsSemimonthly,
	B1Quarterly,
	B2Quarterly,
	Active,
	CountryFlag,
	HighRisk,
	CRR)
	
	VALUES(

	@LegalEntity,
	@GEOCode,
	@Country,
	@StateCode,
	@ListName,
	@LimitAmount,
	@Description,
	@Trace,
	@B1Code,
	@ReportsMonthly,
	@ReportsSemimonthly,
	@B1Quarterly,
	@B2Quarterly,
	@Active,
	@CountryFlag,
	@HighRisk,
	@CRR)
	
	return

















GO

/****** Object:  StoredProcedure [dbo].[memGEOCountryStateCopy]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO















CREATE PROCEDURE [dbo].[memGEOCountryStateCopy]
    @OldLegalEntity    varchar(3),
    @NewLegalEntity    varchar(3)

AS

            Insert into memGEOCountryState Select
            @newlegalentity, 
            GEOCode, 
            Country, 
            StateCode, 
            ListName, 
            Description, 
            Trace, 
            B1Code, 
            ReportsMonthly, 
            ReportsSemimonthly, 
            B1Quarterly, 
            B2Quarterly, 
            OrderBy, 
            Active, 
            CountryFlag, 
            LimitAmount,
			HighRisk,
			CRR
            from memGEOCountryState where @oldlegalentity = Legalentity
    return (@@error)















GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateDelete]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO















CREATE PROCEDURE [dbo].[MemGEOCountryStateDelete] 

	@pkey INTEGER

AS

	DELETE FROM MemGEOCountryState WHERE pkey = @pkey

	return















GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateGetAllToPrintByLE]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO















CREATE PROCEDURE [dbo].[MemGEOCountryStateGetAllToPrintByLE] 

	@LegalEntity VARCHAR(2)

AS

	SELECT * FROM MemGEOCountryState WHERE LegalEntity = @LegalEntity
	
	return

















GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateGetCodeData]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO















CREATE PROCEDURE [dbo].[MemGEOCountryStateGetCodeData]

	@Pkey INTEGER

 AS

	SELECT * FROM MemGEOCountryState WHERE Pkey = @Pkey

	return















GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateGetListNamesByLe]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO















CREATE PROCEDURE [dbo].[MemGEOCountryStateGetListNamesByLe] 

	@LegalEntity VARCHAR(2)

AS

	SELECT * FROM MemGEOCountryState WHERE LegalEntity = @LegalEntity ORDER BY ListName

	return















GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateGetTrace]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO





CREATE PROCEDURE [dbo].[MemGEOCountryStateGetTrace]

	@LegalEntity VARCHAR(2),
	@Country VARCHAR(2)

 AS

	SELECT Trace FROM MemGEOCountryState WHERE Country = @Country and StateCode = "" and LegalEntity = @LegalEntity





GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStatePrintByCode]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO



CREATE PROCEDURE [dbo].[MemGEOCountryStatePrintByCode]

	@LegalEntity VARCHAR(2)

AS

	SELECT * FROM MemGEOCountryState WHERE LegalEntity = @LegalEntity ORDER BY GEOCode




GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStatePrintByCountry]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO



CREATE PROCEDURE [dbo].[MemGEOCountryStatePrintByCountry]

	@LegalEntity VARCHAR(2)

AS

	SELECT * FROM MemGEOCountryState WHERE LegalEntity = @LegalEntity ORDER BY Country, StateCode




GO

/****** Object:  StoredProcedure [dbo].[MemGEOCountryStateUpdate]    Script Date: 5/4/2022 7:40:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO










CREATE PROCEDURE [dbo].[MemGEOCountryStateUpdate]

	@LegalEntity VARCHAR(2),
	@GEOCode VARCHAR(5),
	@Country VARCHAR(2),
	@StateCode VARCHAR(2),
	@ListName VARCHAR(24),
	@LimitAmount MONEY,
	@Description VARCHAR(50),
	@Trace INTEGER,
	@B1Code FLOAT,
	@ReportsMonthly BIT,
	@ReportsSemimonthly BIT,
	@B1Quarterly BIT,
	@B2Quarterly BIT,
	@Active BIT,
	@CountryFlag BIT,
	@HighRisk BIT,
	@pkey INTEGER,
	@CRR VARCHAR(7)

 AS

	UPDATE MemGEOCountryState SET

	LegalEntity = @LegalEntity,
	GEOCode = @GEOCode,
	Country = @Country,
	StateCode = @StateCode,
	ListName = @ListName,
	LimitAmount = @LimitAmount,
	Description = @Description,
	Trace = @Trace,
	B1Code = @B1Code,
	ReportsMonthly = @ReportsMonthly,
	ReportsSemimonthly = @ReportsSemimonthly,
	B1Quarterly = @B1Quarterly,
	B2Quarterly = @B2Quarterly,
	Active = @Active,
	CountryFlag = @CountryFlag,
	HighRisk = @HighRisk,
	CRR = @CRR

	WHERE pkey = @pkey

	return

















GO


