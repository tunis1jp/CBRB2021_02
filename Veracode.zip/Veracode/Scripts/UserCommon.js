function VerifyDelete(ThisWhatever) {
    return (confirm("Do you really want to delete this " + ThisWhatever + "?"));
}

/////////////////////////////////////////////////////////////////////////////
// appExit() - close browser (aka. exit application)
//
function appExit()
{
	window.close();
}

//----------------------------------------------------------------------
// Let's have 1 PosCursor for all the simplest cases
//----------------------------------------------------------------------
function PosCursor(objHere) {
	if (objHere != null) 
		objHere.focus();
}

//***********************************************************
//***********************************************************
function ConfirmCancel(sThisItem) {
	var bYesNo;
	
	bYesNo = confirm ("Do you really want to Quit this " + sThisItem + " without saving any changes?");
	return(bYesNo);
}

////////////////////////////////////////////////////////////////
// CheckRequired() - check the length of a field, if zero, fail
function CheckRequired(field,sDesc) {
	if(field.value.length == 0) {
		// tell 'em to enter something!
		if (sDesc == null) {
			window.alert("You must enter the required field");
			if(CheckRequired.arguments.length < 2)
				field.focus();          // take 'em to that field
		}
		else {
			window.alert(sDesc + " is a required field.");
			if(CheckRequired.arguments.length < 3)
				field.focus();          // take 'em to that field
		}
	  
	  return(false);
	}
	
	return(true);
}
	
//-----------------------------------------------------------------------------
// The scope of these 2 globals is limited to the Wip screen only.  Once the
// user leaves the Wip screen, the showMe function cannot make adequate use of
// these guys.
//-----------------------------------------------------------------------------
var newWindow
var sPriorRef
var sPriorApp

function showMe (sReasonName,sRefName,sTypeName,sStatName,sStyleSheet,form) {
	var sContent
	var sStatus
	var sReason
	var sRef
	var sAppType
	var sAppDesc
	
	sStatus = form.elements[sStatName].value
	sReason = form.elements[sReasonName].value
	sRef = form.elements[sRefName].value
	sAppType = form.elements[sTypeName].value
	
	switch (sAppType) {
		case "IMPENT":
			sAppDesc = "Documentary Application"
			break;
			
		case "STBENT":
			sAppDesc = "Standby Application"
			break;
			
		case "DIRENT":
			sAppDesc = "Direct Collection Application"
			break;
			
		case "CEXENT":		// not likely
			sAppDesc = "Export Collection Application"
			break;
			
		case "IMPXMD":
			sAppDesc = "Documentary Amendment"
			break;
			
		case "STBXMD":
			sAppDesc = "Standby Amendment"
			break;
			
		case "DIRXMD":
			sAppDesc = "Direct Collection Amendment"
			break;
			
		case "CEXXMD":
			sAppDesc = "Export Collection Amendment"
			break;
			
		default:
			sAppDesc = sAppType
	}
	
	//alert ("sAppType = " + sAppType + ", sRef = " + sRef + ", sStatus = " + sStatus)
	//-------------------------------------------------------------------------
	// If the user has selected a different rejected item, then we need to
	// close the window that displayed the prior one.
	//-------------------------------------------------------------------------
	if ((sPriorRef != sRef) || (sPriorApp != sAppType)) {
		if (!newWindow || newWindow.closed) {
		}
		else {
			newWindow.close()
		}
	}
	
	//-------------------------------------------------------------------------
	// Either create the new window, or focus on the existing.
	//-------------------------------------------------------------------------
	if (!newWindow || newWindow.closed) {
		newWindow = window.open("","","resizable,scrollbars,HEIGHT=300,WIDTH=600")
		
		//---------------------------------------------------------------------
		// Create the content of this window
		// The style sheet path needs to be handled by this chunk of code. In
		// this instance, the style sheet will be in the current directory.
		//---------------------------------------------------------------------
			sContent = "<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\" xml:lang=\"en\">" +
						"<head>" +
							"<link rel='STYLESHEET' type='text/css' href='" + sStyleSheet + "'>" +
							"<title>" +
								sAppDesc + " " + sStatus +
							"</TITLE>" +
							"<script LANGUAGE=javascript>function CloseMe(){self.close();}</script>" +
						"</head>" +
						"<body>" + 
							"<table width='100%' class='NAV'>" +
								"<tr class='NAV'>" +
									"<td style='text-align:right' class='NAV'>" +
										"<a href='' class='NavBarInHeader' onClick='CloseMe();'>Close This Window</a>" +
									"</td>" +
								"</tr>" +
							"</table>" +
							"<h3>Reference: '" + sRef + 
							"'</h3>" +
							"<p>" +
								sReason + 
							"</p>" +
						"</body>" +
					"</html>"
									
		//---------------------------------------------------------------------
		// Show the window
		//---------------------------------------------------------------------
		newWindow.document.write(sContent)
		newWindow.document.close()
	}
	else {
		newWindow.focus()
	}
	sPriorRef = sRef
	sPriorApp = sAppType
}
//-------------------------------------------------------------------
// Function added by DCB to display help in a new window.
// Feel free to tweak this to improve the appearance.
// --dependent doesn't do what I had hoped...
//-------------------------------------------------------------------
function ShowHelp (sThisPage) {
	var helpWindow

	helpWindow = window.open(sThisPage,'Help',"resizable,scrollbars,HEIGHT=750,WIDTH=1200")
}

function CloseHelp () {
	self.close()
}

// returnBlank()
//
// Really useful in JavaScript handlers where you want to discard the
// return value of a previous function (see ImpIssue tabs for example)
//
// JBK 03/16/2001
function returnBlank() {
	return;
}

//
// putDateTogether
//
// Helper for parseDateGeneric.  Takes in a year, month
// and day and creates a date based on it.
//
function putDateTogether(year, month, day) {
	if(month == "") {
		return;
	}
	if(month < 1 || month > 12) {
		alert("Invalid month: " + month)
		return;
	}
	var d
	d = new Date(year, month - 1, day)
	if(day > 31 || day < 0 || d.getDate() != day) {
		alert("Invalid day: " + day)
		return;
	}
	return d;
}

//
// parseFixedDateGeneric
//
// Helper for parseDateGeneric.  Parses a fixed-length date
// based on the given size (in characters) of day, month and year.
//
function parseFixedDateGeneric(dateStr, partOrder, yearSize, monthSize, daySize) {
	var year;
	var month;
	var day;
	var partNum;
	var i;
	var temp;
	i=0;
	for(partNum=0;partNum<3;partNum++) {
	    if (partOrder.charAt(partNum) == "Y") {
	        temp = dateStr.substr(i, yearSize);
		    year = fixYear(temp); i += yearSize;
		    if (year == "") {
		        alert("Invalid Year: " + temp);
		        return;
		    }
		} else if(partOrder.charAt(partNum) == "M") {
			month = fixMonth(dateStr.substr(i, monthSize)); i+=monthSize;
		} else if(partOrder.charAt(partNum) == "D") {
			day = dateStr.substr(i, daySize); i+=daySize;
		} else {
			alert("Invalid date part in " + partOrder);
		}
	}
	return putDateTogether(year, month, day);
}

//
// parseDateGeneric
//
// parseDateGeneric is a helper function for getdate()
// that takes in the order of the fields (MDY, MYD, etc.)
// and parses things.  It allows three major formats,
// fixed-length, separated by / and separated by -.
//
// For fixed-length formats, the month may be 3-char alpha
// or 2-digit numeric and the year may be 2 or 4 digits,
// and the day must be 2 digits.  Examples include "MMDDYYYY"
// (12221975), "DDMMMYY" (22dec75) and "YYMMDD" (751222).
//
// For variable length formats, the day and year may be digits
// of any size and the month may be digits of any size or a
// 3-digit representation of the date.
//
// As long as the order of the month, day and year is given,
// the method will automatically detect which format the user
// entered their date in.
//
// dateType does not affect the routine at all; it is
// passed in to be able to show better error messages
// to the user.
//
// This method returns the actual Date object, or nothing if
// there is an error.
//
function parseDateGeneric(dateStr, partOrder, dateType) {
	// Get rid of extraneous spaces and other whatnots
	dateStr = stripCharsNotInBag(dateStr, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz/-");

	// Fixed length formats
	if(strIsAlphaNum(dateStr)) {
		if(dateStr.length == 6) {
			return parseFixedDateGeneric(dateStr, partOrder, 2, 2, 2)
		} else if(dateStr.length == 8) {
			return parseFixedDateGeneric(dateStr, partOrder, 4, 2, 2)
		} else if(dateStr.length == 7) {
			return parseFixedDateGeneric(dateStr, partOrder, 2, 3, 2)
		} else if(dateStr.length == 9) {
			return parseFixedDateGeneric(dateStr, partOrder, 4, 3, 2)
		} else {
			alert("Invalid date.  Date format is " + dateType);
			return;
		}
	} else {
		// Convert variable length formats
		var dateArray;
		dateArray = dateStr.split('/');
		if(dateArray.length != 3) {
			dateArray = dateStr.split('-');
			if(dateArray.length != 3) {
				alert("Invalid date.  Date format is " + dateType);
				return;
			}
		}

		var year;
		var month;
		var day;
		var partNum;
		for(partNum=0;partNum<3;partNum++) {
			if(partOrder.charAt(partNum) == "Y") {
				year = fixYear(dateArray[partNum]);
			} else if(partOrder.charAt(partNum) == "M") {
				month = fixMonth(dateArray[partNum]);
			} else if(partOrder.charAt(partNum) == "D") {
				day = dateArray[partNum];
			} else {
				alert("Invalid date part in " + partOrder);
			}
		}

		return putDateTogether(year, month, day);
	}
}
////////////////////////////////
// PUBLIC DATE FIELD ROUTINES //
////////////////////////////////

//
// checkdate
//
// Left for compatibility with old, non-date-compliant portions
// of the program.
//
// Verifies the date in MM/DD/YYYY format.
//
// 2/8/2001 JBK
//
function checkdate(dateField) {
	return chkdate(dateField, 'MM/dd/yyyy');
}

//
// compareDatesUS
//
// Left for compatibility with old, non-date-format-compliant
// portions of the program.
//
// Uses MM/DD/YYYY format.
//
// 2/8/2001 JBK
//
function compareDatesUS(dateField1, dateField2) {
	return compareDates(dateField1, dateField2, 'MM/DD/YYYY');
}

//
// compareDates
//
// Compare two form fields as dates, formatted according to
// dateType (see getDate for more info on dateType).
//
// Returns whether or not dateField1 > dateField2.
// If either one is blank, this function simply returns false.
//
// 2/7/2001 JBK
//
function compareDates(dateField1, dateField2, dateType)
{
	if(dateField1.value == '' || dateField2.value == '') {
		return false;
	}

	var date1;
	var date2;

	date1 = getDate(dateField1, dateType);
	date2 = getDate(dateField2, dateType);
	
	
	if(date1 == null || date2 == null) {
		return false;
	}
	return date1.getTime() > date2.getTime();
}

//
// chkdate
//
// Validates that the field is a valid date according to the format
// given in dateType (see getDate for more info on dateType).
//
// If the field is blank, this function returns true.
//
// JBK 2/7/2001 revamp, changed interface so that date type is
//              passed in as a field, not a string
// GLA 11/08/00 created
//
function chkdate(field, dateType) {
	if(field.value == '') {
		return true;
	}

	var actualDate;
	actualDate = getDate(field, dateType);
	if(actualDate == null) {
		field.focus();
		return false;
	} else {
		setDateField(field, dateType, actualDate);
		return true;
	}
}

//
// formatDate
//
// Turn a date into a string according to the specified date format
//
// 2/15/2001 JBK
//
function formatDate(actualDate, dateType) {
	if(dateType.toUpperCase () == 'MM/DD/YYYY') {
		return padZeroes(actualDate.getMonth() + 1, 2)
		        + "/" + padZeroes(actualDate.getDate(), 2)
		        + "/" + padZeroes(actualDate.getFullYear(), 4);
	}  else if(dateType.toUpperCase () == 'DD/MM/YYYY') {
		return padZeroes(actualDate.getDate(), 2)
		        + "/" + padZeroes(actualDate.getMonth() + 1, 2)
		        + "/" + padZeroes(actualDate.getFullYear(), 4);
	}  else if(dateType.toUpperCase () == 'DD-MMM-YYYY') {
		return padZeroes(actualDate.getDate(), 2)
		        + "-" + getMonthString(actualDate.getMonth() + 1)
		        + "-" + padZeroes(actualDate.getFullYear(), 4);
	} else {
        	alert("Unrecognized format " + dateType.toUpperCase ());
        	return;
	}
}

//
// setDateField
//
// Using the format given as dateType, format actualDate and put the value in field.
//
// 2/7/2001 JBK
//
function setDateField(field, dateType, actualDate) {
	var newDate = formatDate(actualDate, dateType);

	if(field.value != newDate) {
		field.value = newDate;
	}
}

//
// getDate
//
// Parse date field using the format given in dateType.
// Accepts the date type as a string, either "MM/DD/YYYY",
// "DD/MM/YYYY", or "DD-MMM-YYYY".  For each of these it is
// forgiving if the separators are not there or the year is
// two characters; for example, MM/DD/YYYY also supports MM/DD/YY,
// MMDDYYYY and MMDDYY.  It also accepts MM instead of MMM and
// vice versa, and accepts either - or / as a separator.
//
// This was about as forgiving as I could make this routine
// without leaving date entry ambiguous.  formatDate() will fix
// the date into the proper format anyway, so why not let the
// user enter the date as many ways as possible?  The only real
// constraint in this method is the order of the date parts.
//
// 2/7/2001 JBK
//
function getDate(field, dateType) {
	
    var dateStr = field.value;
    var Result = "";

    if (dateType.toUpperCase() == 'MM/DD/YYYY') {
        Result = parseDateGeneric(dateStr, "MDY", dateType);
    } else if(dateType.toUpperCase () == 'DD/MM/YYYY') {
        Result = parseDateGeneric(dateStr, "DMY", dateType);
    } else if (dateType.toUpperCase() == 'DD-MMM-YYYY') {
        Result = parseDateGeneric(dateStr, "DMY", dateType);
    } else {
        alert("Unrecognized format " + dateType.toUpperCase ())
        return;
    }
    return Result;
}


//
// getTodaysDate
//
// Get today's date, without the milliseconds and seconds and such
//
// 2/15/2001 JBK
//
function getTodaysDate() {
	var todaysDate;
	todaysDate = new Date();
	return new Date(todaysDate.getFullYear(), todaysDate.getMonth(), todaysDate.getDate())
}

////////////////////////////////
// PRIVATE DATE FIELD HELPERS //
////////////////////////////////

//
// getMonthString
//
// Get a 3-digit month string from an integer (1-12) representing the month.
//
// 2/7/2001 JBK
//
function getMonthString(val) {
	val = parseInt(val, 10);
	switch(val) {
		case 1:
			return "Jan";
		case 2:
			return "Feb";
		case 3:
			return "Mar";
		case 4:
			return "Apr";
		case 5:
			return "May";
		case 6:
			return "Jun";
		case 7:
			return "Jul";
		case 8:
			return "Aug";
		case 9:
			return "Sep";
		case 10:
			return "Oct";
		case 11:
			return "Nov";
		case 12:
			return "Dec";
	}
}

//
// fixMonth
//
// If the input string is a number, return that.
// Otherwise convert the 3-digit month to a string with the month # (1-12) in it.
//
// 2/7/2001 JBK
//
function fixMonth(val) {
	if(!isNaN(parseInt(val))) {
		return val;
	}

	switch(val.toUpperCase()) {
		case "JAN":
			return "1";
		case "FEB":
			return "2";
		case "MAR":
			return "3";
		case "APR":
			return "4";
		case "MAY":
			return "5";
		case "JUN":
			return "6";
		case "JUL":
			return "7";
		case "AUG":
			return "8";
		case "SEP":
			return "9";
		case "OCT":
			return "10";
		case "NOV":
			return "11";
		case "DEC":
			return "12";
	}

	alert("Invalid month " + val + ".");
	return "";
}

//
// fixYear
//
// If the year is less than 70, return 2000 + year.
// If the year is less than 100, return 1900 + year.
// Else return the year.
// (Return value is a string.)
//
// 2/7/2001 JBK
//
function fixYear(val) {
	var year;
	year = parseInt(val, 10);
	if (isNaN(year)) {
		return "";
	}

	if(year < 70) {
		year = year + 2000;
	} else if(year < 100) {
		year = year + 1900;
	}

	return new String(year);
}


//---------------------------------------------------
// **********************************************
//Verifies that it is a number being sent in
function ValidateNumber(sAmount, sCurFmt){
	var i;
	var delmCount=0;
	var CompString = '0123456789,.';
		
	//Make sure it's a numeric Value
	for(i=0;i<sAmount.length;i++){
		if(CompString.indexOf(sAmount.charAt(i))==-1){
			alert('Invalid Numeric Value');
			return false;
		}
	}
    
	// checks to see if they placed more than one decimal point
	if(sCurFmt=='CD'){	//999,999.99	
		for(i=0;i<sAmount.length;i++){
			if(sAmount.charAt(i)=='.'){
				delmCount++;
			}
		}
	}
	else{  //999.999,99
		for(i=0;i<sAmount.length;i++){
			if(sAmount.charAt(i)==','){
				delmCount++;
			}
		}
	}
    
	if (delmCount>1){
		alert('Invalid Numeric Value');
		return false;
	}
	//------------------------------------
	
	return true;
}

// check if a field is numeric return false if not
function IsNumeric(field) {
	if(field.value.length == 0)
		return(true);

	var sData = null
	var nopt = IsNumeric.arguments.length
	if (nopt == 2)
	// if second parameter then it is a string and check it

		 sData  = IsNumeric.arguments[1];
	

	if (sData != null)		{
		if (isNaN(sData))	{
			return (false);
			}
		else			{
			return (true)
			}
		}


	if (isNaN(field.value))		{
		// alert ("Numeric is required");
		field.focus();
		return (false);
		
		}
	return(true);
		
}

/////////////////////////////
// STRING PARSING ROUTINES //
/////////////////////////////

//
// stripCharsInBag
//
// Removes all characters which appear in string bag from string s.
//
// 2/7/2001 JBK From FormChek.js (http://developer.netscape.com/docs/examples/javascript/formval/overview.html)
//
function stripCharsInBag (s, bag)
{   var i;
    var returnString = "";

    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.

    for (i = 0; i < s.length; i++)
    {   
        // Check that current character isn't whitespace.
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }

    return returnString;
}

//
// stripCharsNotInBag
//
// Removes all characters which do NOT appear in string bag 
// from string s.
//
// 2/7/2001 JBK From FormChek.js (http://developer.netscape.com/docs/examples/javascript/formval/overview.html)
//
function stripCharsNotInBag (s, bag)
{   var i;
    var returnString = "";

    // Search through string's characters one by one.
    // If character is in bag, append to returnString.

    for (i = 0; i < s.length; i++)
    {   
        // Check that current character isn't whitespace.
        var c = s.charAt(i);
        if (bag.indexOf(c) != -1) returnString += c;
    }

    return returnString;
}

//
// onlyContainsCharsInBag
//
// Returns true is the string only contains the characters in
// the string bag.  Empty string returns true.
// (UNTESTED)
//
// 2/7/2001 JBK
//
function onlyContainsCharsInBag(s, bag)
{   var i;

    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (bag.indexOf(c) != -1) return false;
    }

    return true;
}

//
// isNum
//
// Check if a character is numeric.
//
// 2/7/2001 JBK
//
function isNum(c) {
	return (c >= '0' && c <= '9');
}

//
// isAlpha
//
// Check if a character is A-Za-z.
//
// 2/7/2001 JBK
//
function isAlpha(c) {
	return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}

//
// strIsNum
//
// Check if a string is numeric.
//
// 2/7/2001 JBK
//
function strIsNum(s) {
	var i;
	for(i=0; i<s.length; i++) {
		if(!isNum(s.charAt(i))) {
			return false;
		}
	}
	return true;
}

//
// strIsAlphaNum
//
// Check if a string has entirely numeric or alpha chars.
//
// 2/7/2001 JBK
//
function strIsAlphaNum(s) {
	var i;
	for(i=0; i<s.length; i++) {
		if(!isAlpha(s.charAt(i)) && !isNum(s.charAt(i))) {
			return false;
		}
	}
	return true;
}

//
// padZeroes
//
// Pad the beginning of a String with zeroes up to totalLength.
//
// 2/7/2001 JBK
// 2/22/01 GLA added the optional sDir, defualts to Left Pad
function padZeroes(val, totalLength) {
	val = new String(val);
	var i;
	
	for(i=0; i<totalLength-val.length; i++) {
		val = "0" + val;
	}
    
	return val;
}

function ShowCalendar()
{
	CalWnd = window.open('calendar.htm','Calendar',"resizable,scrollbars,HEIGHT=600,WIDTH=600")
}

function ShowCalculator()
{
	CalcWnd = window.open('calculator.htm','Calculator',"resizable,scrollbars,HEIGHT=600,WIDTH=600")
}

function ShowTodo()
{
	TodoWnd = window.open('todolist.htm','Todo',"resizable,scrollbars,HEIGHT=600,WIDTH=600")
}
