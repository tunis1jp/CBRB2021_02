--
-- Set Purge Retention to 4 years
--
update ParmsLe set  MonthsAfterCOLPaytoPurge = 120,   MonthsAfterExpirytoPurge = 120
--
Update Parmsgts set PartyMonthtoPurge = '6'