function WipSubmit(form, button, formName) {
	var sListSize;
	var sLocation;
	var iSortIndex;
	var sSortDir;
	var sRef;
	var sCurFmt;
	var sBtnType;
	var sTemp;
	var iIndex;

	switch(button) {
		case 997:  // RADPRINT
			// radSelected has a length iff it is a control array
			// i.e., there are > 1 checkboxes
			if (form.radSelected == null) {
				iLen = 0;
			} else {
				iLen = form.radSelected.length
			}
			if (iLen == null) {
				iLen = 1
			}

			switch (iLen) {
				case 0:
					switch (formName) {
						case "BankImages":
							sTemp = "There are no documents available for selection."
							break;
						default:
							sTemp = "formName " + formName + " not implemented in Wip.js (1)"
							break;
					}
					alert (sTemp)
					return (false)
					break;

				case 1:
					if (form.radSelected.checked) {
						switch (formName) {
							case "BankImages":
								sLocation = "inq/Inquiry.aspx?WCI=BankImages&WCE=Submit&lst=N&Pkey=" + form.radSelected.value
								break;

							default:
								sTemp = "formName " + formName + " not implemented in Wip.js (2)"
								alert (stemp);
								return (false);
								break;
						}
						// fall through to the end
					}
					else {
						switch (formName) {
							case "BankImages":
								sTemp = "You have not selected a document."
								break;

							default:
								sTemp = "formName " + formName + " not implemented in Wip.js (3)"
								break;
						}
						alert (sTemp);
						return (false);
					}
					break;

				default:
					switch (formName) {
						case "BankImages":
							for (iIndex = 0; iIndex < iLen; iIndex++) {
								if (form.radSelected(iIndex).checked) {
									sLocation = "inq/Inquiry.aspx?WCI=BankImages&WCE=Submit&lst=N&Pkey=" + form.radSelected(iIndex).value
									document.location = sLocation;
									return (false);
									break;
								}
								sTemp = "You have not selected a document."
							}
							break;

						default:
							sTemp = "formName " + formName + " not implemented in Wip.js (4)"
							break;
					}
					alert (sTemp)
					return (false)
					break;
			}

			document.location = sLocation;
			return (false);
			
			break;

		case 998:  // CHKPRINT
			// chkSelected has a length iff it is a control array
			// i.e., there are > 1 checkboxes
			if (form.chkSelected == null) {
				iLen = 0;
			} else {
				iLen = form.chkSelected.length
			}
			if (iLen == null) {
				iLen = 1
			}
			switch (iLen) {
				case 0:
					switch (formName) {
						case "AdmMenu":
							sTemp = "There are no discrepancies available for selection."
							break;
						case "AppMenu":
							sTemp = "There are no applications available for selection."
							break;
						case "BankText":
							sTemp = "There are no bank text items available for selection."
							break;
						default:
							sTemp = "formName " + formName + " not implemented in Wip.js (5)"
							break;
					}
					alert (sTemp)
					return (false)
					break;
					
				case 1:
					if (form.chkSelected.checked) {
						switch (formName) {
							case "AdmMenu":
								sLocation = "Icc.asp?WCI=AdmMenu&WCE=SubmitPrint&lst=N&Pkey=" + form.chkSelected.value
								break;
							case "AppMenu":
								sLocation = "Icc.asp?WCI=AppMenu&WCE=SubmitPrint&lst=N&Pkey=" + form.chkSelected.value
								break;
							case "BankText":
								sLocation = "inq/Inquiry.asp?WCI=BankText&WCE=Submit&lst=N&Pkey=" + form.chkSelected.value
								break;
							default:
								sTemp = "formName " + formName + " not implemented in Wip.js (6)"
								alert (sTemp);
								return (false);
								break;
						}
						// fall through to the end
					}
					else {
						switch (formName) {
							case "AdmMenu":
								sTemp = "You have not selected any discrepancies."
								break;
							case "AppMenu":
								sTemp = "You have not selected any applications."
								break;
							case "BankText":
								sTemp = "You have not selected any bank text."
								break;
							default:
								sTemp = "formName " + formName + " not implemented in Wip.js (7)"
								break;
						}
						alert (sTemp)
						return (false)
					}
					break;
					
				default:
					sPKeys = ""
					iCount = 0
					// 0 to iLen - 1 OR 1 to iLen ??
					for (iX = 0; iX < iLen; iX++) {
						if (form.chkSelected[iX].checked) {
							if (sPKeys != "") {
								sPKeys = sPKeys + ","
							}
							sPKeys = sPKeys + form.chkSelected[iX].value
							iCount = iCount + 1
						}
					}
					
					if (iCount == 0) {
						switch (formName) {
							case "AdmMenu":
								sTemp = "You have not selected any discrepancies."
								break;
							case "AppMenu":
								sTemp = "You have not selected any applications."
								break;
							case "BankText":
								sTemp = "You have not selected any bank text."
								break;
							default:
								sTemp = "formName " + formName + " not implemented in Wip.js (8)"
								break;
						}
						alert (sTemp)
						return (false)
					}
					else {
						switch (formName) {
							case "AdmMenu":
								sLocation = "Icc.asp?WCI=AdmMenu&WCE=SubmitPrint&lst=Y&Pkey=" + sPKeys
								break;
							case "AppMenu":
								sLocation = "Icc.asp?WCI=AppMenu&WCE=SubmitPrint&lst=Y&Pkey=" + sPKeys
								break;
							case "BankText":
								sLocation = "inq/Inquiry.asp?WCI=BankText&WCE=Submit&lst=Y&Pkey=" + sPKeys
								break;
							default:
								sTemp = "formName " + formName + " not implemented in Wip.js (9)"
								alert (sTemp);
								return (false);
								break;
						}
						// fall through to the end
					}
					break;
			}
			document.location = sLocation;
			return (false);
			
			break;
							
		case 999:  // BTNSELECT
			document.location=form;
			break;
		
		default:
			switch(button)
			{
				case 1:  // BTNSUBMIT
					sBtnType = "Submit";
					break;
				case 2:  // BTNAPPROVE
					sBtnType = "Approve";
					break;
				case 3:  // BTNRELEASE
					sBtnType = "Release";
					break;
				case 4:  // BTNREJECT
					sBtnType = "Reject";
					break;
				case 201:  // BTNNOUPDATE
					sBtnType = "No Update";
					break;
				case 999:  // BTNSELECT
					sBtnType = "Select";
					break;
				default:
					sBtnType = "" + button + " button";
					break;
			}
			alert("The " + sBtnType + " is not implemented.");
			return (false);
			break;
	}
}
