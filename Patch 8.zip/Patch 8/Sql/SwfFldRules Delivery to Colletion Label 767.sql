update SWFFldRules
set MTTokenDescription = 'Delivery To/Collect By'
where mttokenid = ':24G:' and MTTokenMsgType = 'MT767'