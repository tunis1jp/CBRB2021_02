update memSICCodes set LegalEntity = 'TD' 
