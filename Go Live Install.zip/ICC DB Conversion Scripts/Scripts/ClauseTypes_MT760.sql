-- select * from clausetypes
 
declare @MaxPkey int
set @MaxPkey = (SELECT TOP (1) [TypeId] FROM [ClauseTypes] order by typeid desc)

insert into clausetypes
values (@MaxPkey+1, 'STBENT', 'DOCPRESINS', 'Presentation Instructions', 65, 100)

insert into clausetypes
values (@MaxPkey+3, 'STBENT', 'UTERMSCOND', 'Undertaking Terms', 65, 150)

insert into clausetypes
values (@MaxPkey+5, 'STBENT', 'UTRANSDTL', 'Underlying Trans. Details', 65, 50)
