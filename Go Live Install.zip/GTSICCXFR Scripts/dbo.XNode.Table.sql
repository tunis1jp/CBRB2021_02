delete from xnode
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1016, N'0', N'Pledge', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1017, N'01', N'BankId', 1016, 0, 1, 1, N'Pledge', N'BankId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1018, N'02', N'CustomerId', 1016, 0, 1, 1, N'Pledge', N'CustomerId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1019, N'03', N'BranchId', 1016, 0, 1, 1, N'Pledge', N'BranchId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1020, N'04', N'IccID', 1016, 0, 1, 1, N'Pledge', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1021, N'05', N'BankRef', 1016, 0, 1, 1, N'Pledge', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1022, N'06', N'Service', 1016, 0, 1, 1, N'Pledge', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1023, N'07', N'Product', 1016, 0, 1, 1, N'Pledge', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1024, N'08', N'IccType', 1016, 0, 1, 1, N'Pledge', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1025, N'09', N'IccPkey', 1016, 0, 1, 1, N'Pledge', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1026, N'10', N'PledgeId', 1016, 0, 1, 1, N'Pledge', N'PledgeId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1027, N'11', N'DepositorsPkey', 1016, 0, 1, 1, N'Pledge', N'DepositorsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1028, N'18', N'DepositorsName', 1016, 0, 1, 1, N'Pledge', N'DepositorsName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1029, N'12', N'StartDate', 1016, 0, 1, 1, N'Pledge', N'StartDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1030, N'13', N'EndDate', 1016, 0, 1, 1, N'Pledge', N'EndDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1031, N'14', N'Amount', 1016, 0, 1, 1, N'Pledge', N'Amount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1032, N'15', N'Adjustment', 1016, 0, 1, 1, N'Pledge', N'Adjustment')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1033, N'16', N'OutboundToDoPkey', 1016, 0, 1, 1, N'Pledge', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1034, N'17', N'TransPkey', 1016, 0, 1, 1, N'Pledge', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1067, N'19', N'DepositorsAddress1', 1016, 0, 1, 1, N'Pledge', N'DepositorsAddress1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1068, N'20', N'DepositorsAddress2', 1016, 0, 1, 1, N'Pledge', N'DepositorsAddress2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1069, N'21', N'DepositorsAddress3', 1016, 0, 1, 1, N'Pledge', N'DepositorsAddress3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1070, N'24', N'DepositorsEmail', 1016, 0, 1, 1, N'Pledge', N'DepositorsEmail')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1087, N'22', N'DepositorsZip', 1016, 0, 1, 1, N'Pledge', N'DepositorsZip')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1088, N'23', N'DepositorsPhone', 1016, 0, 1, 1, N'Pledge', N'DepositorsPhone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1105, N'992.1', N'RatingAgency', 10134, 0, 1, 1, N'LocPrimary', N'RatingAgency')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1106, N'992.1.1', N'BondPurpose', 10134, 0, 1, 1, N'LocPrimary', N'BondPurpose')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1123, N'27', N'Files', 1016, 4, 3, 1, N'Files', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1124, N'27.01', N'FileName', 1123, 0, 1, 1, N'Files', N'FileName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1125, N'27.02', N'FileType', 1123, 0, 1, 1, N'Files', N'FileType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1126, N'27.03', N'FileData', 1123, 0, 1, 1, N'Files', N'FileData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1127, N'13', N'Files', 1040117, 4, 3, 1, N'Files', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1128, N'13.01', N'FileName', 1127, 0, 1, 1, N'Files', N'FileName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1129, N'13.02', N'FileType', 1127, 0, 1, 1, N'Files', N'FileType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1130, N'13.02', N'FileData', 1127, 0, 1, 1, N'Files', N'FileData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1195, N'30.15', N'AttnLine1', 10165, 0, 1, 1, N'Bene', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1196, N'20.15', N'AttnLine1', 10155, 0, 1, 1, N'ApplicantBank', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1197, N'19.15', N'AttnLine1', 10154, 0, 1, 1, N'AdviseThru', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1198, N'53.15', N'AttnLine1', 10189, 0, 1, 1, N'Opener', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1199, N'39.15', N'AttnLine1', 10602, 0, 1, 1, N'Carrier', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1200, N'40.15', N'AttnLine1', 10603, 0, 1, 1, N'FreightF', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1201, N'41.15', N'Attnline1', 10604, 0, 1, 1, N'Drawee', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1202, N'42.15', N'AttnLine1', 10605, 0, 1, 1, N'Presenter', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1203, N'34.15', N'AttnLine1', 10493, 0, 1, 1, N'Obligor', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1204, N'37.15', N'AttnLine1', 10496, 0, 1, 1, N'PayTo', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1205, N'40.15', N'AttnLine1', 10499, 0, 1, 1, N'ReimburseOn', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1206, N'21.15', N'AttnLine1', 10266, 0, 1, 1, N'Remitter', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1207, N'33.15', N'AttnLine1', 10278, 0, 1, 1, N'CollectFrom', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1208, N'35.15', N'AttnLine1', 10280, 0, 1, 1, N'Drawee', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1209, N'36.15', N'AttnLine1', 10281, 0, 1, 1, N'Drawer', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1210, N'37.15', N'AttnLine1', 10282, 0, 1, 1, N'CreditTo', N'AttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1211, N'30.16', N'EmailAddress', 10165, 0, 1, 1, N'Bene', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1212, N'20.16', N'EmailAddress', 10155, 0, 1, 1, N'ApplicantBank', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1213, N'19.16', N'EmailAddress', 10154, 0, 1, 1, N'AdviseThru', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1214, N'53.16', N'EmailAddress', 10189, 0, 1, 1, N'Opener', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1215, N'39.16', N'EmailAddress', 10602, 0, 1, 1, N'Carrier', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1216, N'40.16', N'EmailAddress', 10603, 0, 1, 1, N'FreightF', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1217, N'41.16', N'EmailAddress', 10604, 0, 1, 1, N'Drawee', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1218, N'42.16', N'EmailAddress', 10605, 0, 1, 1, N'Presenter', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1219, N'34.16', N'EmailAddress', 10493, 0, 1, 1, N'Obligor', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1220, N'37.16', N'EmailAddress', 10496, 0, 1, 1, N'PayTo', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1221, N'40.16', N'EmailAddress', 10499, 0, 1, 1, N'ReimburseOn', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1222, N'21.16', N'EmailAddress', 10266, 0, 1, 1, N'Remitter', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1223, N'33.16', N'EmailAddress', 10278, 0, 1, 1, N'CollectFrom', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1224, N'35.16', N'EmailAddress', 10280, 0, 1, 1, N'Drawee', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1225, N'36.16', N'EmailAddress', 10281, 0, 1, 1, N'Drawer', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1226, N'37.16', N'EmailAddress', 10282, 0, 1, 1, N'CreditTo', N'EmailAddress')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8271, N'89', N'DocumentSets', 10134, 4, 3, 1, N'DocumentSets', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8272, N'89.01', N'DocumentType', 8271, 0, 1, 1, N'DocumentSets', N'DocumentType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8273, N'89.02', N'NumberOrig', 8271, 0, 1, 1, N'DocumentSets', N'NumberOrig')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8274, N'89.03', N'NumberCopies', 8271, 0, 1, 1, N'DocumentSets', N'NumberCopies')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8275, N'89.04', N'Text', 8271, 0, 1, 1, N'DocumentSets', N'Text')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8276, N'0', N'COLBalance', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8282, N'0', N'GtsFees', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8283, N'1', N'Fees', 8282, 4, 3, 0, N'Fees', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8284, N'1.01', N'TransPkey', 8283, 0, 1, 1, N'Fees', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8285, N'1.02', N'GtsId', 8283, 0, 1, 1, N'Fees', N'GtsId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8286, N'1.03', N'GtsCode', 8283, 0, 1, 1, N'Fees', N'GtsCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8287, N'1.04', N'GtsDescription', 8283, 0, 1, 1, N'Fees', N'GtsDescription')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8288, N'1.05', N'CustomerCode', 8283, 0, 1, 1, N'Fees', N'CustomerCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8289, N'1.06', N'CustomerDescription', 8283, 0, 1, 1, N'Fees', N'CustomerDescription')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8290, N'1.07', N'Service', 8283, 0, 1, 1, N'Fees', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8291, N'1.08', N'Product', 8283, 0, 1, 1, N'Fees', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8292, N'1.09', N'EffectiveDate', 8283, 0, 1, 1, N'Fees', N'EffectiveDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8293, N'1.1', N'Amount', 8283, 0, 1, 1, N'Fees', N'Amount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8294, N'1.11', N'TransAmt', 8283, 0, 1, 1, N'Fees', N'TransAmt')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8295, N'1.12', N'Notes', 8283, 0, 1, 1, N'Fees', N'Notes')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8296, N'1.13', N'OutboundToDoPkey', 8283, 0, 1, 1, N'Fees', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8297, N'1.14', N'ReferenceNum', 8283, 0, 1, 1, N'Fees', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8298, N'1.15', N'RefTransferNum', 8283, 0, 1, 1, N'Fees', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8299, N'1.16', N'BankRef', 8283, 0, 1, 1, N'Fees', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8301, N'60', N'DocumentSets', 8276, 4, 3, 1, N'DocumentSets', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8302, N'60.01', N'DocumentType', 8301, 0, 1, 1, N'DocumentSets', N'DocumentType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8303, N'60.02', N'NumberOrig', 8301, 0, 1, 1, N'DocumentSets', N'NumberOrig')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8304, N'1.17', N'IccID', 8283, 0, 1, 1, N'Fees', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8305, N'1.18', N'IccType', 8283, 0, 1, 1, N'Fees', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8306, N'1.19', N'IccPkey', 8283, 0, 1, 1, N'Fees', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8307, N'60.03', N'NumberCopies', 8301, 0, 1, 1, N'DocumentSets', N'NumberCopies')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8308, N'60.04', N'Text', 8301, 0, 1, 1, N'DocumentSets', N'Text')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8312, N'85', N'IncoTerm', 10134, 0, 1, 1, N'LocPrimary', N'IncoTerm')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8313, N'86', N'IncoTermOther', 10134, 0, 1, 1, N'LocPrimary', N'IncoTermOther')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8314, N'87', N'PlacePort', 10134, 0, 1, 1, N'LocPrimary', N'PlacePort')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8315, N'1.2', N'LegalEntity', 8283, 0, 1, 1, N'Fees', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8326, N'0', N'PayStatus', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8338, N'1', N'OutboundToDoPkey', 8326, 0, 1, 1, N'PayStatus', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8339, N'2', N'IccType', 8326, 0, 1, 1, N'PayStatus', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8340, N'3', N'IccID', 8326, 0, 1, 1, N'PayStatus', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8341, N'43', N'Text', 10563, 0, 3, 0, N'Text', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8342, N'4', N'ReferenceNum', 8326, 0, 1, 1, N'PayStatus', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8347, N'0', N'iMail', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8348, N'1', N'IccID', 8347, 0, 1, 1, N'iMail', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8349, N'21', N'TransPkey', 8347, 0, 1, 1, N'iMail', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8350, N'2', N'OutboundToDoPkey', 8347, 0, 1, 1, N'iMail', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8351, N'43.01', N'DescGoods', 8341, 0, 1, 1, N'Text', N'DescGoods')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8352, N'43.02', N'AddConditions', 8341, 0, 1, 1, N'Text', N'AddConditions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8353, N'43.03', N'DocsRequired', 8341, 0, 1, 1, N'Text', N'DocsRequired')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8354, N'43.04', N'AddText', 8341, 0, 1, 1, N'Text', N'AddText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8355, N'43.05', N'FreeText', 8341, 0, 1, 1, N'Text', N'FreeText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8356, N'43.06', N'AppPrint', 8341, 0, 1, 1, N'Text', N'AppPrint')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8357, N'3', N'IccType', 8347, 0, 1, 1, N'iMail', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8358, N'4', N'Service', 8347, 0, 1, 1, N'iMail', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8359, N'5', N'Product', 8347, 0, 1, 1, N'iMail', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8360, N'6', N'ReferenceNum', 8347, 0, 1, 1, N'iMail', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8361, N'7', N'RefTransferNum', 8347, 0, 1, 1, N'iMail', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8362, N'8', N'BankRef', 8347, 0, 1, 1, N'iMail', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8363, N'9', N'LegalEntity', 8347, 0, 1, 1, N'iMail', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8365, N'84', N'STBAFlag', 10134, 0, 1, 1, N'Additional', N'STBAFlag')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8366, N'10', N'CustomerID', 8347, 0, 1, 1, N'iMail', N'CustomerID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8367, N'11', N'BranchID', 8347, 0, 1, 1, N'iMail', N'BranchID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8368, N'12', N'IccPcId', 8347, 0, 1, 1, N'iMail', N'IccPcId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8369, N'13', N'IccUser', 8347, 0, 1, 1, N'iMail', N'IccUser')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8370, N'14', N'IccSignOnID', 8347, 0, 1, 1, N'iMail', N'IccSignOnID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8371, N'15', N'GtsService', 8347, 0, 1, 1, N'iMail', N'GtsService')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8372, N'16', N'GtsProduct', 8347, 0, 1, 1, N'iMail', N'GtsProduct')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8373, N'17', N'TextData', 8347, 0, 1, 1, N'iMail', N'TextData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8374, N'18', N'Subject', 8347, 0, 1, 1, N'iMail', N'Subject')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8375, N'19', N'GtsUserPkey', 8347, 0, 1, 1, N'iMail', N'GtsUserPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8376, N'20', N'GtsUserID', 8347, 0, 1, 1, N'iMail', N'GtsUserID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8377, N'21', N'GtsName', 8347, 0, 1, 1, N'iMail', N'GtsName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8378, N'22', N'GtsPkey', 8347, 0, 1, 1, N'iMail', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8379, N'23', N'BankReference', 8347, 0, 1, 1, N'iMail', N'BankReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8393, N'5', N'RefTransferNum', 8326, 0, 1, 1, N'PayStatus', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8401, N'91', N'Files', 10134, 4, 3, 1, N'Files', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8402, N'44', N'Files', 10563, 4, 3, 1, N'Files', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8403, N'62', N'Files', 8276, 4, 3, 1, N'Files', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8405, N'6', N'BankRef', 8326, 0, 1, 1, N'PayStatus', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8406, N'7', N'Service', 8326, 0, 1, 1, N'PayStatus', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8407, N'8', N'Product', 8326, 0, 1, 1, N'PayStatus', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8408, N'9', N'TransPkey', 8326, 0, 1, 1, N'PayStatus', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8409, N'10', N'GtsPkey', 8326, 0, 1, 1, N'PayStatus', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8410, N'11', N'PresentorsRefNum', 8326, 0, 1, 1, N'PayStatus', N'PresentorsRefNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8411, N'12', N'OurReference', 8326, 0, 1, 1, N'PayStatus', N'OurReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8412, N'13', N'ApplicantName', 8326, 0, 1, 1, N'PayStatus', N'ApplicantName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8413, N'62.01', N'FileName', 8403, 0, 1, 1, N'Files', N'FileName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8414, N'62.02', N'FileType', 8403, 0, 1, 1, N'Files', N'FileType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8415, N'62.03', N'FileData', 8403, 0, 1, 1, N'Files', N'FileData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8416, N'91.01', N'FileName', 8401, 0, 1, 1, N'Files', N'FileName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8417, N'91.02', N'FileType', 8401, 0, 1, 1, N'Files', N'FileType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8418, N'91.03', N'FileData', 8401, 0, 1, 1, N'Files', N'FileData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8419, N'44.01', N'FileName', 8402, 0, 1, 1, N'Files', N'FileName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8420, N'44.02', N'FileType', 8402, 0, 1, 1, N'Files', N'FileType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8421, N'44.03', N'FileData', 8402, 0, 1, 1, N'Files', N'FileData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8425, N'14', N'DraftAmount', 8326, 0, 1, 1, N'PayStatus', N'DraftAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8426, N'15', N'DocsRcvdDate', 8326, 0, 1, 1, N'PayStatus', N'DocsRcvdDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8427, N'16', N'PayStatus', 8326, 0, 1, 1, N'PayStatus', N'PayStatus')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8428, N'17', N'Status', 8326, 0, 1, 1, N'PayStatus', N'Status')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8429, N'18', N'StatusDate', 8326, 0, 1, 1, N'PayStatus', N'StatusDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8430, N'19', N'AcceptMatDate', 8326, 0, 1, 1, N'PayStatus', N'AcceptMatDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8431, N'20', N'TenorPhrase', 8326, 0, 1, 1, N'PayStatus', N'TenorPhrase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8432, N'0', N'IccPkey', 8347, 0, 1, 1, N'iMail', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8444, N'21', N'BankFees', 8326, 0, 1, 1, N'PayStatus', N'BankFees')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8445, N'22', N'OtherBankFees', 8326, 0, 1, 1, N'PayStatus', N'OtherBankFees')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8490, N'23', N'LegalEntity', 8326, 0, 1, 1, N'PayStatus', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8499, N'19.01', N'IccPkey', 10154, 0, 1, 1, N'AdviseThru', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8500, N'20.02', N'GtsPkey', 10155, 0, 1, 1, N'ApplicantBank', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8501, N'30.02', N'GtsPkey', 10165, 0, 1, 1, N'Bene', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8502, N'53.01', N'IccPkey', 10189, 0, 1, 1, N'Opener', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8513, N'24', N'ClosedIndicator', 8326, 0, 1, 1, N'PayStatus', N'ClosedIndicator')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8582, N'59', N'DrawerReference', 8276, 0, 1, 1, N'ColPrimary', N'DrawerReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8602, N'0', N'GtsDocs', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8603, N'1', N'LegalEntity', 8602, 0, 1, 1, N'BankText', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8604, N'3', N'CustomerID', 8602, 0, 1, 1, N'BankText', N'CustomerID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8605, N'4', N'BranchID', 8602, 0, 1, 1, N'BankText', N'BranchID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8606, N'5', N'GtsHistoryPkey', 8602, 0, 1, 1, N'BankText', N'GtsHistoryPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8607, N'5', N'OurReference', 8602, 0, 1, 1, N'BankText', N'OurReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8608, N'6', N'BankReference', 8602, 0, 1, 1, N'BankText', N'BankReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8609, N'7', N'GtsService', 8602, 0, 1, 1, N'BankText', N'GtsService')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8610, N'8', N'GtsProduct', 8602, 0, 1, 1, N'BankText', N'GtsProduct')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8611, N'9', N'TextType', 8602, 0, 1, 1, N'BankText', N'TextType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8612, N'10', N'TextData', 8602, 0, 1, 1, N'BankText', N'TextData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8613, N'11', N'TextImageType', 8602, 0, 1, 1, N'BankText', N'TextImageType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8620, N'2', N'IccID', 8602, 0, 1, 1, N'BankText', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8627, N'12', N'TransPkey', 8602, 0, 1, 1, N'BankText', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8628, N'13', N'OutboundToDoPkey', 8602, 0, 1, 1, N'BankText', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8629, N'14', N'IccType', 8602, 0, 1, 1, N'BankText', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8630, N'15', N'ReferenceNum', 8602, 0, 1, 1, N'BankText', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8631, N'16', N'RefTransferNum', 8602, 0, 1, 1, N'BankText', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8632, N'17', N'BankRef', 8602, 0, 1, 1, N'BankText', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8633, N'18', N'Service', 8602, 0, 1, 1, N'BankText', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8634, N'19', N'Product', 8602, 0, 1, 1, N'BankText', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8636, N'8.5', N'IccPartyID', 8276, 0, 1, 1, N'Additional', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8637, N'8.5', N'IccPartyID', 10134, 0, 1, 1, N'Additional', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8638, N'1.5', N'IccPartyID', 10563, 0, 1, 1, N'Additional', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8639, N'81', N'AmendFlag', 10134, 0, 1, 1, N'Additional', N'AmendFlag')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8642, N'9998', N'IccPurposeCode', 10134, 0, 1, 1, N'Additional', N'IccPurposeCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8651, N'90', N'Text', 10134, 0, 3, 0, N'Text', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8652, N'90.01', N'DescGoods', 8651, 0, 1, 1, N'Text', N'DescGoods')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8653, N'90.02', N'AddConditions', 8651, 0, 1, 1, N'Text', N'AddConditions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8654, N'90.03', N'DocsRequired', 8651, 0, 1, 1, N'Text', N'DocsRequired')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8655, N'90.05', N'FreeText', 8651, 0, 1, 1, N'Text', N'FreeText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8656, N'90.04', N'AddText', 8651, 0, 1, 1, N'Text', N'AddText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8692, N'0.1', N'Status', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8693, N'4', N'IccPkey', 8692, 0, 1, 1, N'Status', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8694, N'6', N'Service', 8692, 0, 1, 1, N'Status', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8695, N'8', N'Text', 8692, 0, 1, 1, N'Status', N'Text')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8702, N'5', N'IccType', 8692, 0, 1, 1, N'Status', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8706, N'1', N'TransPkey', 8692, 0, 1, 1, N'Status', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8707, N'2', N'OutboundToDoPkey', 8692, 0, 1, 1, N'Status', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8708, N'3', N'IccID', 8692, 0, 1, 1, N'Status', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8709, N'7', N'Product', 8692, 0, 1, 1, N'Status', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8722, N'21', N'IccType', 1040021, 0, 1, 1, N'AdvBank', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8723, N'22', N'IccID', 1040021, 0, 1, 1, N'AdvBank', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8724, N'23', N'Service', 1040021, 0, 1, 1, N'AdvBank', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8725, N'24', N'Product', 1040021, 0, 1, 1, N'AdvBank', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8726, N'10', N'IccType', 1040022, 0, 1, 1, N'FxRate', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8727, N'11', N'IccID', 1040022, 0, 1, 1, N'FxRate', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8728, N'12', N'Service', 1040022, 0, 1, 1, N'FxRate', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8729, N'13', N'Product', 1040022, 0, 1, 1, N'FxRate', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8742, N'20', N'OutboundToDoPkey', 1040021, 0, 1, 1, N'AdvBank', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8743, N'9', N'OutboundToDoPkey', 1040022, 0, 1, 1, N'FxRate', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8780, N'82', N'ExpirationPlace', 10134, 0, 1, 1, N'LocPrimary', N'ExpirationPlace')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8785, N'90.06', N'AppPrint', 8651, 0, 1, 1, N'Text', N'AppPrint')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8792, N'0', N'IccUsers', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8821, N'1', N'IccType', 8792, 0, 1, 1, N'XmlData', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8822, N'2', N'Service', 8792, 0, 1, 1, N'XmlData', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8823, N'3', N'Product', 8792, 0, 1, 1, N'XmlData', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8837, N'4', N'Users', 8792, 4, 3, 1, N'IccUsers', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8838, N'4.1', N'IccPcId', 8837, 0, 1, 1, N'IccUsers', N'IccPcId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8839, N'4.2', N'IccUser', 8837, 0, 1, 1, N'IccUsers', N'IccUser')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8879, N'61', N'DocText', 10706, 0, 1, 1, N'AdminMsg', N'DocText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8880, N'62', N'DocName', 10706, 0, 1, 1, N'AdminMsg', N'DocName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8909, N'990', N'FluctuatingBalance', 10134, 0, 1, 1, N'LocPrimary', N'FluctuatingBalance')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8910, N'991', N'MultipleDraw', 10134, 0, 1, 1, N'LocPrimary', N'MultipleDraw')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8911, N'992', N'BondDeal', 10134, 0, 1, 1, N'LocPrimary', N'BondDeal')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8912, N'993', N'CommunityInvestment', 10134, 0, 1, 1, N'LocPrimary', N'CommunityInvestment')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8913, N'994', N'TaxExempt', 10134, 0, 1, 1, N'LocPrimary', N'TaxExempt')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8914, N'995', N'LateFee', 10134, 0, 1, 1, N'LocPrimary', N'LateFee')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8915, N'996', N'Exceptions', 10134, 0, 1, 1, N'LocPrimary', N'Exceptions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8916, N'998', N'CoUAverageDailyBalance', 10134, 0, 1, 1, N'LocPrimary', N'CoUAverageDailyBalance')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8917, N'997', N'LcPurpose', 10134, 0, 1, 1, N'LocPrimary', N'LcPurpose')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8918, N'999', N'CoUCollateralizationPercentage', 10134, 0, 1, 1, N'LocPrimary', N'CoUCollateralizationPercentage')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8923, N'90.08', N'ExcText', 8651, 0, 1, 1, N'Text', N'ExcText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8966, N'9991', N'CoUUtilizedAmount', 10134, 0, 1, 1, N'LocPrimary', N'CoUUtilizedAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (8975, N'88', N'PaymentDetails', 10134, 0, 1, 1, N'LocPrimary', N'PaymentDetails')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (9164, N'90.07', N'PayConds', 8651, 0, 1, 1, N'Text', N'PayConds')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (9165, N'96', N'RequestToCancel', 10134, 0, 1, 1, N'Additional', N'RequestToCancel')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (9166, N'97', N'AmdChargePayableBy', 10134, 0, 1, 1, N'LocPrimary', N'AmdChargePayableBy')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (9167, N'98', N'AmdChargeNarrative', 10134, 0, 1, 1, N'LocPrimary', N'AmdChargeNarrative')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (9168, N'99', N'ConfirmationCharge', 10134, 0, 1, 1, N'LocPrimary', N'ConfirmationCharge')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10003, N'19.02', N'GtsPkey', 10154, 0, 1, 1, N'AdviseThru', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10004, N'19.04', N'GtsPartyID', 10154, 0, 1, 1, N'AdviseThru', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10005, N'19.05', N'LegalEntity', 10154, 0, 1, 1, N'AdviseThru', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10006, N'19.1', N'Address4', 10154, 0, 1, 1, N'AdviseThru', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10007, N'19.11', N'CountryCode', 10154, 0, 1, 1, N'AdviseThru', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10008, N'19.12', N'City', 10154, 0, 1, 1, N'AdviseThru', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10009, N'19.13', N'State', 10154, 0, 1, 1, N'AdviseThru', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10010, N'19.14', N'ZipCode', 10154, 0, 1, 1, N'AdviseThru', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10013, N'20.01', N'IccPkey', 10155, 0, 1, 1, N'ApplicantBank', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10014, N'20.03', N'IccPartyID', 10155, 0, 1, 1, N'ApplicantBank', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10015, N'20.05', N'LegalEntity', 10155, 0, 1, 1, N'ApplicantBank', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10016, N'20.1', N'Address4', 10155, 0, 1, 1, N'ApplicantBank', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10017, N'20.11', N'CountryCode', 10155, 0, 1, 1, N'ApplicantBank', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10018, N'20.12', N'City', 10155, 0, 1, 1, N'ApplicantBank', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10019, N'20.13', N'State', 10155, 0, 1, 1, N'ApplicantBank', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10020, N'20.14', N'ZipCode', 10155, 0, 1, 1, N'ApplicantBank', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10021, N'30.01', N'IccPkey', 10165, 0, 1, 1, N'Bene', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10022, N'30.03', N'IccPartyID', 10165, 0, 1, 1, N'Bene', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10023, N'30.05', N'LegalEntity', 10165, 0, 1, 1, N'Bene', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10024, N'30.1', N'Address4', 10165, 0, 1, 1, N'Bene', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10025, N'30.11', N'CountryCode', 10165, 0, 1, 1, N'Bene', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10026, N'30.12', N'City', 10165, 0, 1, 1, N'Bene', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10027, N'30.13', N'State', 10165, 0, 1, 1, N'Bene', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10028, N'30.14', N'ZipCode', 10165, 0, 1, 1, N'Bene', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10029, N'53.02', N'GtsPkey', 10189, 0, 1, 1, N'Opener', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10030, N'53.04', N'GtsPartyID', 10189, 0, 1, 1, N'Opener', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10031, N'53.05', N'LegalEntity', 10189, 0, 1, 1, N'Opener', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10032, N'53.1', N'Address4', 10189, 0, 1, 1, N'Opener', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10033, N'53.11', N'CountryCode', 10189, 0, 1, 1, N'Opener', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10034, N'53.12', N'City', 10189, 0, 1, 1, N'Opener', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10035, N'53.13', N'State', 10189, 0, 1, 1, N'Opener', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10036, N'53.14', N'ZipCode', 10189, 0, 1, 1, N'Opener', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10134, N'0', N'LCBalance', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10135, N'', N'ZDoc-Index', 0, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10136, N'1', N'GtsPkey', 10134, 0, 1, 1, N'Additional', N'GtsPKey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10137, N'2', N'IccPkey', 10134, 0, 1, 1, N'Additional', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10138, N'3', N'CustomerId', 10134, 0, 1, 1, N'Additional', N'CustomerId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10139, N'4', N'BranchId', 10134, 0, 1, 1, N'Additional', N'BranchId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10140, N'5', N'TransPkey', 10134, 0, 1, 1, N'Additional', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10141, N'6', N'OutboundToDoPkey', 10134, 0, 1, 1, N'Additional', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10142, N'7', N'IccType', 10134, 0, 1, 1, N'Additional', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10143, N'8', N'IccID', 10134, 0, 1, 1, N'Additional', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10144, N'9', N'ReferenceNum', 10134, 0, 1, 1, N'Additional', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10145, N'10', N'RefTransferNum', 10134, 0, 1, 1, N'Additional', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10146, N'11', N'BankRef', 10134, 0, 1, 1, N'Additional', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10147, N'12', N'Service', 10134, 0, 1, 1, N'Additional', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10148, N'13', N'Product', 10134, 0, 1, 1, N'Additional', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10149, N'14', N'TransAmount', 10134, 0, 1, 1, N'Additional', N'TransAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10150, N'15', N'BankID', 10134, 0, 1, 1, N'Additional', N'BankID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10151, N'16', N'BankReference', 10134, 0, 1, 1, N'Additional', N'BankReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10152, N'17', N'SeqNumber', 10134, 0, 1, 1, N'Additional', N'SeqNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10153, N'18', N'Notes', 10134, 0, 1, 1, N'Additional', N'Notes')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10154, N'19', N'AdviseThru', 10134, 0, 3, 0, N'AdviseThru', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10155, N'20', N'ApplicantBank', 10134, 0, 3, 0, N'ApplcantBank', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10156, N'21', N'AutoExtNotifDay', 10134, 0, 1, 1, N'LocPrimary', N'AutoExtNotifDay')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10157, N'22', N'AutoExtTermDate', 10134, 0, 1, 1, N'LocPrimary', N'AutoExtTermDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10158, N'23', N'AutoExtTermDays', 10134, 0, 1, 1, N'LocPrimary', N'AutoExtTermDays')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10159, N'24', N'AutoExtTermsMonth', 10134, 0, 1, 1, N'LocPrimary', N'AutoExtTermsMonth')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10160, N'25', N'AutoRedNotifDay', 10134, 0, 1, 1, N'LocPrimary', N'AutoRedNotifDay')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10161, N'26', N'AvailableofCredit', 10134, 0, 1, 1, N'LocPrimary', N'AvailableofCredit')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10162, N'27', N'AvailableWith', 10134, 0, 1, 1, N'LocPrimary', N'AvailableWith')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10163, N'28', N'AvailableWithContinued', 10134, 0, 1, 1, N'LocPrimary', N'AvailableWithContinued')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10164, N'29', N'BeneAttentTo', 10134, 0, 1, 1, N'LocPrimary', N'BeneAttentTo')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10165, N'30', N'Bene', 10134, 0, 3, 0, N'Bene', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10166, N'31', N'Charges', 10134, 0, 1, 1, N'LocPrimary', N'Charges')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10167, N'32', N'ConfirmInstructions', 10134, 0, 1, 1, N'LocPrimary', N'ConfirmInstructions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10168, N'33', N'CurrencyCode', 10134, 0, 1, 1, N'LocPrimary', N'CurrencyCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10169, N'34', N'DateOptions', 10134, 0, 1, 1, N'LocPrimary', N'DateOptions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10170, N'35', N'DaysPresentDocument', 10134, 0, 1, 1, N'LocPrimary', N'DaysPresentDocument')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10171, N'36', N'DraftsAtPercent', 10134, 0, 1, 1, N'LocPrimary', N'DraftsAtPercent')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10172, N'37', N'DraftsDrawnOn', 10134, 0, 1, 1, N'LocPrimary', N'DraftsDrawnOn')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10173, N'38', N'DraftsDrawnOnContinued', 10134, 0, 1, 1, N'LocPrimary', N'DraftsDrawnOnContinued')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10174, N'39', N'DraftsPercentOf', 10134, 0, 1, 1, N'LocPrimary', N'DraftsPercentOf')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10175, N'40', N'EarliestShipDate', 10134, 0, 1, 1, N'LocPrimary', N'EarliestShipDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10176, N'41', N'EffectiveDate', 10134, 0, 1, 1, N'LocPrimary', N'EffectiveDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10177, N'42', N'ExpirationDate', 10134, 0, 1, 1, N'LocPrimary', N'ExpirationDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10178, N'43', N'Expired', 10134, 0, 1, 1, N'LocPrimary', N'Expired')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10179, N'44', N'FaceAmount', 10134, 0, 1, 1, N'LocPrimary', N'FaceAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10181, N'45', N'FaceAmountBase', 10134, 0, 1, 1, N'LocPrimary', N'FaceAmountBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10182, N'46', N'FxContract', 10134, 0, 1, 1, N'LocPrimary', N'FXContract')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10183, N'47', N'FxRate', 10134, 0, 1, 1, N'LocPrimary', N'FXRate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10184, N'48', N'IssueDate', 10134, 0, 1, 1, N'LocPrimary', N'IssueDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10185, N'49', N'LatestShipDate', 10134, 0, 1, 1, N'LocPrimary', N'LatestShipDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10186, N'50', N'LiabilityAmount', 10134, 0, 1, 1, N'LocPrimary', N'LiabilityAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10187, N'51', N'LiabilityAmountBase', 10134, 0, 1, 1, N'LocPrimary', N'LiabilityAmountBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10188, N'52', N'MultTenorPhrase', 10134, 0, 1, 1, N'LocPrimary', N'MultiTenorPhrase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10189, N'53', N'Opener', 10134, 0, 3, 0, N'Opener', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10190, N'54', N'PartialShip', 10134, 0, 1, 1, N'LocPrimary', N'PartialShip')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10191, N'55', N'PartialShipConditions', 10134, 0, 1, 1, N'LocPrimary', N'PartialShipConditions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10192, N'56', N'PortOfDischarge', 10134, 0, 1, 1, N'LocPrimary', N'PortOfDischarge')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10193, N'57', N'PortOfLoading', 10134, 0, 1, 1, N'LocPrimary', N'PortOfLoading')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10195, N'59', N'ShipFrom', 10134, 0, 1, 1, N'LocPrimary', N'ShipFrom')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10196, N'60', N'ShipTo', 10134, 0, 1, 1, N'LocPrimary', N'ShipTo')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10197, N'61', N'ShipVia', 10134, 0, 1, 1, N'LocPrimary', N'ShipVia')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10198, N'62', N'ShipmentPeriod', 10134, 0, 1, 1, N'LocPrimary', N'ShipmentPeriod')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10199, N'63', N'TenorDays', 10134, 0, 1, 1, N'LocPrimary', N'TenorDays')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10200, N'64', N'TenorDays1', 10134, 0, 1, 1, N'LocPrimary', N'TenorDays1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10201, N'65', N'TenorPercent', 10134, 0, 1, 1, N'LocPrimary', N'TenorPercent')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10202, N'66', N'TenorPercent1', 10134, 0, 1, 1, N'LocPrimary', N'TenorPercent1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10203, N'67', N'TenorPhrase', 10134, 0, 1, 1, N'LocPrimary', N'TenorPhrase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10204, N'68', N'TenorPhrase1', 10134, 0, 1, 1, N'LocPrimary', N'TenorPhrase1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10205, N'69', N'ToleranceMinus', 10134, 0, 1, 1, N'LocPrimary', N'ToleranceMinus')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10206, N'70', N'TolerancePlus', 10134, 0, 1, 1, N'LocPrimary', N'TolerancePlus')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10207, N'71', N'Transferable', 10134, 0, 1, 1, N'LocPrimary', N'Transferable')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10208, N'72', N'TransferableConditions', 10134, 0, 1, 1, N'LocPrimary', N'TransferableConditions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10209, N'73', N'TransShip', 10134, 0, 1, 1, N'LocPrimary', N'TransShip')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10210, N'74', N'TransShipConditions', 10134, 0, 1, 1, N'LocPrimary', N'TransShipConditions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10211, N'75', N'TypeCredit', 10134, 0, 1, 1, N'LocPrimary', N'TypeCredit')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10212, N'76', N'UCPCode', 10134, 0, 1, 1, N'LocPrimary', N'UCPCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10213, N'77', N'UCPOther', 10134, 0, 1, 1, N'LocPrimary', N'UCPOther')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10218, N'78', N'LegalEntity', 10134, 0, 1, 1, N'Additional', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10219, N'19.03', N'IccPartyID', 10154, 0, 1, 1, N'AdviseThru', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10220, N'19.06', N'Name', 10154, 0, 1, 1, N'AdviseThru', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10221, N'19.07', N'Address1', 10154, 0, 1, 1, N'AdviseThru', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10222, N'19.08', N'Address2', 10154, 0, 1, 1, N'AdviseThru', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10223, N'19.09', N'Address3', 10154, 0, 1, 1, N'AdviseThru', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10224, N'20.04', N'GtsPartyID', 10155, 0, 1, 1, N'ApplicantBank', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10225, N'20.06', N'Name', 10155, 0, 1, 1, N'ApplicantBank', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10226, N'20.07', N'Address1', 10155, 0, 1, 1, N'ApplicantBank', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10227, N'20.08', N'Address2', 10155, 0, 1, 1, N'ApplicantBank', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10228, N'20.09', N'Address3', 10155, 0, 1, 1, N'ApplicantBank', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10229, N'30.04', N'GtsPartyID', 10165, 0, 1, 1, N'Bene', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10230, N'30.06', N'Name', 10165, 0, 1, 1, N'Bene', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10231, N'30.07', N'Address1', 10165, 0, 1, 1, N'Bene', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10232, N'30.08', N'Address2', 10165, 0, 1, 1, N'Bene', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10233, N'30.09', N'Address3', 10165, 0, 1, 1, N'Bene', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10234, N'53.03', N'IccPartyID', 10189, 0, 1, 1, N'Opener', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10235, N'53.06', N'Name', 10189, 0, 1, 1, N'Opener', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10236, N'53.07', N'Address1', 10189, 0, 1, 1, N'Opener', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10237, N'53.08', N'Address2', 10189, 0, 1, 1, N'Opener', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10238, N'53.09', N'Address3', 10189, 0, 1, 1, N'Opener', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10239, N'79', N'OurReferenceNum', 10134, 0, 1, 1, N'LocPrimary', N'OurReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10240, N'80', N'OurRefTransferNum', 10134, 0, 1, 1, N'LocPrimary', N'OurRefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10246, N'1', N'IccPkey', 8276, 0, 1, 1, N'Additional', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10247, N'2', N'GtsPkey', 8276, 0, 1, 1, N'Additional', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10248, N'3', N'CustomerId', 8276, 0, 1, 1, N'Additional', N'CustomerId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10249, N'4', N'BranchId', 8276, 0, 1, 1, N'Additional', N'BranchId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10250, N'5', N'TransPkey', 8276, 0, 1, 1, N'Additional', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10251, N'6', N'OutboundToDoPkey', 8276, 0, 1, 1, N'Additional', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10252, N'7', N'IccType', 8276, 0, 1, 1, N'Additional', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10253, N'8', N'IccID', 8276, 0, 1, 1, N'Additional', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10254, N'9', N'LegalEntity', 8276, 0, 1, 1, N'Additional', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10255, N'10', N'ReferenceNum', 8276, 0, 1, 1, N'Additional', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10256, N'11', N'RefTransferNum', 8276, 0, 1, 1, N'Additional', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10257, N'12', N'BankRef', 8276, 0, 1, 1, N'Additional', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10258, N'13', N'Service', 8276, 0, 1, 1, N'Additional', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10259, N'14', N'Product', 8276, 0, 1, 1, N'Additional', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10260, N'15', N'TransAmount', 8276, 0, 1, 1, N'Additional', N'TransAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10261, N'16', N'AmendFlag', 8276, 0, 1, 1, N'Additional', N'AmendFlag')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10262, N'17', N'BankID', 8276, 0, 1, 1, N'Additional', N'BankID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10263, N'18', N'BankReference', 8276, 0, 1, 1, N'Additional', N'BankReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10264, N'19', N'SeqNumber', 8276, 0, 1, 1, N'Additional', N'SeqNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10265, N'20', N'Notes', 8276, 0, 1, 1, N'Additional', N'Notes')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10266, N'21', N'Remitter', 8276, 0, 3, 0, N'Remitter', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10267, N'22', N'RemitterReference', 8276, 0, 1, 1, N'ColPrimary', N'RemitterReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10268, N'23', N'OriginalAmount', 8276, 0, 1, 1, N'ColPrimary', N'OriginalAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10269, N'24', N'OriginalAmountBase', 8276, 0, 1, 1, N'ColPrimary', N'OriginalAmountBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10270, N'25', N'CurrencyCode', 8276, 0, 1, 1, N'ColPrimary', N'CurrencyCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10271, N'26', N'FxRate', 8276, 0, 1, 1, N'ColPrimary', N'FxRate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10272, N'27', N'FxContract', 8276, 0, 1, 1, N'ColPrimary', N'FxContract')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10273, N'28', N'DocumentDate', 8276, 0, 1, 1, N'ColPrimary', N'DocumentDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10274, N'29', N'MaturityDate', 8276, 0, 1, 1, N'ColPrimary', N'MaturityDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10275, N'30', N'BankCharges', 8276, 0, 1, 1, N'ColPrimary', N'BankCharges')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10276, N'31', N'TenorDays', 8276, 0, 1, 1, N'ColPrimary', N'TenorDays')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10277, N'32', N'TenorPhrase', 8276, 0, 1, 1, N'ColPrimary', N'TenorPhrase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10278, N'33', N'CollectFrom', 8276, 0, 3, 0, N'CollectFrom', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10279, N'34', N'CollectFromReference', 8276, 0, 1, 1, N'ColPrimary', N'CollectFromReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10280, N'35', N'Drawee', 8276, 0, 3, 0, N'Drawee', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10281, N'36', N'Drawer', 8276, 0, 3, 0, N'Drawer', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10282, N'37', N'CreditTo', 8276, 0, 3, 0, N'CreditTo', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10283, N'38', N'Covering', 8276, 0, 1, 1, N'ColPrimary', N'Covering')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10284, N'39', N'CollectionType', 8276, 0, 1, 1, N'ColPrimary', N'CollectionType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10285, N'40', N'OtherTenor', 8276, 0, 1, 1, N'ColPrimary', N'OtherTenor')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10286, N'41', N'BlNumber', 8276, 0, 1, 1, N'ColPrimary', N'BlNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10287, N'42', N'ReleaseDocument', 8276, 0, 1, 1, N'ColPrimary', N'ReleaseDocument')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10288, N'43', N'VesselName', 8276, 0, 1, 1, N'ColPrimary', N'VesselName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10289, N'44', N'ShipFrom', 8276, 0, 1, 1, N'ColPrimary', N'ShipFrom')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10290, N'45', N'ShipTo', 8276, 0, 1, 1, N'ColPrimary', N'ShipTo')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10291, N'46', N'ConsignedTo', 8276, 0, 1, 1, N'ColPrimary', N'ConsignedTo')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10292, N'61', N'Text', 8276, 0, 3, 0, N'Text', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10293, N'61.01', N'FreeText', 10292, 0, 1, 1, N'Text', N'FreeText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10294, N'61.02', N'AppPrint', 10292, 0, 1, 1, N'Text', N'AppPrint')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10295, N'37.01', N'IccPkey', 10282, 0, 1, 1, N'CreditTo', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10296, N'37.02', N'GtsPkey', 10282, 0, 1, 1, N'CreditTo', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10297, N'37.03', N'IccPartyID', 10282, 0, 1, 1, N'CreditTo', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10298, N'37.04', N'GtsPartyID', 10282, 0, 1, 1, N'CreditTo', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10299, N'37.05', N'LegalEntity', 10282, 0, 1, 1, N'CreditTo', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10300, N'37.06', N'Name', 10282, 0, 1, 1, N'CreditTo', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10301, N'37.07', N'Address1', 10282, 0, 1, 1, N'CreditTo', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10302, N'37.08', N'Address2', 10282, 0, 1, 1, N'CreditTo', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10303, N'37.09', N'Address3', 10282, 0, 1, 1, N'CreditTo', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10304, N'37.1', N'Address4', 10282, 0, 1, 1, N'CreditTo', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10305, N'37.11', N'CountryCode', 10282, 0, 1, 1, N'CreditTo', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10306, N'37.12', N'City', 10282, 0, 1, 1, N'CreditTo', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10307, N'37.13', N'State', 10282, 0, 1, 1, N'CreditTo', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10308, N'37.14', N'ZipCode', 10282, 0, 1, 1, N'CreditTo', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10309, N'36.01', N'IccPkey', 10281, 0, 1, 1, N'Drawer', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10310, N'36.02', N'GtsPkey', 10281, 0, 1, 1, N'Drawer', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10311, N'36.03', N'IccPartyID', 10281, 0, 1, 1, N'Drawer', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10312, N'36.04', N'GtsPartyID', 10281, 0, 1, 1, N'Drawer', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10313, N'36.05', N'LegalEntity', 10281, 0, 1, 1, N'Drawer', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10314, N'36.06', N'Name', 10281, 0, 1, 1, N'Drawer', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10315, N'36.07', N'Address1', 10281, 0, 1, 1, N'Drawer', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10316, N'36.08', N'Address2', 10281, 0, 1, 1, N'Drawer', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10317, N'36.09', N'Address3', 10281, 0, 1, 1, N'Drawer', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10318, N'36.1', N'Address4', 10281, 0, 1, 1, N'Drawer', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10319, N'36.11', N'CountryCode', 10281, 0, 1, 1, N'Drawer', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10320, N'36.12', N'City', 10281, 0, 1, 1, N'Drawer', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10321, N'36.13', N'State', 10281, 0, 1, 1, N'Drawer', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10322, N'36.14', N'ZipCode', 10281, 0, 1, 1, N'Drawer', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10323, N'35.01', N'IccPkey', 10280, 0, 1, 1, N'Drawee', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10324, N'35.02', N'GtsPkey', 10280, 0, 1, 1, N'Drawee', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10325, N'35.03', N'IccPartyID', 10280, 0, 1, 1, N'Drawee', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10326, N'35.04', N'GtsPartyID', 10280, 0, 1, 1, N'Drawee', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10327, N'35.05', N'LegalEntity', 10280, 0, 1, 1, N'Drawee', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10328, N'35.06', N'Name', 10280, 0, 1, 1, N'Drawee', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10329, N'35.07', N'Address1', 10280, 0, 1, 1, N'Drawee', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10330, N'35.08', N'Address2', 10280, 0, 1, 1, N'Drawee', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10331, N'35.09', N'Address3', 10280, 0, 1, 1, N'Drawee', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10332, N'35.1', N'Address4', 10280, 0, 1, 1, N'Drawee', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10333, N'35.11', N'CountryCode', 10280, 0, 1, 1, N'Drawee', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10334, N'35.12', N'City', 10280, 0, 1, 1, N'Drawee', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10335, N'35.13', N'State', 10280, 0, 1, 1, N'Drawee', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10336, N'35.14', N'ZipCode', 10280, 0, 1, 1, N'Drawee', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10337, N'33.01', N'IccPkey', 10278, 0, 1, 1, N'CollectFrom', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10338, N'33.02', N'GtsPkey', 10278, 0, 1, 1, N'CollectFrom', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10339, N'33.03', N'IccPartyID', 10278, 0, 1, 1, N'CollectFrom', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10340, N'33.04', N'GtsPartyID', 10278, 0, 1, 1, N'CollectFrom', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10341, N'33.05', N'LegalEntity', 10278, 0, 1, 1, N'CollectFrom', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10342, N'33.06', N'Name', 10278, 0, 1, 1, N'CollectFrom', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10343, N'33.07', N'Address1', 10278, 0, 1, 1, N'CollectFrom', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10344, N'33.08', N'Address2', 10278, 0, 1, 1, N'CollectFrom', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10345, N'33.09', N'Address3', 10278, 0, 1, 1, N'CollectFrom', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10346, N'33.1', N'Address4', 10278, 0, 1, 1, N'CollectFrom', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10347, N'33.11', N'CountryCode', 10278, 0, 1, 1, N'CollectFrom', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10348, N'33.12', N'City', 10278, 0, 1, 1, N'CollectFrom', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10349, N'33.13', N'State', 10278, 0, 1, 1, N'CollectFrom', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10350, N'33.14', N'ZipCode', 10278, 0, 1, 1, N'CollectFrom', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10351, N'21.01', N'IccPkey', 10266, 0, 1, 1, N'Remitter', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10352, N'21.02', N'GtsPkey', 10266, 0, 1, 1, N'Remitter', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10353, N'21.03', N'IccPartyID', 10266, 0, 1, 1, N'Remitter', N'IccPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10354, N'21.04', N'GtsPartyID', 10266, 0, 1, 1, N'Remitter', N'GtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10355, N'21.05', N'LegalEntity', 10266, 0, 1, 1, N'Remitter', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10356, N'21.06', N'Name', 10266, 0, 1, 1, N'Remitter', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10357, N'21.07', N'Address1', 10266, 0, 1, 1, N'Remitter', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10358, N'21.08', N'Address2', 10266, 0, 1, 1, N'Remitter', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10359, N'21.09', N'Address3', 10266, 0, 1, 1, N'Remitter', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10360, N'21.1', N'Address4', 10266, 0, 1, 1, N'Remitter', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10361, N'21.11', N'CountryCode', 10266, 0, 1, 1, N'Remitter', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10362, N'21.12', N'City', 10266, 0, 1, 1, N'Remitter', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10363, N'21.13', N'State', 10266, 0, 1, 1, N'Remitter', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10364, N'21.14', N'ZipCode', 10266, 0, 1, 1, N'Remitter', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10418, N'47', N'AmountOutstanding', 8276, 0, 1, 1, N'ColPrimary', N'AmountOutstanding')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10419, N'48', N'AmountOutstandingBase', 8276, 0, 1, 1, N'ColPrimary', N'AmountOutstandingBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10420, N'49', N'TransAmountBase', 8276, 0, 1, 1, N'Additional', N'TransAmountBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10438, N'83', N'TransAmountBase', 10134, 0, 1, 1, N'Additional', N'TransAmountBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10459, N'0', N'BABalance', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10460, N'1', N'IccID', 10459, 0, 1, 1, N'Additional', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10461, N'2', N'TransPkey', 10459, 0, 1, 1, N'Additional', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10462, N'3', N'OutboundToDoPkey', 10459, 0, 1, 1, N'Additional', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10463, N'4', N'IccType', 10459, 0, 1, 1, N'Additional', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10464, N'5', N'Service', 10459, 0, 1, 1, N'Additional', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10465, N'6', N'Product', 10459, 0, 1, 1, N'Additional', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10466, N'7', N'ReferenceNum', 10459, 0, 1, 1, N'Additional', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10467, N'8', N'RefTransferNum', 10459, 0, 1, 1, N'Additional', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10468, N'9', N'BankRef', 10459, 0, 1, 1, N'Additional', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10469, N'10', N'TextData', 10459, 0, 1, 1, N'Additional', N'TextData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10470, N'11', N'GtsPkey', 10459, 0, 1, 1, N'BaPrimary', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10471, N'12', N'GtsService', 10459, 0, 1, 1, N'BaPrimary', N'GtsService')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10472, N'13', N'GtsProduct', 10459, 0, 1, 1, N'BaPrimary', N'GtsProduct')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10473, N'14', N'LegalEntity', 10459, 0, 1, 1, N'BaPrimary', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10474, N'15', N'BankReference', 10459, 0, 1, 1, N'BaPrimary', N'BankReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10475, N'16', N'BaType', 10459, 0, 1, 1, N'BaPrimary', N'BaType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10476, N'17', N'CleanBa', 10459, 0, 1, 1, N'BaPrimary', N'CleanBa')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10477, N'18', N'TenorDate', 10459, 0, 1, 1, N'BaPrimary', N'TenorDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10478, N'19', N'EligibleIneligibleFlag', 10459, 0, 1, 1, N'BaPrimary', N'EligibleIneligibleFlag')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10479, N'20', N'CurrencyCode', 10459, 0, 1, 1, N'BaPrimary', N'CurrencyCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10480, N'21', N'FxRate', 10459, 0, 1, 1, N'BaPrimary', N'FxRate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10481, N'22', N'DraftNumber', 10459, 0, 1, 1, N'BaPrimary', N'DraftNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10482, N'23', N'CustomerStatus', 10459, 0, 1, 1, N'BaPrimary', N'CustomerStatus')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10483, N'24', N'BankStatus', 10459, 0, 1, 1, N'BaPrimary', N'BankStatus')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10484, N'25', N'DraftDisposition', 10459, 0, 1, 1, N'BaPrimary', N'DraftDisposition')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10485, N'26', N'DateMaturity', 10459, 0, 1, 1, N'BaPrimary', N'DateMaturity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10486, N'27', N'FaceAmount', 10459, 0, 1, 1, N'BaPrimary', N'FaceAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10487, N'28', N'FaceAmountBase', 10459, 0, 1, 1, N'BaPrimary', N'FaceAmountBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10488, N'29', N'NetOutstandingAmount', 10459, 0, 1, 1, N'BaPrimary', N'NetOutstandingAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10489, N'30', N'NetOutstandingAmountBase', 10459, 0, 1, 1, N'BaPrimary', N'NetOutstandingAmountBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10490, N'31', N'DiscountRate', 10459, 0, 1, 1, N'BaPrimary', N'DiscountRate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10491, N'32', N'RebateRate', 10459, 0, 1, 1, N'BaPrimary', N'RebateRate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10492, N'33', N'ObligorReference', 10459, 0, 1, 1, N'BaPrimary', N'ObligorReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10493, N'34', N'Obligor', 10459, 0, 3, 0, N'Obligor', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10494, N'35', N'PayToHow', 10459, 0, 1, 1, N'BaPrimary', N'PayToHow')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10495, N'36', N'PayToRefNum', 10459, 0, 1, 1, N'BaPrimary', N'PayToRefNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10496, N'37', N'PayTo', 10459, 0, 3, 0, N'PayTo', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10497, N'38', N'ReimburseHow', 10459, 0, 1, 1, N'BaPrimary', N'ReimburseHow')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10498, N'39', N'ReimbOnRefNum', 10459, 0, 1, 1, N'BaPrimary', N'ReimbOnRefNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10499, N'40', N'ReimburseOn', 10459, 0, 3, 0, N'ReimburseOn', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10500, N'34.01', N'IccPkey', 10493, 0, 1, 1, N'Obligor', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10501, N'34.02', N'GtsPkey', 10493, 0, 1, 1, N'Obligor', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10502, N'34.03', N'IccPartyId', 10493, 0, 1, 1, N'Obligor', N'IccPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10503, N'34.04', N'GtsPartyId', 10493, 0, 1, 1, N'Obligor', N'GtsPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10504, N'34.05', N'LegalEntity', 10493, 0, 1, 1, N'Obligor', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10505, N'34.06', N'Name', 10493, 0, 1, 1, N'Obligor', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10506, N'34.07', N'Address1', 10493, 0, 1, 1, N'Obligor', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10507, N'34.08', N'Address2', 10493, 0, 1, 1, N'Obligor', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10508, N'34.09', N'Address3', 10493, 0, 1, 1, N'Obligor', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10509, N'34.1', N'Address4', 10493, 0, 1, 1, N'Obligor', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10510, N'34.11', N'CountryCode', 10493, 0, 1, 1, N'Obligor', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10511, N'34.12', N'City', 10493, 0, 1, 1, N'Obligor', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10512, N'34.13', N'State', 10493, 0, 1, 1, N'Obligor', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10513, N'34.14', N'ZipCode', 10493, 0, 1, 1, N'Obligor', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10514, N'37.01', N'IccPkey', 10496, 0, 1, 1, N'PayTo', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10515, N'37.02', N'GtsPkey', 10496, 0, 1, 1, N'PayTo', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10516, N'37.03', N'IccPartyId', 10496, 0, 1, 1, N'PayTo', N'IccPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10517, N'37.04', N'GtsPartyId', 10496, 0, 1, 1, N'PayTo', N'GtsPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10518, N'37.05', N'LegalEntity', 10496, 0, 1, 1, N'PayTo', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10519, N'37.06', N'Name', 10496, 0, 1, 1, N'PayTo', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10520, N'37.07', N'Address1', 10496, 0, 1, 1, N'PayTo', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10521, N'37.08', N'Address2', 10496, 0, 1, 1, N'PayTo', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10522, N'37.09', N'Address3', 10496, 0, 1, 1, N'PayTo', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10523, N'37.1', N'Address4', 10496, 0, 1, 1, N'PayTo', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10524, N'37.11', N'CountryCode', 10496, 0, 1, 1, N'PayTo', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10525, N'37.12', N'City', 10496, 0, 1, 1, N'PayTo', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10526, N'37.13', N'State', 10496, 0, 1, 1, N'PayTo', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10527, N'37.14', N'ZipCode', 10496, 0, 1, 1, N'PayTo', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10528, N'40.01', N'IccPkey', 10499, 0, 1, 1, N'ReimburseOn', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10529, N'40.02', N'GtsPkey', 10499, 0, 1, 1, N'ReimburseOn', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10530, N'40.03', N'IccPartyId', 10499, 0, 1, 1, N'ReimburseOn', N'IccPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10531, N'40.04', N'GtsPartyId', 10499, 0, 1, 1, N'ReimburseOn', N'GtsPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10532, N'40.05', N'LegalEntity', 10499, 0, 1, 1, N'ReimburseOn', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10533, N'40.06', N'Name', 10499, 0, 1, 1, N'ReimburseOn', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10534, N'40.07', N'Address1', 10499, 0, 1, 1, N'ReimburseOn', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10535, N'40.08', N'Address2', 10499, 0, 1, 1, N'ReimburseOn', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10536, N'40.09', N'Address3', 10499, 0, 1, 1, N'ReimburseOn', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10537, N'40.1', N'Address4', 10499, 0, 1, 1, N'ReimburseOn', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10538, N'40.11', N'CountryCode', 10499, 0, 1, 1, N'ReimburseOn', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10539, N'40.12', N'City', 10499, 0, 1, 1, N'ReimburseOn', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10540, N'40.13', N'State', 10499, 0, 1, 1, N'ReimburseOn', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10541, N'40.14', N'ZipCode', 10499, 0, 1, 1, N'ReimburseOn', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10548, N'50', N'EntryDate', 8276, 0, 1, 1, N'ColPrimary', N'EntryDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10549, N'51', N'DateAccepted', 8276, 0, 1, 1, N'ColPrimary', N'DateAccepted')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10550, N'52', N'LastTracerDate', 8276, 0, 1, 1, N'ColPrimary', N'LastTracerDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10551, N'53', N'TraceToday', 8276, 0, 1, 1, N'ColPrimary', N'TraceToday')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10552, N'54', N'NumberOfTracers', 8276, 0, 1, 1, N'ColPrimary', N'NumberOfTracers')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10553, N'55', N'DraweeName', 8276, 0, 1, 1, N'ColPrimary', N'DraweeName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10554, N'56', N'DraweeCityCountry', 8276, 0, 1, 1, N'ColPrimary', N'DraweeCityCountry')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10555, N'57', N'DrawerName', 8276, 0, 1, 1, N'ColPrimary', N'Drawername')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10556, N'58', N'DrawerCityCountry', 8276, 0, 1, 1, N'ColPrimary', N'DrawerCityCountry')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10563, N'0', N'SARBalance', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10564, N'1', N'IccID', 10563, 0, 1, 1, N'Additional', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10565, N'2', N'TransPkey', 10563, 0, 1, 1, N'Additional', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10566, N'3', N'OutboundToDoPkey', 10563, 0, 1, 1, N'Additional', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10567, N'4', N'IccType', 10563, 0, 1, 1, N'Additional', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10568, N'5', N'Service', 10563, 0, 1, 1, N'Additional', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10569, N'6', N'Product', 10563, 0, 1, 1, N'Additional', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10570, N'7', N'LegalEntity', 10563, 0, 1, 1, N'Additional', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10571, N'8', N'ReferenceNum', 10563, 0, 1, 1, N'Additional', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10572, N'9', N'RefTransferNum', 10563, 0, 1, 1, N'Additional', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10573, N'10', N'BankRef', 10563, 0, 1, 1, N'Additional', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10574, N'11', N'IccPkey', 10563, 0, 1, 1, N'Additional', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10575, N'12', N'CustomerId', 10563, 0, 1, 1, N'Additional', N'CustomerId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10576, N'13', N'BranchId', 10563, 0, 1, 1, N'Additional', N'BranchId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10577, N'14', N'TransAmount', 10563, 0, 1, 1, N'Additional', N'TransAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10578, N'15', N'TransAmountBase', 10563, 0, 1, 1, N'Additional', N'TransAmountBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10579, N'16', N'SeqNumber', 10563, 0, 1, 1, N'Additional', N'SeqNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10580, N'17', N'TextData', 10563, 0, 1, 1, N'Additional', N'TextData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10581, N'18', N'TypeBill', 10563, 0, 1, 1, N'SARPrimary', N'TypeBill')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10582, N'19', N'RelatedTo', 10563, 0, 1, 1, N'SARPrimary', N'RelatedTo')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10583, N'20', N'BillDate', 10563, 0, 1, 1, N'SARPrimary', N'BillDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10584, N'21', N'EnterDate', 10563, 0, 1, 1, N'SARPrimary', N'EnterDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10585, N'22', N'TransferNum', 10563, 0, 1, 1, N'SARPrimary', N'TransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10586, N'23', N'ShippingCompany', 10563, 0, 1, 1, N'SARPrimary', N'ShippingCompany')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10587, N'24', N'VoyageNumber', 10563, 0, 1, 1, N'SARPrimary', N'VoyageNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10588, N'25', N'PortLoading', 10563, 0, 1, 1, N'SARPrimary', N'PortLoading')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10589, N'26', N'PortDischarge', 10563, 0, 1, 1, N'SARPrimary', N'PortDischarge')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10590, N'27', N'Container', 10563, 0, 1, 1, N'SARPrimary', N'Container')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10591, N'28', N'EstimatedValue', 10563, 0, 1, 1, N'SARPrimary', N'EstimatedValue')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10592, N'29', N'EstimatedValueBase', 10563, 0, 1, 1, N'SARPrimary', N'EstimatedValueBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10593, N'30', N'CurrencyCode', 10563, 0, 1, 1, N'SARPrimary', N'CurrencyCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10594, N'31', N'FxRate', 10563, 0, 1, 1, N'SARPrimary', N'FxRate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10595, N'32', N'DateCancelled', 10563, 0, 1, 1, N'SARPrimary', N'DateCancelled')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10596, N'33', N'BLNumber', 10563, 0, 1, 1, N'SARPrimary', N'BLNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10597, N'34', N'HouseBillNumber', 10563, 0, 1, 1, N'SARPrimary', N'HouseBillNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10598, N'35', N'ExpirationDate', 10563, 0, 1, 1, N'SARPrimary', N'ExpirationDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10599, N'36', N'MarginAmount', 10563, 0, 1, 1, N'SARPrimary', N'MarginAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10600, N'37', N'SpecialInstructions', 10563, 0, 1, 1, N'SARPrimary', N'SpecialInstructions')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10601, N'38', N'Notes', 10563, 0, 1, 1, N'Additional', N'Notes')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10602, N'39', N'Carrier', 10563, 0, 3, 0, N'Carrier', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10603, N'40', N'FreightF', 10563, 0, 3, 0, N'FreightF', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10604, N'41', N'Drawee', 10563, 0, 3, 0, N'Drawee', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10605, N'42', N'Presenter', 10563, 0, 3, 0, N'Presenter', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10614, N'39.01', N'IccPkey', 10602, 0, 1, 1, N'Carrier', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10615, N'39.02', N'GtsPkey', 10602, 0, 1, 1, N'Carrier', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10616, N'39.03', N'IccPartyId', 10602, 0, 1, 1, N'Carrier', N'IccPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10617, N'39.04', N'GtsPartyId', 10602, 0, 1, 1, N'Carrier', N'GtsPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10618, N'39.05', N'LegalEntity', 10602, 0, 1, 1, N'Carrier', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10619, N'39.06', N'Name', 10602, 0, 1, 1, N'Carrier', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10620, N'39.07', N'Address1', 10602, 0, 1, 1, N'Carrier', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10621, N'39.08', N'Address2', 10602, 0, 1, 1, N'Carrier', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10622, N'39.09', N'Address3', 10602, 0, 1, 1, N'Carrier', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10623, N'39.1', N'Address4', 10602, 0, 1, 1, N'Carrier', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10624, N'39.11', N'CountryCode', 10602, 0, 1, 1, N'Carrier', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10625, N'39.12', N'City', 10602, 0, 1, 1, N'Carrier', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10626, N'39.13', N'State', 10602, 0, 1, 1, N'Carrier', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10627, N'39.14', N'ZipCode', 10602, 0, 1, 1, N'Carrier', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10628, N'40.01', N'IccPkey', 10603, 0, 1, 1, N'FreightF', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10629, N'40.02', N'GtsPkey', 10603, 0, 1, 1, N'FreightF', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10630, N'40.03', N'IccPartyId', 10603, 0, 1, 1, N'FreightF', N'IccPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10631, N'40.04', N'GtsPartyId', 10603, 0, 1, 1, N'FreightF', N'GtsPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10632, N'40.05', N'LegalEntity', 10603, 0, 1, 1, N'FreightF', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10633, N'40.06', N'Name', 10603, 0, 1, 1, N'FreightF', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10634, N'40.07', N'Address1', 10603, 0, 1, 1, N'FreightF', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10635, N'40.08', N'Address2', 10603, 0, 1, 1, N'FreightF', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10636, N'40.09', N'Address3', 10603, 0, 1, 1, N'FreightF', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10637, N'40.1', N'Address4', 10603, 0, 1, 1, N'FreightF', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10638, N'40.11', N'CountryCode', 10603, 0, 1, 1, N'FreightF', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10639, N'40.12', N'City', 10603, 0, 1, 1, N'FreightF', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10655, N'40.13', N'State', 10603, 0, 1, 1, N'FreightF', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10656, N'40.14', N'ZipCode', 10603, 0, 1, 1, N'FreightF', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10657, N'41.01', N'IccPkey', 10604, 0, 1, 1, N'Drawee', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10658, N'41.02', N'GtsPkey', 10604, 0, 1, 1, N'Drawee', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10659, N'41.03', N'IccPartyId', 10604, 0, 1, 1, N'Drawee', N'IccPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10660, N'41.04', N'GtsPartyId', 10604, 0, 1, 1, N'Drawee', N'GtsPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10661, N'41.05', N'LegalEntity', 10604, 0, 1, 1, N'Drawee', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10662, N'41.06', N'Name', 10604, 0, 1, 1, N'Drawee', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10663, N'41.07', N'Address1', 10604, 0, 1, 1, N'Drawee', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10664, N'41.08', N'Address2', 10604, 0, 1, 1, N'Drawee', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10665, N'41.09', N'Address3', 10604, 0, 1, 1, N'Drawee', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10666, N'41.1', N'Address4', 10604, 0, 1, 1, N'Drawee', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10667, N'41.11', N'CountryCode', 10604, 0, 1, 1, N'Drawee', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10668, N'41.12', N'City', 10604, 0, 1, 1, N'Drawee', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10669, N'41.13', N'State', 10604, 0, 1, 1, N'Drawee', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10670, N'41.14', N'ZipCode', 10604, 0, 1, 1, N'Drawee', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10671, N'42.01', N'IccPkey', 10605, 0, 1, 1, N'Presenter', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10672, N'42.02', N'GtsPkey', 10605, 0, 1, 1, N'Presenter', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10673, N'42.03', N'IccPartyId', 10605, 0, 1, 1, N'Presenter', N'IccPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10674, N'42.04', N'GtsPartyId', 10605, 0, 1, 1, N'Presenter', N'GtsPartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10675, N'42.05', N'LegalEntity', 10605, 0, 1, 1, N'Presenter', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10676, N'42.06', N'Name', 10605, 0, 1, 1, N'Presenter', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10677, N'42.07', N'Address1', 10605, 0, 1, 1, N'Presenter', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10678, N'42.08', N'Address2', 10605, 0, 1, 1, N'Presenter', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10679, N'42.09', N'Address3', 10605, 0, 1, 1, N'Presenter', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10680, N'42.1', N'Address4', 10605, 0, 1, 1, N'Presenter', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10681, N'42.11', N'CountryCode', 10605, 0, 1, 1, N'Presenter', N'CountryCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10682, N'42.12', N'City', 10605, 0, 1, 1, N'Presenter', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10683, N'42.13', N'State', 10605, 0, 1, 1, N'Presenter', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10684, N'42.14', N'ZipCode', 10605, 0, 1, 1, N'Presenter', N'ZipCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10706, N'0', N'AdminMsg', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10707, N'1', N'IccID', 10706, 0, 1, 1, N'AdminMsg', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10708, N'2', N'TransPkey', 10706, 0, 1, 1, N'AdminMsg', N'TransPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10709, N'3', N'OutboundToDoPkey', 10706, 0, 1, 1, N'AdminMsg', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10710, N'4', N'IccType', 10706, 0, 1, 1, N'AdminMsg', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10711, N'5', N'Service', 10706, 0, 1, 1, N'AdminMsg', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10712, N'6', N'Product', 10706, 0, 1, 1, N'AdminMsg', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10713, N'7', N'ReferenceNum', 10706, 0, 1, 1, N'AdminMsg', N'ReferenceNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10714, N'8', N'RefTransferNum', 10706, 0, 1, 1, N'AdminMsg', N'RefTransferNum')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10715, N'9', N'BankRef', 10706, 0, 1, 1, N'AdminMsg', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10716, N'10', N'TextData', 10706, 0, 1, 1, N'AdminMsg', N'TextData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10717, N'39', N'ImageFileName', 10706, 0, 1, 1, N'AdminMsg', N'ImageFileName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10718, N'11', N'LegalEntity', 10706, 0, 1, 1, N'AdminMsg', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10719, N'12', N'Division', 10706, 0, 1, 1, N'AdminMsg', N'Division')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10720, N'13', N'Department', 10706, 0, 1, 1, N'AdminMsg', N'Department')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10721, N'14', N'CustomerId', 10706, 0, 1, 1, N'AdminMsg', N'CustomerId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10722, N'15', N'BranchId', 10706, 0, 1, 1, N'AdminMsg', N'BranchId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10723, N'16', N'OurReference', 10706, 0, 1, 1, N'AdminMsg', N'OurReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10724, N'17', N'BankReference', 10706, 0, 1, 1, N'AdminMsg', N'BankReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10725, N'18', N'GtsService', 10706, 0, 1, 1, N'AdminMsg', N'GtsService')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10726, N'19', N'GtsProduct', 10706, 0, 1, 1, N'AdminMsg', N'GtsProduct')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10727, N'20', N'GtsUserPkey', 10706, 0, 1, 1, N'AdminMsg', N'GtsUserPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10728, N'21', N'GtsUserName', 10706, 0, 1, 1, N'AdminMsg', N'GtsUserName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10729, N'22', N'GtsPaymentPkey', 10706, 0, 1, 1, N'AdminMsg', N'GtsPaymentPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10730, N'23', N'GtsWipPkey', 10706, 0, 1, 1, N'AdminMsg', N'GtsWipPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10731, N'24', N'TypeFlag', 10706, 0, 1, 1, N'AdminMsg', N'TypeFlag')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10732, N'25', N'Status', 10706, 0, 1, 1, N'AdminMsg', N'Status')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10733, N'26', N'StatusDate', 10706, 0, 1, 1, N'AdminMsg', N'StatusDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10734, N'27', N'SubjectLine', 10706, 0, 1, 1, N'AdminMsg', N'SubjectLine')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10735, N'28', N'DrawingAmount', 10706, 0, 1, 1, N'AdminMsg', N'DrawingAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10736, N'29', N'DrawingDate', 10706, 0, 1, 1, N'AdminMsg', N'DrawingDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10737, N'40', N'DiscrepancyResponseCode', 10706, 0, 1, 1, N'AdminMsg', N'DiscrepancyResponseCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10738, N'30', N'Presenter', 10706, 0, 1, 1, N'AdminMsg', N'Presenter')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10739, N'31', N'RunningText', 10706, 0, 1, 1, N'AdminMsg', N'RunningText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10740, N'32', N'ResponseText', 10706, 0, 1, 1, N'AdminMsg', N'ResponseText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10741, N'33', N'GTSOpenerPkey', 10706, 0, 1, 1, N'AdminMsg', N'GtsOpenerPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10742, N'34', N'BankId', 10706, 0, 1, 1, N'AdminMsg', N'BankId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10743, N'35', N'DiscrepancyResponse', 10706, 0, 1, 1, N'AdminMsg', N'DiscrepancyResponse')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10744, N'36', N'StatusUserId', 10706, 0, 1, 1, N'AdminMsg', N'StatusUserId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10745, N'37', N'GtsId', 10706, 0, 1, 1, N'AdminMsg', N'GtsId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10746, N'38', N'ImageType', 10706, 0, 1, 1, N'AdminMsg', N'ImageType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10771, N'41.1', N'IccPkey', 10706, 0, 1, 1, N'AdminMsg', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10784, N'42', N'RemitterReference', 10706, 0, 1, 1, N'AdminMsg', N'RemitterReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10785, N'43', N'DrawerReference', 10706, 0, 1, 1, N'AdminMsg', N'DrawerReference')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10786, N'44', N'DrawerName', 10706, 0, 1, 1, N'AdminMsg', N'DrawerName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10787, N'45', N'TenorDays', 10706, 0, 1, 1, N'AdminMsg', N'TenorDays')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10788, N'46', N'TenorPhrase', 10706, 0, 1, 1, N'AdminMsg', N'TenorPhrase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10789, N'47', N'POADate', 10706, 0, 1, 1, N'AdminMsg', N'POADate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10790, N'48', N'AmountOutstandingBase', 10706, 0, 1, 1, N'AdminMsg', N'AmountOutstandingBase')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10791, N'49', N'AmountOutstanding', 10706, 0, 1, 1, N'AdminMsg', N'AmountOutstanding')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10792, N'50', N'BankCharges', 10706, 0, 1, 1, N'AdminMsg', N'BankCharges')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10793, N'51', N'RemitterCharges', 10706, 0, 1, 1, N'AdminMsg', N'RemitterCharges')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10794, N'52', N'MaturityDate', 10706, 0, 1, 1, N'AdminMsg', N'MaturityDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10795, N'53', N'PresBankChargesWaivable', 10706, 0, 1, 1, N'AdminMsg', N'PresBankChargesWaivable')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10796, N'54', N'OurBankChargesWaivable', 10706, 0, 1, 1, N'AdminMsg', N'OurBankChargesWaivable')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10797, N'57', N'DocumentDisposition', 10706, 0, 1, 1, N'AdminMsg', N'DocumentDisposition')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10809, N'41', N'TranDate', 10459, 0, 1, 1, N'Additional', N'TranDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10810, N'63', N'TranDate', 8276, 0, 1, 1, N'Additional', N'TranDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10811, N'92', N'TranDate', 10134, 0, 1, 1, N'Additional', N'TranDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10812, N'45', N'TranDate', 10563, 0, 1, 1, N'Additional', N'TranDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10846, N'55', N'PresBankChargesWaived', 10706, 0, 1, 1, N'AdminMsg', N'PresBankChargesWaived')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10847, N'56', N'OurBankChargesWaived', 10706, 0, 1, 1, N'AdminMsg', N'OurBankChargesWaived')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10965, N'42', N'CopyTo1', 10459, 0, 1, 1, N'Additional', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10966, N'43', N'CopyTo2', 10459, 0, 1, 1, N'Additional', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10967, N'44', N'CopyTo3', 10459, 0, 1, 1, N'Additional', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10968, N'64', N'CopyTo1', 8276, 0, 1, 1, N'Additional', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10969, N'65', N'CopyTo2', 8276, 0, 1, 1, N'Additional', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10970, N'66', N'CopyTo3', 8276, 0, 1, 1, N'Additional', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10971, N'93', N'CopyTo1', 10134, 0, 1, 1, N'Additional', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10972, N'94', N'CopyTo2', 10134, 0, 1, 1, N'Additional', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10973, N'95', N'CopyTo3', 10134, 0, 1, 1, N'Additional', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10974, N'46', N'CopyTo1', 10563, 0, 1, 1, N'Additional', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10975, N'47', N'CopyTo2', 10563, 0, 1, 1, N'Additional', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (10976, N'48', N'CopyTo3', 10563, 0, 1, 1, N'Additional', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11030, N'58', N'CopyTo1', 10706, 0, 1, 1, N'AdminMsg', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11031, N'59', N'CopyTo2', 10706, 0, 1, 1, N'AdminMsg', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11032, N'60', N'CopyTo3', 10706, 0, 1, 1, N'AdminMsg', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11033, N'21', N'CopyTo1', 8602, 0, 1, 1, N'BankText', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11034, N'22', N'CopyTo2', 8602, 0, 1, 1, N'BankText', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11035, N'23', N'CopyTo3', 8602, 0, 1, 1, N'BankText', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11036, N'1.22', N'CopyTo1', 8283, 0, 1, 1, N'Fees', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11037, N'1.23', N'CopyTo2', 8283, 0, 1, 1, N'Fees', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11038, N'1.24', N'CopyTo3', 8283, 0, 1, 1, N'Fees', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11039, N'27', N'CopyTo1', 8347, 0, 1, 1, N'iMail', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11040, N'28', N'CopyTo2', 8347, 0, 1, 1, N'iMail', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11041, N'29', N'CopyTo3', 8347, 0, 1, 1, N'iMail', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11042, N'25', N'CopyTo1', 8326, 0, 1, 1, N'PayStatus', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11043, N'26', N'CopyTo2', 8326, 0, 1, 1, N'PayStatus', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11044, N'27', N'CopyTo3', 8326, 0, 1, 1, N'PayStatus', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11045, N'9', N'CopyTo1', 8692, 0, 1, 1, N'Status', N'CopyTo1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11046, N'10', N'CopyTo2', 8692, 0, 1, 1, N'Status', N'CopyTo2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11047, N'11', N'CopyTo3', 8692, 0, 1, 1, N'Status', N'CopyTo3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11058, N'1.21', N'TranDate', 8283, 0, 1, 1, N'Fees', N'TranDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11059, N'20', N'TranDate', 8602, 0, 1, 1, N'BankText', N'TranDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11070, N'24', N'Files', 8347, 4, 3, 1, N'Files', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11071, N'24.01', N'FileName', 11070, 0, 1, 1, N'Files', N'FileName')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11072, N'24.02', N'FileType', 11070, 0, 1, 1, N'Files', N'FileType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (11073, N'24.03', N'FileData', 11070, 0, 1, 1, N'Files', N'FileData')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040021, N'0', N'AdvBank', 0, 0, 4, 1, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040022, N'0', N'FxRate', 0, 0, 4, 1, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040023, N'1', N'LegalEntity', 1040022, 0, 1, 1, N'FxRate', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040024, N'2', N'Code', 1040022, 0, 1, 1, N'FxRate', N'Code')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040025, N'3', N'Description', 1040022, 0, 1, 1, N'FxRate', N'Description')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040026, N'4', N'SpotRate', 1040022, 0, 1, 1, N'FxRate', N'SpotRate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040027, N'5', N'MultDiv', 1040022, 0, 1, 1, N'FxRate', N'MultDiv')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040028, N'6', N'Decimals', 1040022, 0, 1, 1, N'FxRate', N'Decimals')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040029, N'7', N'Active', 1040022, 0, 1, 1, N'FxRate', N'Active')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040030, N'8', N'OrderBy', 1040022, 0, 1, 1, N'FxRate', N'OrderBy')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040044, N'1', N'GtsPkey', 1040021, 0, 1, 1, N'AdvBank', N'GtsPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040045, N'2', N'GtsHostId', 1040021, 0, 1, 1, N'AdvBank', N'GtsHostId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040046, N'3', N'CustomerId', 1040021, 0, 1, 1, N'AdvBank', N'CustomerId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040047, N'4', N'BranchId', 1040021, 0, 1, 1, N'AdvBank', N'BranchId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040048, N'5', N'PartyId', 1040021, 0, 1, 1, N'AdvBank', N'PartyId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040049, N'6', N'Name', 1040021, 0, 1, 1, N'AdvBank', N'Name')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040050, N'7', N'Address1', 1040021, 0, 1, 1, N'AdvBank', N'Address1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040051, N'8', N'Address2', 1040021, 0, 1, 1, N'AdvBank', N'Address2')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040052, N'9', N'Address3', 1040021, 0, 1, 1, N'AdvBank', N'Address3')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040053, N'10', N'Address4', 1040021, 0, 1, 1, N'AdvBank', N'Address4')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040054, N'11', N'City', 1040021, 0, 1, 1, N'AdvBank', N'City')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040055, N'12', N'State', 1040021, 0, 1, 1, N'AdvBank', N'State')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040056, N'13', N'Country', 1040021, 0, 1, 1, N'AdvBank', N'Country')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040057, N'14', N'PostalCode', 1040021, 0, 1, 1, N'AdvBank', N'PostalCode')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040058, N'15', N'Type', 1040021, 0, 1, 1, N'AdvBank', N'Type')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040059, N'16', N'IsPtyFlag', 1040021, 0, 1, 1, N'AdvBank', N'IsPtyFlag')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040060, N'17', N'BankId', 1040021, 0, 1, 1, N'AdvBank', N'BankId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040061, N'18', N'LegalEntity', 1040021, 0, 1, 1, N'AdvBank', N'LegalEntity')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040062, N'19', N'Active', 1040021, 0, 1, 1, N'AdvBank', N'Active')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040104, N'89.5', N'BillsOfLading', 10134, 4, 3, 1, N'BillsOfLading', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040105, N'89.5.01', N'BillType', 1040104, 0, 1, 1, N'BillsOfLading', N'BillOfLadingType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040106, N'89.5.02', N'PrePaid', 1040104, 0, 1, 1, N'BillsOfLading', N'PrePaid')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040107, N'89.5.03', N'NumberOriginals', 1040104, 0, 1, 1, N'BillsOfLading', N'NumberOriginals')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040108, N'89.5.04', N'OrigReqPresentation', 1040104, 0, 1, 1, N'BillsOfLading', N'OrigReqPresentation')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040109, N'89.5.05', N'NumberCopies', 1040104, 0, 1, 1, N'BillsOfLading', N'NumberCopies')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040110, N'89.5.06', N'IncoTerm', 1040104, 0, 1, 1, N'BillsOfLading', N'IncoTerm')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040111, N'89.5.07', N'PlacePort', 1040104, 0, 1, 1, N'BillsOfLading', N'PlacePort')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040112, N'89.5.08', N'ConsignedTo', 1040104, 0, 1, 1, N'BillsOfLading', N'ConsignedTo')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040113, N'89.5.09', N'Notify', 1040104, 0, 1, 1, N'BillsOfLading', N'Notify')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040114, N'89.5.10', N'AddText', 1040104, 0, 1, 1, N'BillsOfLading', N'AddText')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040115, N'89.5.11', N'OpenerPaysIns', 1040104, 0, 1, 1, N'BillsOfLading', N'OpenerPaysIns')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040116, N'89.5.12', N'FullSets', 1040104, 0, 1, 1, N'BillsOfLading', N'FullSets')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040117, N'0', N'CertUtil', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040118, N'01', N'BankId', 1040117, 0, 1, 1, N'CertUtil', N'BankId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040119, N'02', N'CustomerId', 1040117, 0, 1, 1, N'CertUtil', N'CustomerId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040120, N'03', N'BranchId', 1040117, 0, 1, 1, N'CertUtil', N'BranchId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040121, N'04', N'IccID', 1040117, 0, 1, 1, N'CertUtil', N'GtsId')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040122, N'05', N'BankRef', 1040117, 0, 1, 1, N'CertUtil', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040123, N'06', N'UtilizedAmount', 1040117, 0, 1, 1, N'CertUtil', N'UtilizedAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040124, N'07', N'AverageDailyBalance', 1040117, 0, 1, 1, N'CertUtil', N'AverageDailyBalance')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040125, N'08', N'CollateralizationPercentage', 1040117, 0, 1, 1, N'CertUtil', N'CollateralizationPercentage')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040126, N'09', N'Service', 1040117, 0, 1, 1, N'CertUtil', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040127, N'10', N'Product', 1040117, 0, 1, 1, N'CertUtil', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040128, N'11', N'IccType', 1040117, 0, 1, 1, N'CertUtil', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040129, N'12', N'IccPkey', 1040117, 0, 1, 1, N'CertUtil', N'IccPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040174, N'9992', N'FHLExtStatus', 10134, 0, 1, 1, N'LocPrimary', N'FHLExtStatus')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040175, N'9993', N'MemberLCNumber', 10134, 0, 1, 1, N'LocPrimary', N'MemberLCNumber')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040176, N'9993', N'MemberLCAmount', 10134, 0, 1, 1, N'LocPrimary', N'MemberLCAmount')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040177, N'9994', N'MemberLCEffectiveDate', 10134, 0, 1, 1, N'LocPrimary', N'MemberLCEffectiveDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040178, N'9995', N'MemberLCExpirationDate', 10134, 0, 1, 1, N'LocPrimary', N'MemberLCExpirationDate')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040179, N'9996', N'AccountPartyCustomer', 10134, 0, 1, 1, N'LocPrimary', N'AccountPartyCustomer')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040194, N'0', N'Merge', 0, 0, 4, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040210, N'6', N'OldIccID', 1040194, 0, 1, 1, N'Merge', N'OldIccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040211, N'7', N'NewIccID', 1040194, 0, 1, 1, N'Merge', N'NewIccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040227, N'1', N'OutboundToDoPkey', 1040194, 0, 1, 1, N'Merge', N'OutboundToDoPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040228, N'2', N'IccType', 1040194, 0, 1, 1, N'Merge', N'IccType')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040229, N'3', N'IccID', 1040194, 0, 1, 1, N'Merge', N'IccID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040230, N'4', N'Service', 1040194, 0, 1, 1, N'Merge', N'Service')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040231, N'5', N'Product', 1040194, 0, 1, 1, N'Merge', N'Product')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040233, N'30.17', N'Phone', 10165, 0, 1, 1, N'Bene', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040234, N'20.17', N'Phone', 10155, 0, 1, 1, N'ApplicantBank', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040235, N'19.17', N'Phone', 10154, 0, 1, 1, N'AdviseThru', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040236, N'53.17', N'Phone', 10189, 0, 1, 1, N'Opener', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040237, N'39.17', N'Phone', 10602, 0, 1, 1, N'Carrier', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040238, N'40.17', N'Phone', 10603, 0, 1, 1, N'FreightF', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040239, N'41.17', N'Phone', 10604, 0, 1, 1, N'Drawee', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040240, N'42.17', N'Phone', 10605, 0, 1, 1, N'Presenter', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040241, N'34.17', N'Phone', 10493, 0, 1, 1, N'Obligor', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040242, N'37.17', N'Phone', 10496, 0, 1, 1, N'PayTo', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040243, N'40.17', N'Phone', 10499, 0, 1, 1, N'ReimburseOn', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040244, N'21.17', N'Phone', 10266, 0, 1, 1, N'Remitter', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040245, N'33.17', N'Phone', 10278, 0, 1, 1, N'CollectFrom', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040246, N'35.17', N'Phone', 10280, 0, 1, 1, N'Drawee', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040247, N'36.17', N'Phone', 10281, 0, 1, 1, N'Drawer', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040248, N'37.17', N'Phone', 10282, 0, 1, 1, N'CreditTo', N'Phone')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040282, N'8', N'BankRef', 1040194, 0, 1, 1, N'Merge', N'BankRef')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040363, N'9', N'AppPkey', 1040194, 0, 1, 1, N'Merge', N'AppPkey')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040413, N'25', N'DepositorsGtsPartyID', 1016, 0, 1, 1, N'Pledge', N'DepositorsGtsPartyID')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040430, N'26', N'DepositorsAttnLine1', 1016, 0, 1, 1, N'Pledge', N'DepositorsAttnLine1')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040503, N'90.09', N'DocPresIns', 8651, 0, 1, 1, N'Text', N'DocPresIns')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040504, N'90.10', N'UTermScond', 8651, 0, 1, 1, N'Text', N'UTermScond')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040505, N'90.11', N'UTranSdtl', 8651, 0, 1, 1, N'Text', N'UTranSdtl')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040522, N'9997', N'SendVia', 10134, 0, 1, 1, N'LocPrimary', N'SendVia')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040555, N'9999', N'WorkField', 10134, 0, 1, 1, N'Additional', N'WorkField')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040620, N'<Pledge>', N'Pledge', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040621, N'<COLBalance>', N'COLBalance', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040622, N'<GtsFees>', N'GtsFees', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040623, N'<PayStatus>', N'PayStatus', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040624, N'<iMail>', N'iMail', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040625, N'<GtsDocs>', N'GtsDocs', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040626, N'<Status>', N'Status', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040627, N'<IccUsers>', N'IccUsers', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040628, N'<LCBalance>', N'LCBalance', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040629, N'<BABalance>', N'BABalance', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040630, N'<SARBalance>', N'SARBalance', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040631, N'<AdminMsg>', N'AdminMsg', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040632, N'<AdvBank>', N'AdvBank', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040633, N'<FxRate>', N'FxRate', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040634, N'<CertUtil>', N'CertUtil', 10135, 0, 5, 0, N'', N'')
GO
INSERT [dbo].[XNode] ([Pkey], [Descriptor], [Name], [ParentPkey], [NodeAttr], [NodeType], [DataType], [DataSource], [DataColumn]) VALUES (1040635, N'<Merge>', N'Merge', 10135, 0, 5, 0, N'', N'')
GO
